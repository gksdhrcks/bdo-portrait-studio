@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto run
where py >nul 2>nul
if errorlevel 1 (
  python -m venv .venv
) else (
  py -3 -m venv .venv
)
if errorlevel 1 goto fail
:run
".venv\Scripts\python.exe" -c "from PIL import Image; import tkinter; import tkinterdnd2" >nul 2>nul
if errorlevel 1 (
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 goto fail
)
".venv\Scripts\python.exe" run.py
if errorlevel 1 goto fail
exit /b 0
:fail
echo Python 3.10+ and an internet connection are needed for the first setup.
echo See README.md for instructions.
pause
exit /b 1
