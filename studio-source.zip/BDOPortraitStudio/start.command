#!/bin/sh
cd -- "$(dirname -- "$0")"
exec /bin/sh ./start.sh "$@"
