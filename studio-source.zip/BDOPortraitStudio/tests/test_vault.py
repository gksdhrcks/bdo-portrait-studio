import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image

from portrait_studio.core import default_layers,find_fonts,render_portrait,scan_library
from portrait_studio.vault import Vault,select_data_directory


class VaultTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.original=self.root/'original';self.original.mkdir()
        self.file=self.original/'다크나이트_각성.png'
        Image.new('RGB',(120,180),'red').save(self.file)
        self.vault=Vault(self.root/'computer-a')
    def tearDown(self):self.temp.cleanup()

    def project(self,font=''):
        return {'schema':1,'character':'다크나이트','mode':'각성','layers':default_layers(font),
                'zoom':145,'pan_x':12,'pan_y':-6,'shade':40,'generation':{'provider':'Test provider','requested_model':'test-model'}}

    def test_base_images_survive_original_removal_and_repeated_import(self):
        self.vault.import_entries(scan_library(str(self.original)))
        again=self.vault.import_entries(scan_library(str(self.original)))
        self.assertEqual(len(again),1)
        self.file.unlink()
        reopened=Vault(self.root/'computer-a')
        entries=reopened.entries()
        self.assertEqual(entries[0].status,'연결 완료')
        self.assertEqual(Image.open(entries[0].path).getpixel((0,0)),(255,0,0))
        entries[0].class_name='새 클래스';entries[0].mode='기본'
        reopened.update_entries(entries)
        self.assertEqual(reopened.entries()[0].class_name,'새 클래스')

    def test_backup_restores_pictures_fonts_reference_results_and_draft_on_new_computer(self):
        self.vault.import_entries(scan_library(str(self.original)))
        fonts=find_fonts();self.assertTrue(fonts)
        font=next((p for p in fonts if Path(p).name.lower() in {'arial.ttf','dejavusans.ttf'}),fonts[0])
        project=self.project(font)
        reference=self.vault.put_image(Image.new('RGB',(30,40),'green'),'reference')
        project.update(reference_asset=reference,reference_label='참조 그림.png')
        source=Image.new('RGB',(200,250),'blue')
        preview,_=render_portrait(source,project['layers'])
        identifier=self.vault.add_result(source,preview,project)
        self.vault.save_draft(('다크나이트','각성'),project,'AI 결과',identifier)
        self.vault.save_preferences({'character':'다크나이트','mode':'각성','api_key':'do-not-export','layers':project['layers'],'reference_asset':reference})
        backup=self.vault.export_backup(self.root/'all-work.bdostudio')
        self.file.unlink()
        destination=Vault(self.root/'computer-b')
        recovery=destination.restore_backup(backup)
        self.assertTrue(recovery.is_file())
        restored=destination.result(identifier)
        self.assertEqual(restored['image'].getpixel((0,0)),(0,0,255))
        self.assertEqual(destination.image(reference).getpixel((0,0)),(0,128,0))
        self.assertTrue(Path(restored['project']['layers'][0]['font']).is_relative_to(destination.root))
        self.assertEqual(destination.draft(('다크나이트','각성'))['project']['zoom'],145)
        self.assertEqual(destination.entries()[0].status,'연결 완료')
        self.assertNotIn('do-not-export',backup.read_bytes().decode('latin1'))
        self.assertNotIn('api_key',destination.load_preferences())

    def test_reference_and_workflow_are_copied_and_workflow_keys_are_removed(self):
        workflow=self.root/'workflow.json'
        workflow.write_text(json.dumps({'1':{'inputs':{'api_key':'workflow-secret','text':'prompt','max_tokens':25}}}))
        self.vault.save_preferences({'ai':{'workflow':str(workflow),'api_key':'key-secret'},'layers':[]})
        workflow.unlink()
        restored=self.vault.load_preferences()
        self.assertTrue(Path(restored['ai']['workflow']).is_file())
        data=Path(restored['ai']['workflow']).read_text()
        self.assertNotIn('workflow-secret',data)
        self.assertIn('max_tokens',data)

    def test_invalid_archive_does_not_replace_current_data(self):
        self.vault.set_preference('sentinel',{'keep':True})
        fake=self.root/'fake.bdostudio';fake.write_bytes(b'not a sqlite database')
        with self.assertRaises((ValueError,sqlite3.DatabaseError)):self.vault.restore_backup(fake)
        self.assertEqual(self.vault.preference('sentinel'),{'keep':True})

    def test_tampered_blob_or_trigger_archive_is_rejected(self):
        other=Vault(self.root/'bad-source')
        digest=other.put_image(Image.new('RGB',(20,30),'red'))
        with other.connect() as connection:connection.execute('UPDATE blobs SET payload=? WHERE hash=?',(b'bad',digest))
        with self.assertRaises(ValueError):self.vault.restore_backup(other.path)
        with other.connect() as connection:
            connection.execute('DELETE FROM blobs')
            connection.execute('CREATE TRIGGER bad AFTER INSERT ON prefs BEGIN DELETE FROM library; END')
        with self.assertRaises(ValueError):self.vault.restore_backup(other.path)

    def test_portable_folder_selection_and_legacy_settings_migration(self):
        program=self.root/'program';program.mkdir();(program/'portable.txt').write_text('portable')
        old=self.root/'legacy';old.mkdir();(old/'settings.json').write_text('{"character":"무사"}',encoding='utf-8')
        with patch('portrait_studio.vault.program_directory',return_value=program),patch('portrait_studio.vault.data_directory',return_value=old):
            directory=select_data_directory()
        self.assertEqual(directory,program/'StudioData')
        self.assertTrue((directory/'settings.json').is_file())


class PersistenceUITests(unittest.TestCase):
    def test_app_restart_restores_defaults_and_results_without_original_folder(self):
        import tkinter as tk
        from portrait_studio.app import StudioApp
        with tempfile.TemporaryDirectory() as temporary:
            folder=Path(temporary)/'external';folder.mkdir()
            image=folder/'다크나이트_각성.png';Image.new('RGB',(160,240),'red').save(image)
            data=Path(temporary)/'data'
            root=tk.Tk();root.withdraw();app=StudioApp(root,data)
            app._scanned(scan_library(str(folder)))
            app.layers[2]['x']=31;app.zoom.set(155)
            result_id=app._archive_current();app.open_stored_result(result_id);app._save_settings()
            expected=app._render_full()[0].tobytes()
            root.destroy();image.unlink()
            root=tk.Tk();root.withdraw();restored=StudioApp(root,data)
            self.assertIsNotNone(restored.base_image)
            self.assertEqual(restored.result_id,result_id)
            self.assertEqual(restored.layers[2]['x'],31)
            self.assertEqual(restored.zoom.get(),155)
            self.assertEqual(restored._render_full()[0].tobytes(),expected)
            root.destroy()


if __name__=='__main__':unittest.main()
