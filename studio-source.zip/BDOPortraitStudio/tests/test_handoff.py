import io
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from PIL import Image, ImageGrab

from portrait_studio.clipboard import copy_image
from portrait_studio.core import default_layers, load_image, scan_library
from portrait_studio.desktop import create_root, register_file_drag
from portrait_studio.handoff import korean_font, render_handoff, wrap_text
from portrait_studio.vault import Vault
from portrait_studio.web_tasks import WebTasks
from portrait_studio.web_ui import BUNDLE_REQUEST


def font_or_skip(test):
    try:return korean_font()
    except ValueError as exc:test.skipTest(str(exc))


class HandoffTests(unittest.TestCase):
    def test_board_preserves_image_roles_and_aspect_ratios_without_cropping(self):
        font=font_or_skip(self)
        base=Image.new('RGB',(600,900),'red');reference=Image.new('RGB',(900,300),'green')
        board,boxes=render_handoff(base,reference,'01_base.png는 기본 그림\n02_reference.png는 화풍 참조',font)
        self.assertEqual(len(boxes),2)
        for box,original in zip(boxes,[base,reference]):
            x,y,right,bottom=box
            self.assertAlmostEqual((right-x)/(bottom-y),original.width/original.height,places=2)
            self.assertEqual(board.getpixel(((x+right)//2,(y+bottom)//2)),original.getpixel((0,0)))
        from PIL import ImageFont
        text='젠더: 남성으로 재해석. 무기와 의상은 유지해 주세요.'
        self.assertEqual(''.join(wrap_text(text,ImageFont.truetype(font,32),200)),text)
        with self.assertRaises(ValueError):render_handoff(base,None,'x'*8001,font)

    def test_bundle_regenerates_from_portable_backup_and_original_files_stay_exact(self):
        font=Path(font_or_skip(self))
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);vault=Vault(root/'a');service=WebTasks(vault)
            project=dict(character='가모스',mode='기본',kind='보스·몬스터',layers=default_layers(),
                         controls=dict(gender='기본 그림 유지',prompt='푸른 밤'),api_key='do-not-copy')
            vault.set_preference('web_bundle_font',vault.put_blob(font.read_bytes(),'font',font.suffix))
            base=Image.new('RGB',(600,900),'red');reference=Image.new('RGB',(800,500),'blue')
            task=service.create(base,reference,project)
            board=service.bundle(task['id']);before=load_image(board)
            stamp=board.stat().st_mtime_ns
            self.assertEqual(service.bundle(task['id']).stat().st_mtime_ns,stamp)
            originals=service.attachments(task['id'])
            self.assertEqual([load_image(p).tobytes() for p in originals],[base.tobytes(),reference.tobytes()])
            self.assertNotIn('do-not-copy',json.dumps(service.task(task['id'])))
            backup=vault.export_backup(root/'transfer.bdostudio')
            destination=Vault(root/'b');destination.restore_backup(backup)
            restored=load_image(WebTasks(destination).bundle(task['id']))
            self.assertEqual(before.tobytes(),restored.tobytes())

    def test_current_selection_reuses_identical_task_but_changed_gender_or_reference_gets_a_new_one(self):
        with tempfile.TemporaryDirectory() as temporary:
            service=WebTasks(Vault(Path(temporary)))
            project=dict(character='다크나이트',mode='각성',layers=default_layers(),controls=dict(gender='기본 그림 유지'))
            base=Image.new('RGB',(40,60),'red')
            first=service.create(base,None,project,reuse=True)
            self.assertEqual(service.create(base,None,project,reuse=True)['id'],first['id'])
            project['controls']['gender']='남성으로 재해석'
            second=service.create(base,None,project,reuse=True)
            self.assertNotEqual(second['id'],first['id'])
            third=service.create(base,Image.new('RGB',(30,50),'blue'),project,reuse=True)
            self.assertNotEqual(third['id'],second['id'])
            self.assertEqual(service.task(first['id'])['project']['controls']['gender'],'기본 그림 유지')

    def test_native_drag_exports_all_original_paths_with_spaces_and_korean(self):
        root=create_root();root.withdraw()
        try:
            with tempfile.TemporaryDirectory(prefix='한글 그림 ') as temporary:
                files=[Path(temporary)/'01 base.png',Path(temporary)/'02 참조.png']
                for path in files:Image.new('RGB',(10,10)).save(path)
                events={}
                widget=SimpleNamespace(drag_source_register=lambda *args:None,
                    dnd_bind=lambda name,callback:events.update({name:callback}))
                self.assertTrue(register_file_drag(widget,lambda:files))
                action,kind,paths=events['<<DragInitCmd>>'](None)
                self.assertEqual(root.tk.splitlist(root.tk.call('format','%s',paths)),tuple(str(path.resolve()) for path in files))
                files[0].unlink()
                self.assertEqual(events['<<DragInitCmd>>'](None),'refuse_drop')
        finally:root.update_idletasks();root.destroy()


class ClipboardTests(unittest.TestCase):
    def test_real_clipboard_contains_the_image_instead_of_just_its_filename(self):
        if sys.platform=='linux' and not shutil.which('xclip'):self.skipTest('xclip is unavailable')
        root=create_root();root.withdraw()
        try:
            with tempfile.TemporaryDirectory() as temporary:
                path=Path(temporary)/'한 장 첨부.png'
                image=Image.new('RGB',(75,110),'#295e8d');image.putpixel((4,6),(222,11,32));image.save(path)
                copy_image(root,path,BUNDLE_REQUEST)
                if sys.platform=='win32':
                    actual=ImageGrab.grabclipboard()
                    self.assertIsInstance(actual,Image.Image)
                    self.assertEqual(actual.convert('RGB').tobytes(),image.tobytes())
                    self.assertEqual(root.clipboard_get(),BUNDLE_REQUEST)
                elif sys.platform=='darwin':
                    result=subprocess.run(['osascript','-e','clipboard info'],capture_output=True,check=True,timeout=10)
                    self.assertIn(b'PNGf',result.stdout)
                else:
                    result=subprocess.run(['xclip','-selection','clipboard','-t','image/png','-o'],capture_output=True,check=True,timeout=10)
                    self.assertEqual(Image.open(io.BytesIO(result.stdout)).tobytes(),image.tobytes())
        finally:root.update_idletasks();root.destroy()

    def test_linux_without_clipboard_tool_reports_fallback_and_never_claims_success(self):
        with tempfile.TemporaryDirectory() as temporary:
            path=Path(temporary)/'board.png';Image.new('RGB',(10,10)).save(path)
            with patch('portrait_studio.clipboard.sys.platform','linux'),patch('portrait_studio.clipboard.shutil.which',return_value=None):
                with self.assertRaisesRegex(OSError,'wl-copy|xclip'):copy_image(None,path)


class HandoffUITests(unittest.TestCase):
    def test_quick_copy_opens_browser_only_after_real_copy_succeeds_and_layout_fits(self):
        font_or_skip(self)
        from portrait_studio.app import StudioApp
        with tempfile.TemporaryDirectory() as temporary:
            root=create_root();root.withdraw()
            try:
                app=StudioApp(root,Path(temporary)/'data')
                folder=Path(temporary)/'original';folder.mkdir()
                Image.new('RGB',(500,800),'red').save(folder/'다크나이트_각성.png')
                app._scanned(scan_library(str(folder)));app.provider.set('ChatGPT 웹');app.open_web_workspace()
                web=app.web_workspace;self.assertIsNotNone(web.bundle_path)
                web.window.attributes('-alpha',0.0);root.attributes('-alpha',0.0);root.deiconify()
                web.window.geometry('700x700+0+0');web.window.update()
                for button in [web.bundle_copy_button,web.bundle_again_button,web.import_button]:
                    self.assertTrue(button.winfo_ismapped())
                    self.assertLessEqual(button.winfo_rooty()+button.winfo_height(),web.window.winfo_rooty()+web.window.winfo_height())
                with patch('portrait_studio.web_ui.copy_image') as copy,patch.object(app,'open_chatgpt') as browser:
                    web.copy_bundle(True);copy.assert_called_once();browser.assert_called_once()
                with patch('portrait_studio.web_ui.copy_image',side_effect=OSError('busy')),patch.object(app,'open_chatgpt') as browser:
                    web.copy_bundle(True);browser.assert_not_called();self.assertIn('복사하지 못',web.note.get())
                first=web.task_id;app.gender.set('남성으로 재해석');app.open_web_workspace()
                self.assertNotEqual(first,web.task_id)
                self.assertIn('남성으로 재해석',app.web_tasks.task(web.task_id)['prompt'])
            finally:root.update_idletasks();root.destroy()


if __name__=='__main__':unittest.main()
