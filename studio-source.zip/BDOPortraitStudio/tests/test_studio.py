import base64
import copy
import io
import json
import tempfile
import unittest
import urllib.error
import urllib.parse
from pathlib import Path
from unittest.mock import patch

from PIL import Image

from portrait_studio.core import (SIZE, apply_with_backup, default_layers, export_bundle,
                                 infer_identity, load_image, png_bytes, render_portrait,
                                 scan_library, validate_entries)
from portrait_studio.providers import (ComfyProvider, OpenAIProvider, ProviderError,
                                      compose_prompt, prepare_workflow, read_workflow)


def workflow():
    return {
        "1":{"class_type":"LoadImage","inputs":{"image":"base.png"}},
        "2":{"class_type":"LoadImage","inputs":{"image":"ref.png"}},
        "3":{"class_type":"CLIPTextEncode","inputs":{"text":"positive"}},
        "4":{"class_type":"TestEdit","inputs":{"base":["1",0],"reference":["2",0],"conditioning":["3",0]}},
        "5":{"class_type":"SaveImage","inputs":{"images":["4",0],"filename_prefix":"test"}},
        "6":{"class_type":"LoadImage","inputs":{"image":"unused.png"}},
    }


BINDINGS={"base":"1:image","reference":"2:image","prompt":"3:text","output":"5"}


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def image(self,name,color="red"):
        file=self.root/name;file.parent.mkdir(parents=True,exist_ok=True)
        Image.new("RGB",(300,500),color).save(file);return file

    def test_korean_english_and_folder_classification(self):
        for file,expected in [("다크나이트_각성.png",("다크나이트","각성")),
            ("dark_knight/awakening/01.png",("다크나이트","각성")),
            ("무사전승02.png",("무사","전승")),("위치/전승/one.png",("위치","전승"))]:
            self.assertEqual(infer_identity(file),expected)
        self.assertEqual(infer_identity("다크나잇_각성.png"),("","각성"))
        self.assertEqual(infer_identity("위치/무사_각성.png"),("","각성"))

    def test_scan_duplicate_unknown_corrupt_and_override(self):
        a=self.image("무사_전승.png");b=self.image("무사_전승_2.png")
        unknown=self.image("unknown.png")
        (self.root/"매화_각성.png").write_text("broken")
        (self.root/"readme.txt").write_text("ignore")
        entries=scan_library(str(self.root))
        self.assertEqual(len(entries),4)
        self.assertEqual(sum(e.status.startswith("중복") for e in entries),2)
        self.assertEqual(sum(bool(e.error) for e in entries),1)
        overrides={str(b):{"skipped":True},str(unknown):{"class_name":"새로운클래스","mode":"각성"}}
        fixed=scan_library(str(self.root),overrides)
        self.assertEqual(sum(e.status=="연결 완료" for e in fixed),2)

    def test_export_is_24_bit_bmp_and_preserves_source(self):
        source=Image.new("RGB",(1000,1500),"#a83244")
        rendered,_=render_portrait(source,[],shade=0)
        target=export_bundle(str(self.root),"다크나이트_각성",source,rendered,{"api_key":"secret","layers":[]})
        raw=(target/"portrait.bmp").read_bytes()
        self.assertEqual(raw[:2],b"BM");self.assertEqual(int.from_bytes(raw[28:30],"little"),24)
        self.assertEqual(load_image(target/"portrait.bmp").size,(220,283))
        self.assertEqual(load_image(target/"portrait.png").size,(220,283))
        self.assertEqual(load_image(target/"source.png").size,source.size)
        self.assertNotIn("secret",(target/"project.json").read_text(encoding="utf-8"))
        again=export_bundle(str(self.root),"다크나이트_각성",source,rendered,{})
        self.assertNotEqual(target,again)

    def test_crop_and_pan_do_not_distort_or_explode(self):
        image=Image.new("RGB",(400,100),"red")
        for x in range(200,400):
            for y in range(100):image.putpixel((x,y),(0,0,255))
        left,_=render_portrait(image,[],pan_x=-100,shade=0)
        right,_=render_portrait(image,[],pan_x=100,shade=0)
        self.assertEqual(left.getpixel((110,141)),(255,0,0))
        self.assertEqual(right.getpixel((110,141)),(0,0,255))
        wide=Image.new("RGB",(100000,1),"green")
        self.assertEqual(render_portrait(wide,[],shade=0)[0].size,SIZE)

    def test_apply_keeps_exact_backup(self):
        target=self.image("existing.bmp");original=target.read_bytes()
        backup=apply_with_backup(str(target),Image.new("RGB",SIZE,"blue"),self.root/"backups")
        self.assertEqual(backup.read_bytes(),original)
        self.assertEqual(load_image(target).size,SIZE)

    def test_wrong_size_cannot_be_exported_or_applied(self):
        wrong=Image.new("RGB",(624,804))
        with self.assertRaises(ValueError):export_bundle(str(self.root),"wrong",wrong,wrong,{})
        target=self.image("existing.bmp");original=target.read_bytes()
        with self.assertRaises(ValueError):apply_with_backup(str(target),wrong,self.root/"backups")
        self.assertEqual(target.read_bytes(),original)

    def test_legacy_text_size_keeps_proportion_on_small_output(self):
        layers=default_layers();layers[1]["text"]="CLASS"
        image,boxes=render_portrait(None,layers)
        box=boxes["class"]
        self.assertEqual(image.size,(220,283))
        self.assertAlmostEqual((box[0]+box[2])/2,110,delta=1)
        self.assertLess(box[2]-box[0],120)
        self.assertLess(box[3]-box[1],35)

    def test_prompt_keeps_image_roles_and_no_text(self):
        prompt=compose_prompt("다크나이트","각성","남성","무기","수채화","차분한 표정",True)
        self.assertIn("Image 1",prompt);self.assertIn("Image 2",prompt)
        self.assertIn("Do not draw any text",prompt)


class WorkflowTests(unittest.TestCase):
    def test_binding_preserves_original_and_all_references(self):
        graph=workflow();original=copy.deepcopy(graph)
        prepared=prepare_workflow(graph,BINDINGS,"new prompt","new-base.png","new-ref.png")
        self.assertEqual(prepared["1"]["inputs"]["image"],"new-base.png")
        self.assertEqual(prepared["2"]["inputs"]["image"],"new-ref.png")
        self.assertEqual(prepared["3"]["inputs"]["text"],"new prompt")
        self.assertEqual(original,graph)

    def test_unused_or_missing_reference_fails(self):
        for bindings in [{**BINDINGS,"reference":"6:image"},{**BINDINGS,"reference":""},{**BINDINGS,"reference":"1:image"}]:
            with self.assertRaises(ProviderError):prepare_workflow(workflow(),bindings,"prompt","base","ref")

    def test_frontend_workflow_rejected(self):
        with self.assertRaises(ProviderError):read_workflow({"nodes":[]})


class ProviderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.requests=[];cls.return_image=png_bytes(Image.new("RGB",(100,150),"blue"))
        class FixtureOpener:
            def open(self,request,timeout=60):
                url=urllib.parse.urlsplit(request.full_url);path=url.path+('?' + url.query if url.query else '')
                data=json.loads(request.data) if request.data and 'json' in request.get_header('Content-type','') else request.data
                cls.requests.append((request.method,path,data))
                result={}
                if path.startswith('/models/'):result={'id':path.rsplit('/',1)[-1]}
                elif path=='/system_stats':result={'system':{}}
                elif path=='/history/job':result={'job':{'status':{'completed':True},'outputs':{'5':{'images':[{'filename':'result.png','subfolder':'','type':'output'}]}}}}
                elif path.startswith('/view?'):return io.BytesIO(cls.return_image)
                elif path=='/images/edits':
                    if request.get_header('Authorization')=='Bearer bad-key':
                        raise urllib.error.HTTPError(request.full_url,401,'unauthorized',{},io.BytesIO(json.dumps({'error':{'message':'rejected bad-key'}}).encode()))
                    result={'data':[{'b64_json':base64.b64encode(cls.return_image).decode()}],'created':1}
                elif path=='/upload/image':result={'name':'uploaded.png','subfolder':''}
                elif path=='/prompt':result={'prompt_id':'job'}
                return io.BytesIO(json.dumps(result).encode())
        cls.opener_patch=patch('portrait_studio.providers.urllib.request.build_opener',return_value=FixtureOpener())
        cls.opener_patch.start()
        cls.url='http://127.0.0.1:8188'
    @classmethod
    def tearDownClass(cls):cls.opener_patch.stop()

    def test_openai_request_uses_two_images_and_selected_model(self):
        provider=OpenAIProvider("test-key","selected-image-model",self.url)
        self.assertEqual(provider.check()["model"],"selected-image-model")
        result=provider.generate(Image.new("RGB",(30,40)),Image.new("RGB",(40,50)),"prompt")
        payload=next(body for method,path,body in reversed(self.requests) if path=="/images/edits")
        self.assertEqual(payload["model"],"selected-image-model");self.assertEqual(len(payload["images"]),2)
        self.assertEqual(result.image.size,(100,150))

    def test_api_error_redacts_secret(self):
        with self.assertRaises(ProviderError) as error:OpenAIProvider("bad-key","model",self.url).generate(Image.new("RGB",(10,10)),None,"prompt")
        self.assertNotIn("bad-key",str(error.exception));self.assertIn("401",str(error.exception))

    def test_comfy_upload_bind_queue_and_retrieve(self):
        provider=ComfyProvider(self.url);provider.check()
        result=provider.generate(Image.new("RGB",(30,40)),Image.new("RGB",(40,50)),"new prompt",workflow(),BINDINGS)
        payload=next(body for method,path,body in reversed(self.requests) if path=="/prompt")
        self.assertEqual(payload["prompt"]["3"]["inputs"]["text"],"new prompt")
        self.assertEqual(result.metadata["job_id"],"job")
        self.assertEqual(result.image.size,(100,150))


class UITests(unittest.TestCase):
    def test_native_app_settings_project_and_no_key_persistence(self):
        import tkinter as tk
        from portrait_studio.app import StudioApp
        with tempfile.TemporaryDirectory() as temporary:
            root=tk.Tk();root.withdraw()
            app=StudioApp(root,Path(temporary)/"data")
            root.update_idletasks()
            root.attributes('-alpha',0.0)
            root.geometry('1000x700+0+0');root.deiconify();root.update()
            self.assertTrue(app.preview_actual.get())
            with patch.object(app.canvas,"winfo_width",return_value=600),patch.object(app.canvas,"winfo_height",return_value=600):
                app._render()
                self.assertEqual(app.preview_transform[2],1.0)
            for widget in [app.generate_button,app.export_button,app.canvas]:
                self.assertTrue(widget.winfo_ismapped())
                self.assertLessEqual(widget.winfo_rooty()-root.winfo_rooty()+widget.winfo_height(),root.winfo_height())
            root.withdraw()
            app.api_key="never-write-this-secret"
            app._change_layer("text","테스트 이름")
            folder=Path(temporary)/"그림";folder.mkdir()
            Image.new("RGB",(200,300),"red").save(folder/"다크나이트_각성.png")
            Image.new("RGB",(200,300),"blue").save(folder/"무사_전승.png")
            app._scanned(scan_library(str(folder)))
            self.assertIn("다크나이트_각성",app.base_name.cget("text"))
            app.character.set("무사");app.mode.set("전승");app._select_character()
            self.assertIn("무사_전승",app.base_name.cget("text"))
            self.assertEqual(app.base_image.getpixel((0,0)),(0,0,255))
            app.layers[2]["x"]=33;app.zoom.set(140)
            image,_=app._render_full()
            self.assertEqual(image.size,(220,283))
            bundle=export_bundle(str(Path(temporary)/"export"),"roundtrip",app.base_image,image,app.project_data())
            with patch("portrait_studio.app.filedialog.askopenfilename",return_value=str(bundle/"project.json")):
                app.open_project()
            self.assertEqual(app.result_key,("무사","전승"));self.assertEqual(app.layers[2]["x"],33)
            self.assertEqual(app.zoom.get(),140)
            self.assertEqual(app.result_image.size,(200,300))
            app._save_settings()
            saved=app.config_file.read_text(encoding="utf-8")
            self.assertNotIn(app.api_key,saved)
            root.destroy()


if __name__=="__main__":unittest.main()
