import hashlib
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from PIL import Image

from portrait_studio.core import (LibraryEntry, default_layers, infer_identity, modes_for,
                                 scan_library, validate_entries)
from portrait_studio.providers import compose_prompt
from portrait_studio.updater import (APP_ID, apply_plan, check_release, github_feed,
                                     stage_release, validate_plan)
from portrait_studio.vault import Vault
from portrait_studio.web_tasks import web_prompt


class CatalogTests(unittest.TestCase):
    def test_special_classes_use_opening_or_talent_and_incorrect_modes_are_flagged(self):
        for name in ['오공','스칼라','데드아이','세라핌','아처']:
            self.assertEqual(infer_identity(name+'.png'),(name,'개방'))
            self.assertNotIn('각성',modes_for(name))
        self.assertEqual(infer_identity('샤이.png'),('샤이','재능'))
        entry=LibraryEntry('unused','오공_각성.png','오공','각성')
        self.assertIn('확인 필요',validate_entries([entry])[0].status)
        entry.mode='개방';self.assertEqual(validate_entries([entry])[0].status,'연결 완료')
        self.assertEqual(infer_identity('다크나이트.png'),('다크나이트',''))

    def test_boss_names_are_recognized_and_custom_monsters_survive_backup(self):
        self.assertEqual(infer_identity('가모스.png'),('가모스','기본'))
        self.assertEqual(infer_identity('boss/garmoth.jpg'),('가모스','기본'))
        self.assertEqual(infer_identity('벨_기본.png'),('벨','기본'))
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);folder=root/'originals';folder.mkdir()
            image=folder/'나만의보스.png';Image.new('RGB',(80,100),'red').save(image)
            vault=Vault(root/'computer-a')
            entries=scan_library(str(folder),custom_bosses=['나만의보스'])
            vault.import_entries(entries)
            backup=vault.export_backup(root/'transfer.bdostudio');image.unlink()
            destination=Vault(root/'computer-b');destination.restore_backup(backup)
            restored=destination.entries()[0]
            self.assertEqual((restored.class_name,restored.mode,restored.kind),('나만의보스','기본','보스·몬스터'))
            self.assertEqual(restored.status,'연결 완료')

    def test_boss_generation_prompts_preserve_creature_anatomy(self):
        prompt=compose_prompt('가모스','기본','기본 그림 유지','뿔·날개','화풍','',True,'보스·몬스터')
        self.assertIn('boss/monster',prompt);self.assertIn('do not humanize',prompt)
        self.assertNotIn('Character class:',prompt)
        project=dict(character='가모스',mode='기본',kind='보스·몬스터',controls={})
        prompt=web_prompt(project,True)
        self.assertIn('사람 형태로 바꾸지',prompt);self.assertIn('보스·몬스터 이름: 가모스',prompt)


class UpdateTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.root=Path(self.temporary.name)
        self.install=self.root/'프로그램 폴더';self.install.mkdir()
        (self.install/'run.py').write_text('old runner')
        (self.install/'portrait_studio').mkdir()
        (self.install/'portrait_studio/core.py').write_text('old core')
        self.data=self.install/'StudioData';self.data.mkdir()
        (self.data/'keep.png').write_bytes(b'original data')

    def tearDown(self):self.temporary.cleanup()

    def release(self,members=None):
        archive=self.root/'release.zip'
        members=members or {'app/run.py':b'new runner','app/portrait_studio/core.py':b'new core'}
        with zipfile.ZipFile(archive,'w') as zipped:
            for name,content in members.items():zipped.writestr(name,content)
        package=dict(file=archive.name,size=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
        feed=self.root/'update.json';feed.write_text(json.dumps(dict(app=APP_ID,schema=1,version='1.3.0',notes='bosses and updater',packages={'source':package})))
        return check_release(str(feed),'1.2.0','source')

    def test_manifest_version_comparison_and_github_location(self):
        release=self.release();self.assertTrue(release['available'])
        self.assertFalse(check_release(release['feed'],'1.3.0','source')['available'])
        self.assertEqual(github_feed('gksdhrcks/bdo-portrait-studio'),'https://github.com/gksdhrcks/bdo-portrait-studio/releases/latest/download/update.json')
        with self.assertRaises(ValueError):github_feed('owner/repo/../../secret')
        with self.assertRaises(ValueError):check_release(release['feed'],'1.2.0','windows-x64')

    def test_install_preserves_user_data_and_keeps_previous_program_files(self):
        plan=stage_release(self.release(),self.data,self.install)
        result=apply_plan(plan,wait=False,restart=False)
        self.assertEqual(result['status'],'updated')
        self.assertEqual((self.install/'run.py').read_text(),'new runner')
        self.assertEqual((self.data/'keep.png').read_bytes(),b'original data')
        self.assertEqual((plan.parent/'previous/run.py').read_text(),'old runner')

    def test_bad_download_hash_and_tampered_staging_are_rejected(self):
        release=self.release();release['package']['sha256']='0'*64
        with self.assertRaises(ValueError):stage_release(release,self.data,self.install)
        self.assertEqual((self.install/'run.py').read_text(),'old runner')
        plan=stage_release(self.release(),self.data,self.install)
        (plan.parent/'payload/run.py').write_text('changed')
        with self.assertRaises(ValueError):validate_plan(plan)

    def test_archive_cannot_write_outside_the_app_or_into_the_library(self):
        for invalid in ['app/../outside.py','app/StudioData/keep.png','app/portrait_studio/../../outside.py']:
            release=self.release({'app/run.py':b'new',invalid:b'bad'})
            with self.assertRaises(ValueError):stage_release(release,self.data,self.install)
        self.assertEqual((self.data/'keep.png').read_bytes(),b'original data')

    def test_failed_install_rolls_back_every_changed_program_file(self):
        from portrait_studio import updater
        plan=stage_release(self.release(),self.data,self.install)
        real_replace=updater._replace
        def fail_midway(source,destination):
            if 'payload' in Path(source).parts and Path(source).name=='core.py':raise PermissionError('fixture failure')
            return real_replace(source,destination)
        with patch.object(updater,'_replace',side_effect=fail_midway):
            result=apply_plan(plan,wait=False,restart=False)
        self.assertEqual(result['status'],'failed');self.assertEqual(result['rollback_errors'],[])
        self.assertEqual((self.install/'run.py').read_text(),'old runner')
        self.assertEqual((self.install/'portrait_studio/core.py').read_text(),'old core')
        self.assertEqual((self.data/'keep.png').read_bytes(),b'original data')


class CatalogUITests(unittest.TestCase):
    def test_class_mode_filter_and_boss_import_reopen(self):
        from portrait_studio.app import StudioApp
        from portrait_studio.desktop import create_root
        with tempfile.TemporaryDirectory() as temporary:
            data=Path(temporary);folder=data/'original';folder.mkdir()
            Image.new('RGB',(100,150),'red').save(folder/'오공.png')
            Image.new('RGB',(100,150),'blue').save(folder/'가모스.png')
            root=create_root();root.withdraw()
            try:
                app=StudioApp(root,data/'data');app._scanned(scan_library(str(folder)))
                app.character.set('오공');app.mode.set('각성');app._select_character()
                self.assertEqual(app.mode.get(),'개방');self.assertIsNotNone(app.base_image)
                self.assertEqual(tuple(app.mode_combo.cget('values')),('개방','기본'))
                app.portrait_kind.set('보스·몬스터');app._change_kind()
                self.assertEqual(app.character.get(),'가모스');self.assertEqual(app.mode.get(),'기본')
                self.assertIn('보스 외형',app.preserve.get())
                self.assertEqual(app.project_data()['kind'],'보스·몬스터')
                app.keep_current();app._save_settings()
                app.update_dialog();app.update_window.window.withdraw()
                self.assertEqual(app.update_window.repository.get(),'gksdhrcks/bdo-portrait-studio')
            finally:
                root.update_idletasks();root.destroy()
            root=create_root();root.withdraw()
            try:
                restored=StudioApp(root,data/'data')
                self.assertEqual(restored.character.get(),'가모스')
                self.assertEqual(restored.portrait_kind.get(),'보스·몬스터')
                self.assertEqual(restored.result_metadata['provider'],'기본 그림')
            finally:
                root.update_idletasks();root.destroy()


if __name__=='__main__':unittest.main()
