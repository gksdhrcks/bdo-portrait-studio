import json
import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from PIL import Image

from portrait_studio.core import default_layers, find_fonts, load_image, scan_library
from portrait_studio.desktop import create_root, register_file_drop
from portrait_studio.vault import Vault
from portrait_studio.web_tasks import CHATGPT_URL, PROVIDERS, WebTasks, provider_label, web_prompt


def project():
    return dict(character="다크나이트", mode="각성", layers=default_layers(),
                zoom=140, pan_x=12, pan_y=-8, shade=60,
                controls=dict(gender="남성으로 재해석", preserve="클래스·무기", reference_role="화풍과 색감", prompt="푸른 밤"))


class WebTaskTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.vault = Vault(self.root / "computer-a")
        self.tasks = WebTasks(self.vault)

    def tearDown(self):
        self.temporary.cleanup()

    def test_handoff_has_original_images_and_correct_reference_roles_without_secrets(self):
        settings = project(); settings["api_key"] = "do-not-include"
        base = Image.new("RGB", (240, 360), "red")
        reference = Image.new("RGB", (180, 200), "green")
        task = self.tasks.create(base, reference, settings)
        settings["layers"][1]["text"] = "later edit"
        folder = self.tasks.materialize(task["id"])
        self.assertEqual(load_image(folder / "01_base.png").tobytes(), base.tobytes())
        self.assertEqual(load_image(folder / "02_reference.png").tobytes(), reference.tobytes())
        prompt = (folder / "요청문.txt").read_text(encoding="utf-8")
        for value in ["01_base.png", "02_reference.png", "남성으로 재해석", "화풍과 색감", "푸른 밤", "그리지 마세요"]:
            self.assertIn(value, prompt)
        self.assertNotIn("do-not-include", json.dumps(self.tasks.tasks()))
        self.assertEqual(task["project"]["layers"][1]["text"], "다크나이트")
        self.assertEqual(task["project"]["zoom"], 100)
        self.assertNotIn("02_reference", web_prompt(project(), False))

    def test_pending_task_and_fonts_survive_backup_to_another_computer(self):
        settings = project()
        font = Path(find_fonts()[0])
        copied_font = self.root / ("original-font" + font.suffix)
        copied_font.write_bytes(font.read_bytes())
        for layer in settings["layers"]:
            layer["font"] = str(copied_font)
        task = self.tasks.create(Image.new("RGB", (80, 100), "blue"), None, settings)
        self.vault.set_preference("web_active", task["id"])
        backup = self.vault.export_backup(self.root / "transfer.bdostudio")
        copied_font.unlink()
        destination = Vault(self.root / "computer-b")
        destination.restore_backup(backup)
        service = WebTasks(destination)
        folder = service.materialize(task["id"])
        self.assertTrue(folder.is_relative_to(destination.root))
        self.assertFalse((folder / "02_reference.png").exists())
        result = self.root / "다운로드 결과.png"
        Image.new("RGB", (360, 500), "yellow").save(result)
        identifier = service.import_result(task["id"], result, "웹에서 본 모델")
        record = destination.result(identifier)
        self.assertTrue(Path(record["project"]["layers"][0]["font"]).is_relative_to(destination.root))
        self.assertEqual(record["project"]["generation"]["reported_model"], "웹에서 본 모델")
        self.assertFalse(record["project"]["generation"]["model_verified"])
        self.assertEqual(service.task(task["id"])["result_ids"], [identifier])
        result.unlink()
        self.assertEqual(destination.result(identifier)["image"].size, (360, 500))

    def test_invalid_result_and_unknown_task_do_not_create_results(self):
        task = self.tasks.create(Image.new("RGB", (80, 100)), None, project())
        broken = self.root / "broken.png"; broken.write_text("not an image")
        with self.assertRaises(Exception):
            self.tasks.import_result(task["id"], broken)
        with self.assertRaises(ValueError):
            self.tasks.materialize("../../outside")
        self.assertEqual(self.vault.results(), [])
        self.assertEqual(provider_label("OpenAI"), "OpenAI API")

    def test_drop_parser_preserves_unicode_spaces_and_multiple_paths(self):
        root = tk.Tk(); root.withdraw()
        callbacks = {}; received = []
        try:
            widget = SimpleNamespace(tk=root.tk,
                drop_target_register=lambda *args: None,
                dnd_bind=lambda event, callback: callbacks.update({event: callback}))
            self.assertTrue(register_file_drop(widget, lambda paths: received.append(paths) or True))
            paths = (str(self.root / "한글 폴더" / "결과 그림.png"), str(self.root / "second.png"))
            # Build the native Tcl list representation, including Windows paths.
            data = root.tk.call("format", "%s", paths)
            callbacks["<<Drop>>"](SimpleNamespace(data=data))
            self.assertEqual(received, [list(paths)])
        finally:
            root.update_idletasks()
            root.destroy()

    def test_unavailable_native_library_falls_back_to_a_usable_single_root(self):
        with patch("tkinterdnd2.TkinterDnD._require", side_effect=RuntimeError("unavailable")):
            root = create_root()
        try:
            self.assertTrue(root.dnd_unavailable)
            self.assertEqual(root.tk.call("winfo", "exists", "."), 1)
            self.assertFalse(register_file_drop(tk.Label(root), lambda paths: True))
        finally:
            root.update_idletasks()
            root.destroy()


class WebUITests(unittest.TestCase):
    def test_web_route_prepares_copies_and_imports_into_original_class_without_api(self):
        from portrait_studio.app import StudioApp
        with tempfile.TemporaryDirectory() as temporary:
            data = Path(temporary)
            root = create_root(); root.withdraw()
            try:
                app = StudioApp(root, data / "data")
                originals = data / "originals"; originals.mkdir()
                Image.new("RGB", (160, 240), "red").save(originals / "다크나이트_각성.png")
                Image.new("RGB", (160, 240), "green").save(originals / "무사_전승.png")
                app._scanned(scan_library(str(originals)))
                app.layers[2]["x"] = 32
                app.provider.set("ChatGPT 웹"); app._invalidate_connection()
                self.assertEqual(tuple(app.provider_combo.cget("values")), PROVIDERS)
                with patch.object(app, "_provider", side_effect=AssertionError("Must not call API")):
                    app.generate()
                web = app.web_workspace; web.window.withdraw()
                self.assertTrue(web.task_id)
                self.assertTrue(app.file_drop_enabled)
                self.assertTrue(web.drop_enabled)
                web.copy_prompt()
                self.assertEqual(root.clipboard_get(), app.web_tasks.task(web.task_id)["prompt"])
                with patch("webbrowser.open", return_value=True) as browser:
                    app.check_connection()
                    browser.assert_called_once_with(CHATGPT_URL)
                task_id = web.task_id
                app.character.set("무사"); app.mode.set("전승"); app._select_character()
                app.layers[2]["x"] = 80
                filename = data / "한글 결과 파일.png"
                Image.new("RGB", (300, 400), "blue").save(filename)
                self.assertTrue(web.drop([str(filename)]))
                self.assertEqual(app.current_key(), ("다크나이트", "각성"))
                self.assertEqual(app.layers[2]["x"], 32)
                self.assertEqual(app.result_image.size, (300, 400))
                self.assertEqual(app.view.get(), "AI 결과")
                self.assertEqual(app.result_metadata["task_id"], task_id)
                self.assertEqual(len(app.vault.results()), 1)
                filename.unlink()
                app._save_settings()
                self.assertIn("자동 확인 불가", app.provenance.get())
                with patch("portrait_studio.app.messagebox.showinfo"):
                    self.assertFalse(app.import_web_result(task_id, ["first.png", "second.png"]))
            finally:
                root.update_idletasks()
                root.destroy()

            root = create_root(); root.withdraw()
            try:
                restored = StudioApp(root, data / "data")
                self.assertEqual(restored.provider.get(), "ChatGPT 웹")
                self.assertEqual(restored.result_image.size, (300, 400))
                self.assertEqual(restored.layers[2]["x"], 32)
                restored.open_web_workspace(); restored.web_workspace.window.withdraw()
                self.assertEqual(restored.web_workspace.task_id, task_id)
            finally:
                root.update_idletasks()
                root.destroy()


if __name__ == "__main__":
    unittest.main()
