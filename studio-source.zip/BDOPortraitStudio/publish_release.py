"""Build GitHub Release assets; uploading is handled by the release workflow."""
import argparse
import hashlib
import importlib.metadata
import json
import re
import shutil
import sys
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
VERSION=re.search(r'__version__\s*=\s*"([\d.]+)"',(ROOT/'portrait_studio/__init__.py').read_text(encoding='utf-8')).group(1)
COMMON={'README.md','LICENSE','VERIFICATION.md','portable.txt','RELEASE_NOTES.md'}


def source_files():
    allowed=COMMON|{'run.py','build.py','requirements.txt','start.sh','start.command','start.bat','.gitignore','publish_release.py'}
    for file in ROOT.rglob('*'):
        if not file.is_file():continue
        relative=file.relative_to(ROOT)
        if any(part in {'__pycache__','.venv','build','dist','StudioData','.git'} for part in relative.parts):continue
        if len(relative.parts)==1 and file.name in allowed:yield relative,file
        elif relative.parts[0] in {'portrait_studio','tests'} and len(relative.parts)==2 and file.suffix=='.py':yield relative,file
        elif relative.parts[:2]==('.github','workflows') and file.suffix in {'.yml','.yaml'}:yield relative,file


def add_licenses(folder):
    folder.mkdir(parents=True,exist_ok=True)
    for name in ['pillow','pyinstaller','tkinterdnd2']:
        try:dist=importlib.metadata.distribution(name)
        except importlib.metadata.PackageNotFoundError:continue
        for index,relative in enumerate(dist.files or []):
            if '/licenses/' in str(relative).replace('\\','/'):
                file=Path(dist.locate_file(relative))
                if file.is_file():shutil.copy2(file,folder/(name+'-'+str(index)+'-'+file.name))
        if name=='tkinterdnd2':
            tcl=Path(dist.locate_file('tkinterdnd2/tkdnd/win-x64/tkdnd.tcl'))
            if tcl.is_file():(folder/'TkDND.txt').write_text(tcl.read_text(encoding='utf-8').split('package require Tk',1)[0],encoding='utf-8')
    for file in [Path(sys.base_prefix)/'LICENSE.txt',Path(sys.base_prefix)/'tcl/tcl8.6/license.terms',Path(sys.base_prefix)/'tcl/tk8.6/license.terms']:
        if file.is_file():shutil.copy2(file,folder/(file.parent.name+'-'+file.name))


def make_asset(target,input_dir,output,repository):
    output.mkdir(parents=True,exist_ok=True)
    if target=='source':files=list(source_files())
    else:
        input_dir=Path(input_dir).resolve()
        if target.startswith('macos-'):
            bundle=input_dir/'BDOPortraitStudio.app'
            if not (bundle/'Contents/MacOS/BDOPortraitStudio').is_file():raise ValueError('Missing macOS application bundle')
            files=[(file.relative_to(input_dir),file) for file in bundle.rglob('*') if file.is_file()]
        else:
            executable=input_dir/('BDOPortraitStudio.exe' if target.startswith('windows-') else 'BDOPortraitStudio')
            if not executable.is_file():raise ValueError('Missing application executable')
            files=[(Path(executable.name),executable)]
        files.extend((Path(name),ROOT/name) for name in COMMON if (ROOT/name).is_file())
        license_dir=output/('licenses-'+target);add_licenses(license_dir)
        files.extend((Path('ThirdPartyLicenses')/file.name,file) for file in license_dir.iterdir() if file.is_file())
    filename=f'BDOPortraitStudio-{VERSION}-{target}.zip';archive_path=output/filename
    with zipfile.ZipFile(archive_path,'w',zipfile.ZIP_DEFLATED) as archive:
        seen=set()
        for relative,file in sorted(files,key=lambda item:item[0].as_posix()):
            if relative.as_posix() in seen:continue
            seen.add(relative.as_posix())
            info=zipfile.ZipInfo('BDOPortraitStudio/'+relative.as_posix());info.compress_type=zipfile.ZIP_DEFLATED
            executable=file.suffix in {'.sh','.command'} or file.name=='BDOPortraitStudio'
            info.external_attr=((0o100755 if executable else 0o100644)<<16)
            archive.writestr(info,file.read_bytes())
        info=dict(app='bdo-portrait-studio',version=VERSION,target=target,repository=repository)
        archive.writestr('BDOPortraitStudio/release-info.json',json.dumps(info))
    notes=(ROOT/'RELEASE_NOTES.md').read_text(encoding='utf-8') if (ROOT/'RELEASE_NOTES.md').is_file() else ''
    manifest=dict(app='bdo-portrait-studio',schema=1,version=VERSION,notes=notes,packages={target:dict(file=filename,size=archive_path.stat().st_size,sha256=hashlib.sha256(archive_path.read_bytes()).hexdigest())})
    (output/('update-'+target+'.json')).write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(archive_path)


def merge_assets(parts,output):
    output.mkdir(parents=True,exist_ok=True);manifest=None
    for file in Path(parts).rglob('update-*.json'):
        item=json.loads(file.read_text(encoding='utf-8'))
        if manifest is None:manifest={**item,'packages':{}}
        if item['version']!=manifest['version']:raise ValueError('Cannot mix versions')
        for target,package in item['packages'].items():
            if target in manifest['packages']:raise ValueError('Duplicate target: '+target)
            source=file.parent/package['file']
            if hashlib.sha256(source.read_bytes()).hexdigest()!=package['sha256']:raise ValueError('Invalid artifact hash')
            shutil.copy2(source,output/package['file']);manifest['packages'][target]=package
    if not manifest:raise ValueError('No release parts found')
    (output/'update.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--target');parser.add_argument('--input',type=Path)
    parser.add_argument('--out',type=Path,required=True);parser.add_argument('--repo',default='gksdhrcks/bdo-portrait-studio')
    parser.add_argument('--merge',type=Path);args=parser.parse_args()
    if args.merge:merge_assets(args.merge,args.out)
    else:make_asset(args.target,args.input,args.out,args.repo)
