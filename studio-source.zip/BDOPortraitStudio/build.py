"""Run this on each target OS to build that OS's standalone application."""
import argparse
import subprocess
import sys
import shutil
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument("--out-dir",default="dist")
parser.add_argument("--work-dir",default="build")
args=parser.parse_args()
project=Path(__file__).resolve().parent
command=[sys.executable,"-m","PyInstaller","--noconfirm","--clean","--onefile",
         "--name","BDOPortraitStudio","--distpath",str(Path(args.out_dir).resolve()),
         "--workpath",str(Path(args.work_dir).resolve()),"--specpath",str(Path(args.work_dir).resolve()),
         "--paths",str(project),"--hidden-import","PIL._tkinter_finder","--exclude-module","numpy",
         "--collect-all","tkinterdnd2"]
if sys.platform in {"win32","darwin"}:command.append("--windowed")
command.append(str(project/"run.py"))
subprocess.run(command,check=True,cwd=project)
shutil.copy2(project/"portable.txt",Path(args.out_dir).resolve()/"portable.txt")
