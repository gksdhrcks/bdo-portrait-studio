from __future__ import annotations

import tkinter as tk
import urllib.error
from datetime import datetime
from tkinter import messagebox, ttk

from . import __version__
from .updater import DEFAULT_REPOSITORY, check_release, github_feed, launch_installer, stage_release
from .vault import program_directory


class UpdateWindow:
    def __init__(self, app):
        self.app=app;self.release=None
        self.window=tk.Toplevel(app.root);self.window.title("프로그램 업데이트")
        self.window.geometry("660x460");self.window.minsize(570,420);self.window.transient(app.root)
        panel=ttk.Frame(self.window,padding=18,style="Panel.TFrame");panel.pack(fill="both",expand=True)
        ttk.Label(panel,text="GitHub에서 업데이트",style="Section.TLabel").pack(anchor="w")
        ttk.Label(panel,text=f"현재 버전: {__version__}").pack(anchor="w",pady=(8,12))
        self.repository=tk.StringVar(value=app.vault.preference("update_repository",DEFAULT_REPOSITORY))
        ttk.Label(panel,text="업데이트 저장소").pack(anchor="w")
        ttk.Entry(panel,textvariable=self.repository).pack(fill="x",pady=4)
        ttk.Label(panel,text="공개된 새 버전을 확인하고 이 프로그램 폴더에 적용합니다.\n적용 전에 작업과 자료함을 백업하며 완료 후 앱을 재시작합니다.",style="Muted.TLabel",wraplength=590).pack(anchor="w",pady=(5,10))
        self.note=tk.StringVar(value="업데이트 확인을 눌러 주세요.")
        ttk.Label(panel,textvariable=self.note,wraplength=590).pack(anchor="w",pady=5)
        self.notes=tk.Text(panel,wrap="word",height=6,state="disabled",font=("TkDefaultFont",10))
        self.notes.pack(fill="both",expand=True,pady=5)
        buttons=ttk.Frame(panel,style="Panel.TFrame");buttons.pack(fill="x",pady=(8,0))
        self.check_button=ttk.Button(buttons,text="업데이트 확인",command=self.check)
        self.check_button.pack(side="left")
        self.install_button=ttk.Button(buttons,text="업데이트 적용 및 재시작",state="disabled",command=self.install)
        self.install_button.pack(side="right")

    def check(self):
        if self.app.busy:return
        try:feed=github_feed(self.repository.get().strip())
        except ValueError as exc:self.note.set(str(exc));return
        repository=self.repository.get().strip();self.release=None
        self.install_button.configure(state="disabled")
        self.note.set("GitHub 배포 버전 확인 중…")
        def work(progress):
            try:return check_release(feed,__version__)
            except urllib.error.HTTPError as exc:
                if exc.code==404:raise ValueError("저장소 또는 공개된 배포 파일을 찾지 못했습니다. 첫 GitHub 배포가 완료됐는지 확인해 주세요.") from exc
                raise
        def complete(release):
            self.app.vault.set_preference("update_repository",repository)
            if not self.window.winfo_exists():return
            self.release=release
            self.note.set(f"새 버전 {release['version']}을 사용할 수 있습니다." if release["available"] else f"최신 버전입니다. ({__version__})")
            self.notes.configure(state="normal");self.notes.delete("1.0","end");self.notes.insert("1.0",release["notes"]);self.notes.configure(state="disabled")
            if release["available"]:self.install_button.configure(state="normal")
        self.app._run(work,complete,"GitHub 업데이트 확인 중…")

    def install(self):
        if self.app.busy or not self.release or not self.release["available"]:return
        self.app._save_settings()
        release=self.release
        self.install_button.configure(state="disabled");self.note.set("업데이트를 다운로드하고 검증합니다…")
        def complete(plan):
            self.app._save_settings()
            backup=self.app.data_dir/"updates"/("library-before-"+datetime.now().strftime("%Y%m%d-%H%M%S")+".bdostudio")
            self.app.vault.export_backup(backup)
            try:launch_installer(plan)
            except Exception as exc:
                if self.window.winfo_exists():self.install_button.configure(state="normal")
                messagebox.showerror("업데이트 시작 실패",str(exc),parent=self.app.root);return
            self.app.root.destroy()
        self.app._run(lambda progress:stage_release(release,self.app.data_dir,program_directory(),progress),complete,"업데이트 파일 준비 중…")
