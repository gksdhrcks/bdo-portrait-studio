from __future__ import annotations

import base64
import copy
import json
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass

from .core import load_image, png_bytes


class ProviderError(RuntimeError):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ProviderError("API 주소가 다른 위치로 이동했습니다. 서버 주소를 확인해 주세요.")


class Transport:
    def __init__(self, base_url, api_key=""):
        parsed = urllib.parse.urlsplit(base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.username or parsed.password:
            raise ProviderError("올바른 http 또는 https 서버 주소를 입력해 주세요.")
        if parsed.query or parsed.fragment:
            raise ProviderError("서버 주소에는 쿼리나 # 문자를 넣을 수 없습니다.")
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.opener = urllib.request.build_opener(NoRedirect())

    def request(self, method, path, body=None, content_type="application/json", timeout=60, binary=False):
        headers = {"Accept":"application/json", "User-Agent":"BDOPortraitStudio/1.0"}
        if self.api_key:
            headers["Authorization"] = "Bearer "+self.api_key
        if body is not None:
            headers["Content-Type"] = content_type
            if not isinstance(body, bytes):
                body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(self.base_url+path, data=body, headers=headers, method=method)
        try:
            with self.opener.open(request, timeout=timeout) as response:
                raw = response.read(90_000_001)
            if len(raw) > 90_000_000:
                raise ProviderError("API 응답이 너무 큽니다.")
            return raw if binary else json.loads(raw.decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read(16000).decode("utf-8", errors="replace")
            try:
                error = json.loads(detail)
                detail = str(error.get("error", error))
                if isinstance(error.get("error"), dict):
                    detail = error["error"].get("message", str(error["error"]))
            except ValueError:
                pass
            if self.api_key:
                detail = detail.replace(self.api_key, "[키 숨김]")
            raise ProviderError(f"API 오류 {exc.code}: {detail[:1500]}") from None
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            detail = str(exc)
            if self.api_key:
                detail = detail.replace(self.api_key, "[키 숨김]")
            raise ProviderError("서버에 연결하지 못했습니다: "+detail) from None
        except json.JSONDecodeError:
            raise ProviderError("서버에서 올바른 JSON 응답을 받지 못했습니다.") from None


@dataclass
class GenerationResult:
    image: object
    metadata: dict


def compose_prompt(character, mode, gender, preserve, reference_role, extra, has_reference=False, kind="클래스"):
    if kind=="보스·몬스터":
        prompt=(f"Create a Black Desert boss/monster portrait of {character}. "
                "Image 1 is the primary boss artwork. Preserve its species, silhouette, anatomy and signature features. "
                f"Keep these defining features: {preserve}. Appearance direction: {gender}. "
                "Keep the boss's creature form and do not humanize it unless explicitly requested. "
                "Compose a vertical portrait at approximately 52:67 aspect ratio with space below for labels. "
                "Do not draw any text, captions, letters, logos or watermarks. ")
        if has_reference:prompt+=f"Image 2 is an external reference. Borrow only this aspect: {reference_role}. "
        if extra.strip():prompt+="Additional user instructions: "+extra.strip()
        return prompt
    prompt = (
        "Create a polished Black Desert character portrait using the supplied source images. "
        f"Character class: {character}. Combat specialization: {mode}. "
        "Image 1 is the primary base character artwork. Use this as the foundation, not a generic replacement. "
        f"Preserve these defining features from image 1: {preserve}. "
        f"Appearance/gender direction: {gender}. "
        "Keep the class's recognizable weapon design and visual identity. "
        "Compose one character in a vertical portrait, approximately 52:67 aspect ratio; "
        "keep the face visible, leave some quiet space near the bottom for labels. "
        "Do not draw any text, class names, captions, letters, logos or watermarks. "
    )
    if has_reference:
        prompt += f"Image 2 is an external reference. Borrow only this aspect from it: {reference_role}. "
        prompt += "Keep image 1 as the main character foundation when the references conflict. "
    if extra.strip():
        prompt += "Additional user instructions: "+extra.strip()
    return prompt


class OpenAIProvider:
    def __init__(self, api_key, model="gpt-image-2.5-sunburst", base_url="https://api.openai.com/v1"):
        if not api_key.strip():
            raise ProviderError("연결 설정에서 OpenAI API 키를 입력해 주세요.")
        if not model.strip():
            raise ProviderError("이미지 생성 모델명을 입력해 주세요.")
        self.model = model.strip()
        self.http = Transport(base_url, api_key.strip())

    def check(self):
        result = self.http.request("GET", "/models/"+urllib.parse.quote(self.model, safe=""))
        return {"provider":"OpenAI", "model":result.get("id", self.model),
                "note":"모델 접근 확인. 이미지 생성 권한·잔액은 생성 요청 시 확인됩니다."}

    def generate(self, base_image, reference_image, prompt, quality="high", progress=lambda text:None):
        progress("OpenAI에서 초상화 생성 중…")
        images = [{"image_url":"data:image/png;base64,"+base64.b64encode(png_bytes(base_image)).decode("ascii")}]
        if reference_image is not None:
            images.append({"image_url":"data:image/png;base64,"+base64.b64encode(png_bytes(reference_image)).decode("ascii")})
        result = self.http.request("POST", "/images/edits", {
            "model":self.model, "images":images, "prompt":prompt, "size":"1024x1536",
            "quality":quality, "output_format":"png", "n":1,
        }, timeout=900)
        data = result.get("data", [])
        if not data or not data[0].get("b64_json"):
            raise ProviderError("API가 이미지 데이터를 반환하지 않았습니다.")
        try:
            image = load_image(base64.b64decode(data[0]["b64_json"], validate=True))
        except Exception as exc:
            raise ProviderError("반환된 이미지를 읽을 수 없습니다: "+str(exc)) from None
        return GenerationResult(image, {"provider":"OpenAI", "requested_model":self.model,
                                       "reported_model":result.get("model"), "usage":result.get("usage"),
                                       "created":result.get("created"), "quality":quality})


def read_workflow(data):
    if isinstance(data, dict) and "prompt" in data and isinstance(data["prompt"], dict):
        data = data["prompt"]
    if not isinstance(data, dict) or not data or "nodes" in data:
        raise ProviderError("ComfyUI에서 'API 형식'으로 내보낸 워크플로 JSON이 필요합니다.")
    for node_id, node in data.items():
        if not isinstance(node, dict) or not isinstance(node.get("inputs"), dict) or not node.get("class_type"):
            raise ProviderError(f"노드 {node_id}가 API 형식이 아닙니다.")
    return {str(key):value for key,value in data.items()}


def input_options(workflow, kind):
    choices = []
    for node_id, node in workflow.items():
        title = node.get("_meta", {}).get("title", node["class_type"])
        for name, value in node["inputs"].items():
            if not isinstance(value, str):
                continue
            if kind == "image" and name != "image":
                continue
            if kind == "prompt" and name not in {"text", "prompt", "positive_prompt"}:
                continue
            choices.append((f"{node_id}.{name} · {title}", f"{node_id}:{name}"))
    return choices


def model_names(workflow):
    keys = {"ckpt_name", "unet_name", "model_name", "diffusion_model", "lora_name"}
    return list(dict.fromkeys(value for node in workflow.values() for name,value in node["inputs"].items()
                              if name in keys and isinstance(value,str)))


def prepare_workflow(workflow, bindings, prompt, base_name, reference_name=None):
    graph = copy.deepcopy(read_workflow(workflow))
    output = str(bindings.get("output", ""))
    if output not in graph:
        raise ProviderError("이미지를 저장하는 출력 노드를 선택해 주세요.")
    reachable = set()
    def visit(node_id):
        if node_id in reachable or node_id not in graph:
            return
        reachable.add(node_id)
        for value in graph[node_id]["inputs"].values():
            if isinstance(value,list) and len(value)==2:
                visit(str(value[0]))
    visit(output)
    used = set()
    for role,value in [("base",base_name),("prompt",prompt),("reference",reference_name)]:
        if role=="reference" and value is None:
            continue
        binding = bindings.get(role, "")
        if not isinstance(binding,str) or ":" not in binding:
            raise ProviderError({"base":"기본 그림", "reference":"참조 그림", "prompt":"프롬프트"}[role]+" 입력 위치를 지정해 주세요.")
        node_id, field = binding.split(":",1)
        if node_id not in graph or field not in graph[node_id]["inputs"] or node_id not in reachable:
            raise ProviderError(f"{role} 입력 노드가 선택한 출력에 연결되어 있지 않습니다.")
        if binding in used:
            raise ProviderError("기본 그림, 참조 그림, 프롬프트 입력은 서로 다른 위치여야 합니다.")
        used.add(binding)
        if not isinstance(graph[node_id]["inputs"][field],str):
            raise ProviderError("노드 연결선 대신 직접 입력하는 문자열 항목을 선택해 주세요.")
        graph[node_id]["inputs"][field] = value
    return graph


class ComfyProvider:
    def __init__(self, url="http://127.0.0.1:8188"):
        self.http = Transport(url)

    def check(self):
        stats = self.http.request("GET", "/system_stats")
        if not isinstance(stats,dict) or "system" not in stats:
            raise ProviderError("ComfyUI 서버의 응답이 아닙니다.")
        return {"provider":"ComfyUI", "model":"워크플로에서 선택", "note":"ComfyUI 서버 연결 확인"}

    def upload(self, image, role):
        data = png_bytes(image)
        boundary = "portraitstudio"+secrets.token_hex(16)
        filename = f"portrait-{role}-{secrets.token_hex(8)}.png"
        head = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"image\"; filename=\"{filename}\"\r\n"
                "Content-Type: image/png\r\n\r\n").encode("ascii")
        body = head+data+f"\r\n--{boundary}\r\nContent-Disposition: form-data; name=\"type\"\r\n\r\ninput\r\n--{boundary}--\r\n".encode("ascii")
        response = self.http.request("POST", "/upload/image", body, "multipart/form-data; boundary="+boundary)
        if not response.get("name"):
            raise ProviderError("ComfyUI에 이미지를 올리지 못했습니다.")
        return (response.get("subfolder", "").strip("/")+"/"+response["name"]).lstrip("/")

    def generate(self, base_image, reference_image, prompt, workflow, bindings, progress=lambda text:None, timeout=900):
        prepare_workflow(workflow,bindings,prompt,"validation-base.png","validation-reference.png" if reference_image is not None else None)
        progress("ComfyUI에 기본 그림 업로드 중…")
        base = self.upload(base_image,"base")
        reference = self.upload(reference_image,"reference") if reference_image is not None else None
        graph = prepare_workflow(workflow,bindings,prompt,base,reference)
        response = self.http.request("POST", "/prompt", {"prompt":graph, "client_id":secrets.token_hex(16)})
        if response.get("error") or response.get("node_errors"):
            raise ProviderError("ComfyUI 워크플로 오류: "+json.dumps(response,ensure_ascii=False)[:1800])
        job_id = response.get("prompt_id")
        if not job_id:
            raise ProviderError("ComfyUI가 작업 번호를 반환하지 않았습니다.")
        start = time.monotonic()
        while time.monotonic()-start < timeout:
            progress("ComfyUI 생성 중 · 작업 "+str(job_id)[:12])
            history = self.http.request("GET", "/history/"+urllib.parse.quote(str(job_id),safe=""))
            job = history.get(str(job_id))
            if job:
                state = job.get("status",{})
                if state.get("status_str")=="error":
                    raise ProviderError("ComfyUI 생성 실패: "+json.dumps(state.get("messages",[]),ensure_ascii=False)[:1800])
                images = job.get("outputs",{}).get(str(bindings["output"]),{}).get("images",[])
                if images:
                    image = images[0]
                    query = urllib.parse.urlencode({key:image.get(key,"") for key in ["filename","subfolder","type"]})
                    raw = self.http.request("GET", "/view?"+query,binary=True)
                    return GenerationResult(load_image(raw), {"provider":"ComfyUI", "models":model_names(graph),
                        "server":self.http.base_url, "job_id":job_id, "bindings":bindings})
                if state.get("completed"):
                    raise ProviderError("작업이 완료됐지만 선택한 출력 노드에서 이미지를 찾지 못했습니다.")
            time.sleep(1)
        raise ProviderError("ComfyUI 결과 대기 시간이 초과됐습니다. 서버에서는 작업이 계속될 수 있습니다.")
