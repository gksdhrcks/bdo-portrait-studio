from __future__ import annotations

import argparse
import copy
import json
import os
import queue
import sys
import threading
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import colorchooser, filedialog, messagebox, ttk

from PIL import Image, ImageTk

from . import __version__
from .core import (CLASS_ALIASES, BOSS_ALIASES, MODE_ALIASES, SIZE, LibraryEntry, apply_with_backup, atomic_json,
                   data_directory, default_layers, export_bundle, find_fonts,
                   load_image, render_portrait, scan_library, validate_entries,
                   default_mode, infer_identity, modes_for, subject_kind)
from .providers import (ComfyProvider, OpenAIProvider, ProviderError, compose_prompt,
                        input_options, model_names, prepare_workflow, read_workflow)
from .vault import Vault, select_data_directory
from .desktop import create_root, open_folder, register_file_drop
from .web_tasks import CHATGPT_URL, PROVIDERS, WebTasks, provider_label

IMAGE_TYPES = [("그림 파일", "*.png *.jpg *.jpeg *.webp *.bmp"), ("모든 파일", "*")]


class ScrollPanel(ttk.Frame):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self.canvas = tk.Canvas(self, highlightthickness=0, background="#ffffff", width=285)
        scroll = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.body = ttk.Frame(self.canvas, padding=14, style="Panel.TFrame")
        window = self.canvas.create_window((0,0), window=self.body, anchor="nw")
        self.body.bind("<Configure>", lambda e:self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e:self.canvas.itemconfigure(window,width=e.width))
        self.canvas.configure(yscrollcommand=scroll.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right",fill="y")
        def wheel(event):
            if event.num == 4:
                amount = -3
            elif event.num == 5:
                amount = 3
            else:
                amount = -int(event.delta/120) if abs(event.delta)>=120 else (-1 if event.delta>0 else 1)
            self.canvas.yview_scroll(amount,"units")
            return "break"
        self.canvas.bind("<MouseWheel>",wheel)
        if sys.platform not in {"win32","darwin"}:
            self.canvas.bind("<Button-4>",wheel)
            self.canvas.bind("<Button-5>",wheel)


class StudioApp:
    def __init__(self, root: tk.Tk, data_dir: Path | None = None):
        self.root = root
        self.data_dir = select_data_directory(data_dir)
        self.data_dir.mkdir(parents=True,exist_ok=True)
        self.vault=Vault(self.data_dir)
        self.web_tasks=WebTasks(self.vault)
        self.config_file = self.data_dir/"settings.json"
        try:
            self.saved = json.loads(self.config_file.read_text(encoding="utf-8")) if self.config_file.exists() else {}
            if not isinstance(self.saved,dict): self.saved={}
        except (ValueError,OSError):
            self.saved={}
        self.saved=self.vault.load_preferences() or self.saved
        self.api_key = os.environ.get("OPENAI_API_KEY", "")
        incoming_ai=self.saved.get("ai",{})
        if not isinstance(incoming_ai,dict):incoming_ai={}
        defaults={"model":"gpt-image-2.5-sunburst","quality":"high","comfy_url":"http://127.0.0.1:8188","workflow":"","bindings":{}}
        self.ai={key:copy.deepcopy(incoming_ai.get(key,value)) for key,value in defaults.items()}
        if not isinstance(self.ai["bindings"],dict):self.ai["bindings"]={}
        self.entries=[]
        self.overrides=self.saved.get("library_overrides",{})
        self.custom_classes=self.saved.get("custom_classes",[])
        self.custom_bosses=self.vault.preference("custom_bosses",self.saved.get("custom_bosses",[]))
        self.base_image=None
        self.base_path=""
        self.reference_image=None
        self.reference_path=""
        self.reference_asset=""
        self.reference_label=""
        self.result_image=None
        self.result_key=None
        self.result_metadata={}
        self.result_id=None
        self.editor_key=None
        self.suspend_save=False
        self.fonts=find_fonts()
        self.layers=default_layers(self.fonts[0] if self.fonts else "")
        for saved_layer in self.saved.get("layers",[]):
            if isinstance(saved_layer,dict):
                for layer in self.layers:
                    if layer["id"]==saved_layer.get("id"):
                        for field in ["font","font_name","color","size","x","y","stroke","text"]:
                            if field in saved_layer: layer[field]=saved_layer[field]
        self.messages=queue.Queue()
        self.busy=False
        self.verified=None
        self.ready=False
        self.render_pending=None
        self.save_pending=None
        self.preview_boxes={}
        self.preview_transform=(0,0,1)
        self.drag=None
        self._photos={}
        self.provider=tk.StringVar(value=provider_label(self.saved.get("provider","ChatGPT 웹")))
        self.character=tk.StringVar(value=self.saved.get("character","다크나이트"))
        self.portrait_kind=tk.StringVar(value=subject_kind(self.character.get(),self.custom_bosses))
        self.mode=tk.StringVar(value=self.saved.get("mode","각성"))
        self.folder=tk.StringVar(value=self.saved.get("folder",""))
        self.output=tk.StringVar(value=self.saved.get("output",""))
        if self.output.get() and not Path(self.output.get()).is_dir():self.output.set("")
        self.gender=tk.StringVar(value=self.saved.get("gender","기본 그림 유지"))
        self.preserve=tk.StringVar(value=self.saved.get("preserve","클래스·무기·의상"))
        self.reference_role=tk.StringVar(value=self.saved.get("reference_role","화풍과 색감"))
        self.view=tk.StringVar(value="기본 그림")
        self.preview_actual=tk.BooleanVar(value=self.saved.get("preview_actual",True))
        self.selected_layer=tk.StringVar(value="class")
        self.layer_text=tk.StringVar()
        self.layer_font=tk.StringVar()
        self.layer_size=tk.DoubleVar(value=54)
        self.layer_x=tk.DoubleVar(value=50)
        self.layer_y=tk.DoubleVar(value=81)
        self.layer_stroke=tk.DoubleVar(value=1)
        self.zoom=tk.DoubleVar(value=100)
        self.pan_x=tk.DoubleVar(value=0)
        self.pan_y=tk.DoubleVar(value=0)
        self.shade=tk.DoubleVar(value=65)
        self.ai_status=tk.StringVar(value="현재 연결된 AI: 없음 · 미연결")
        self.provenance=tk.StringVar(value="생성에 사용한 AI: —")
        self.status=tk.StringVar(value="기본 그림을 추가하고, 상단에서 생성 방식을 선택하세요. 웹 방식은 API 키가 필요 없습니다.")
        self.library_status=tk.StringVar(value="폴더 미선택")
        self._build()
        self.ready=True
        self._update_provider_ui()
        self._load_layer_controls()
        self.entries=self.vault.entries()
        self._refresh_library()
        self.root.after(70,self._poll)
        self.root.protocol("WM_DELETE_WINDOW",self.close)
        if not self.entries and self.folder.get() and Path(self.folder.get()).is_dir():self.root.after(150,self.rescan)
        if self.saved.get("reference_asset") and not self.reference_asset:
            self._restore_reference(self.saved["reference_asset"],self.saved.get("reference_label","보관된 참조 그림"))
        if self.entries or self.vault.results():self.status.set("자료함을 불러왔습니다. 원본 폴더 없이 기본 그림과 보관 결과를 사용할 수 있습니다.")
        update_status=self.data_dir/"update-status.json"
        if update_status.is_file():
            try:
                report=json.loads(update_status.read_text(encoding="utf-8"))
                if report.get("status")=="updated":self.status.set("프로그램 업데이트 완료 · 현재 버전 "+__version__)
                elif report.get("status")=="failed":self.status.set("업데이트 실패 · 이전 버전 복원: "+str(report.get("message","")))
            except (OSError,ValueError):pass

    def update_dialog(self):
        if self.busy:return
        existing=getattr(self,"update_window",None)
        if existing and existing.window.winfo_exists():existing.window.lift();return
        from .update_ui import UpdateWindow
        self.update_window=UpdateWindow(self)

    def _build(self):
        self.root.title(f"검은사막 초상화 스튜디오 {__version__}")
        width=min(1280,self.root.winfo_screenwidth()-60)
        height=min(900,self.root.winfo_screenheight()-100)
        self.root.geometry(f"{max(980,width)}x{max(660,height)}")
        self.root.minsize(980,660)
        self.root.configure(background="#f5f4f0")
        style=ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("TFrame",background="#f5f4f0")
        style.configure("Panel.TFrame",background="#ffffff")
        style.configure("TLabel",background="#ffffff",foreground="#292e35",font=("TkDefaultFont",10))
        style.configure("Title.TLabel",background="#f5f4f0",font=("TkDefaultFont",16,"bold"))
        style.configure("Section.TLabel",foreground="#785728",font=("TkDefaultFont",11,"bold"))
        style.configure("Muted.TLabel",foreground="#5d6570",font=("TkDefaultFont",9))
        style.configure("TButton",padding=(9,6))
        style.configure("TCombobox",padding=5)
        style.configure("TEntry",padding=5)
        style.configure("Treeview",rowheight=28,font=("TkDefaultFont",10))
        style.configure("Treeview.Heading",font=("TkDefaultFont",10,"bold"))
        menu=tk.Menu(self.root)
        file_menu=tk.Menu(menu,tearoff=False)
        file_menu.add_command(label="프로젝트 열기…",command=self.open_project)
        file_menu.add_command(label="템플릿 저장…",command=self.save_template)
        file_menu.add_command(label="템플릿 불러오기…",command=self.load_template)
        file_menu.add_separator()
        file_menu.add_command(label="게임 초상화에 적용…",command=self.apply_game)
        file_menu.add_command(label="최근 게임 적용 복원…",command=self.restore_game)
        file_menu.add_separator()
        file_menu.add_command(label="종료",command=self.close)
        menu.add_cascade(label="파일",menu=file_menu)
        vault_menu=tk.Menu(menu,tearoff=False)
        vault_menu.add_command(label="보관된 결과 보기…",command=self.results_dialog)
        vault_menu.add_command(label="자료함 백업 내보내기…",command=self.export_vault)
        vault_menu.add_command(label="자료함 백업 가져오기…",command=self.import_vault)
        vault_menu.add_separator()
        vault_menu.add_command(label="자료함 폴더 열기",command=self.open_vault_folder)
        menu.add_cascade(label="자료함",menu=vault_menu)
        options=tk.Menu(menu,tearoff=False)
        options.add_command(label="업데이트 확인…",command=self.update_dialog)
        menu.add_cascade(label="옵션",menu=options)
        menu.add_command(label="사용 안내",command=self.help)
        self.root.configure(menu=menu)
        heading=ttk.Frame(self.root,padding=(16,12))
        heading.pack(fill="x")
        ttk.Label(heading,text="검은사막 초상화 스튜디오",style="Title.TLabel").pack(side="left")
        ttk.Label(heading,text="기본 그림 + 참조 그림 → AI 생성 → 글자 편집",background="#f5f4f0").pack(side="right")
        top=ttk.Frame(self.root,padding=(14,9),style="Panel.TFrame")
        top.pack(fill="x")
        ttk.Label(top,text="생성 방식").pack(side="left",padx=(0,8))
        self.provider_combo=ttk.Combobox(top,textvariable=self.provider,values=PROVIDERS,width=14,state="readonly")
        self.provider_combo.pack(side="left")
        self.provider_combo.bind("<<ComboboxSelected>>",lambda e:self._invalidate_connection())
        self.settings_button=ttk.Button(top,text="AI 연결 설정",command=self.connection_settings)
        self.settings_button.pack(side="left",padx=8)
        self.connect_button=ttk.Button(top,text="연결 확인",command=self.check_connection)
        self.connect_button.pack(side="left")
        ttk.Label(top,textvariable=self.ai_status,style="Muted.TLabel",wraplength=520).pack(side="right",padx=8)
        library=ttk.Frame(self.root,padding=(14,9),style="Panel.TFrame")
        library.pack(fill="x",pady=(1,0))
        ttk.Label(library,text="기본 그림 추가").pack(side="left",padx=(0,8))
        ttk.Entry(library,textvariable=self.folder,state="readonly").pack(side="left",fill="x",expand=True)
        self.folder_button=ttk.Button(library,text="폴더 선택…",command=self.choose_folder)
        self.folder_button.pack(side="left",padx=6)
        ttk.Button(library,text="그림 한 장 추가…",command=self.add_portrait).pack(side="left",padx=(0,6))
        ttk.Button(library,text="파일 연결 확인…",command=self.library_dialog).pack(side="left")
        ttk.Button(library,text="보관된 결과…",command=self.results_dialog).pack(side="left",padx=(6,0))
        summary=ttk.Frame(self.root,padding=(14,2),style="Panel.TFrame")
        summary.pack(fill="x")
        ttk.Label(summary,textvariable=self.library_status,style="Muted.TLabel").pack(anchor="w")
        footer=ttk.Frame(self.root)
        footer.pack(side="bottom",fill="x")
        body=ttk.Frame(self.root)
        body.pack(fill="both",expand=True,pady=7,padx=10)
        body.columnconfigure(0,weight=0,minsize=300)
        body.columnconfigure(1,weight=1,minsize=280)
        body.columnconfigure(2,weight=0,minsize=290)
        body.rowconfigure(0,weight=1)
        left=ScrollPanel(body)
        left.grid(row=0,column=0,sticky="nsew",padx=(0,6))
        panel=left.body
        self._section(panel,"기본 그림")
        self.kind_combo=self._combo(panel,"초상화 종류",self.portrait_kind,["클래스","보스·몬스터"])
        self.kind_combo.bind("<<ComboboxSelected>>",lambda e:self._change_kind())
        self.class_combo=self._combo(panel,"클래스 / 보스·몬스터",self.character,list(CLASS_ALIASES)+self.custom_classes)
        self.class_combo.bind("<<ComboboxSelected>>",lambda e:self._select_character())
        self.mode_combo=self._combo(panel,"전투계열 / 그림 유형",self.mode,modes_for(self.character.get()))
        self.mode_combo.bind("<<ComboboxSelected>>",lambda e:self._select_character())
        self.base_thumb=ttk.Label(panel,text="기본 그림 미등록",anchor="center")
        self.base_thumb.pack(fill="x",pady=6)
        self.base_name=ttk.Label(panel,text="클래스와 전투계열에 연결된 그림 없음",style="Muted.TLabel",wraplength=260)
        self.base_name.pack(fill="x",pady=(0,8))
        self._section(panel,"외부 참조 그림")
        actions=ttk.Frame(panel,style="Panel.TFrame")
        actions.pack(fill="x")
        self.reference_button=ttk.Button(actions,text="그림 가져오기…",command=self.choose_reference)
        self.reference_button.pack(side="left")
        ttk.Button(actions,text="제거",command=self.clear_reference).pack(side="left",padx=5)
        self.reference_thumb=ttk.Label(panel,text="선택한 참조 그림 없음",anchor="center")
        self.reference_thumb.pack(fill="x",pady=7)
        self.reference_name=ttk.Label(panel,text="",style="Muted.TLabel",wraplength=260)
        self.reference_name.pack(fill="x")
        self._combo(panel,"이 그림에서 참고할 것",self.reference_role,["화풍과 색감","얼굴과 외형","의상과 장식","포즈와 구도"])
        self._combo(panel,"그림 속 젠더",self.gender,["기본 그림 유지","남성으로 재해석","여성으로 재해석"])
        self.preserve_combo=self._combo(panel,"유지할 특징",self.preserve,["클래스·무기·의상","클래스·무기","클래스 분위기"])
        ttk.Label(panel,text="추가 요청").pack(anchor="w",pady=(8,3))
        self.extra=tk.Text(panel,height=4,wrap="word",font=("TkDefaultFont",10),relief="solid",borderwidth=1)
        self.extra.pack(fill="x")
        self.extra.insert("1.0",self.saved.get("prompt",""))
        center=ttk.Frame(body,padding=10)
        center.grid(row=0,column=1,sticky="nsew")
        self.preview_title=ttk.Label(center,text="미리보기 · 220 × 283",background="#f5f4f0")
        self.preview_title.pack(anchor="w")
        self.canvas=tk.Canvas(center,background="#252b34",highlightthickness=0,width=280,height=440)
        self.canvas.bind("<Configure>",lambda e:self.schedule_render())
        self.canvas.bind("<ButtonPress-1>",self._drag_start)
        self.canvas.bind("<B1-Motion>",self._drag_move)
        self.canvas.bind("<ButtonRelease-1>",lambda e:setattr(self,"drag",None))
        self.canvas.bind("<KeyPress>",self._move_key)
        self.file_drop_enabled=register_file_drop(self.canvas,self._drop_web_result)
        preview_controls=ttk.Frame(center)
        preview_controls.pack(side="bottom",fill="x")
        ttk.Checkbutton(preview_controls,text="실제 크기 보기 · 최대 100%",variable=self.preview_actual,
                        command=self.schedule_render).pack(anchor="w")
        views=ttk.Frame(preview_controls)
        views.pack(fill="x")
        for text in ["기본 그림","AI 결과"]:
            ttk.Radiobutton(views,text=text,variable=self.view,value=text,command=self.schedule_render).pack(side="left",padx=6)
        self.generate_button=ttk.Button(preview_controls,text="AI로 초상화 생성",command=self.generate)
        self.generate_button.pack(fill="x",pady=8)
        ttk.Button(preview_controls,text="현재 편집본을 자료함에 보관",command=self.keep_current).pack(fill="x",pady=(0,7))
        ttk.Label(preview_controls,textvariable=self.provenance,style="Muted.TLabel",background="#f5f4f0",wraplength=300).pack(fill="x")
        self.canvas.pack(fill="both",expand=True,pady=7)
        right=ScrollPanel(body)
        right.grid(row=0,column=2,sticky="nsew",padx=(6,0))
        panel=right.body
        self._section(panel,"글자 편집")
        self.layer_labels={"클래스·보스 이름":"class","전투계열·종류":"mode","추가 글자":"name"}
        self.layer_selection=tk.StringVar(value="클래스·보스 이름")
        selection=self._combo(panel,"편집할 레이어",self.layer_selection,list(self.layer_labels))
        selection.bind("<<ComboboxSelected>>",lambda e:self._select_layer(self.layer_labels[self.layer_selection.get()]))
        ttk.Label(panel,text="표시할 글자").pack(anchor="w",pady=(8,3))
        ttk.Entry(panel,textvariable=self.layer_text).pack(fill="x")
        self.layer_text.trace_add("write",lambda *_:self._change_layer("text",self.layer_text.get()))
        labels={}
        for path in self.fonts:
            label=Path(path).name
            if label in labels: label+=f" [{len(labels)}]"
            labels[label]=path
        self.font_map=labels
        self.font_combo=self._combo(panel,"폰트 파일",self.layer_font,list(labels))
        self.font_combo.bind("<<ComboboxSelected>>",lambda e:self._change_layer("font",self.font_map[self.layer_font.get()]))
        ttk.Button(panel,text="다른 폰트 파일…",command=self.choose_font).pack(fill="x",pady=5)
        self.color_button=ttk.Button(panel,text="글자 색 선택",command=self.choose_color)
        self.color_button.pack(fill="x")
        for label,var,field,minimum,maximum in [
            ("글자 크기",self.layer_size,"size",10,130),("가로 위치 %",self.layer_x,"x",0,100),
            ("세로 위치 %",self.layer_y,"y",0,100),("외곽선 두께",self.layer_stroke,"stroke",0,6)]:
            self._slider(panel,label,var,minimum,maximum,lambda value,f=field:self._change_layer(f,float(value)))
        self._section(panel,"그림 구도")
        for label,var,minimum,maximum in [("확대 %",self.zoom,100,250),("가로 구도",self.pan_x,-100,100),
                                            ("세로 구도",self.pan_y,-100,100),("하단 어둡게",self.shade,0,100)]:
            self._slider(panel,label,var,minimum,maximum,lambda value:self.schedule_render())
        bottom=ttk.Frame(footer,padding=(14,8),style="Panel.TFrame")
        bottom.pack(fill="x")
        ttk.Label(bottom,text="저장 폴더").pack(side="left",padx=(0,8))
        ttk.Entry(bottom,textvariable=self.output,state="readonly").pack(side="left",fill="x",expand=True)
        ttk.Button(bottom,text="선택…",command=self.choose_output).pack(side="left",padx=5)
        self.export_button=ttk.Button(bottom,text="BMP · PNG · 프로젝트 저장",command=self.export)
        self.export_button.pack(side="left")
        self.progress=ttk.Progressbar(footer,mode="indeterminate")
        self.progress.pack(fill="x")
        ttk.Label(footer,textvariable=self.status,background="#f5f4f0",wraplength=900,padding=(12,5)).pack(fill="x")

    def _section(self,parent,text):
        ttk.Label(parent,text=text,style="Section.TLabel").pack(anchor="w",pady=(12,7))

    def _combo(self,parent,label,variable,values):
        ttk.Label(parent,text=label).pack(anchor="w",pady=(7,3))
        combo=ttk.Combobox(parent,textvariable=variable,values=values,state="readonly",width=22)
        combo.pack(fill="x")
        return combo

    def _slider(self,parent,label,variable,minimum,maximum,command):
        row=ttk.Frame(parent,style="Panel.TFrame")
        row.pack(fill="x",pady=(7,0))
        ttk.Label(row,text=label).pack(side="left")
        number=ttk.Label(row,text=f"{variable.get():.1f}",style="Muted.TLabel")
        number.pack(side="right")
        def changed(value):
            number.configure(text=f"{float(value):.1f}")
            command(value)
        ttk.Scale(parent,from_=minimum,to=maximum,variable=variable,command=changed).pack(fill="x")
        variable.trace_add("write",lambda *_:number.configure(text=f"{variable.get():.1f}"))

    def current_key(self): return self.character.get(),self.mode.get()

    def _entry(self):
        return next((e for e in self.entries if e.status=="연결 완료" and (e.class_name,e.mode)==self.current_key()),None)

    def _subject_names(self,kind):
        names=[*CLASS_ALIASES,*BOSS_ALIASES,*self.custom_classes,*self.custom_bosses,
               *[entry.class_name for entry in self.entries if entry.class_name]]
        return [name for name in dict.fromkeys(names) if subject_kind(name,self.custom_bosses)==kind]

    def _change_kind(self):
        names=self._subject_names(self.portrait_kind.get())
        if names:self.character.set(names[0])
        self._select_character()

    def _select_character(self,restore=True):
        if not self.ready:return
        kind=subject_kind(self.character.get(),self.custom_bosses)
        self.portrait_kind.set(kind)
        self.class_combo.configure(values=self._subject_names(kind))
        choices=modes_for(self.character.get(),kind)
        self.mode_combo.configure(values=choices)
        if self.mode.get() not in choices:self.mode.set(choices[0])
        key=self.current_key()
        changed=self.editor_key!=key
        if changed and self.editor_key:self._save_session(self.editor_key)
        self.editor_key=key
        self.layers[0]["text"]=self.mode.get()
        self.layers[1]["text"]=self.character.get()
        entry=self._entry()
        if entry and self.base_path!=entry.path:
            try:self.base_image=load_image(entry.path);self.base_path=entry.path
            except Exception as exc:self.base_image=None;self.base_path="";self.status.set("기본 그림을 읽을 수 없습니다: "+str(exc))
            self.zoom.set(100);self.pan_x.set(0);self.pan_y.set(0)
        elif not entry:self.base_image=None;self.base_path=""
        self._thumbnail(self.base_thumb,self.base_image,"base")
        self.base_name.configure(text=entry.relative if entry else "연결된 기본 그림 없음 · 파일 연결 확인에서 지정")
        if self.result_key!=key:
            self.view.set("기본 그림");self.result_key=None;self.result_image=None;self.result_id=None
            self.provenance.set("생성에 사용한 AI: —")
        if changed and restore:
            draft=self.vault.draft(key)
            results=self.vault.results(key)
            identifier=draft.get("result_id") if draft else None
            if not identifier and results:identifier=results[0]["id"]
            if identifier:
                try:self._read_result(identifier,apply_editor=not bool(draft))
                except (ValueError,OSError):pass
            if kind=="보스·몬스터" and not draft and not identifier:
                self.layers[0]["text"]="보스·몬스터";self.layers[2]["text"]=""
            if draft:
                try:
                    self._apply_template(draft["project"])
                    self._apply_project_controls(draft["project"])
                    self.view.set(draft.get("view","기본 그림") if self.result_image is not None else "기본 그림")
                    self._restore_reference(draft["project"].get("reference_asset",""),draft["project"].get("reference_label",""))
                except (ValueError,OSError):pass
        preserve=["보스 외형·뿔·날개","보스 외형","보스 분위기"] if kind=="보스·몬스터" else ["클래스·무기·의상","클래스·무기","클래스 분위기"]
        self.preserve_combo.configure(values=preserve)
        if self.preserve.get() not in preserve:self.preserve.set(preserve[0])
        self._load_layer_controls()
        self.schedule_render()

    def _thumbnail(self,label,image,key):
        if image is None:
            label.configure(image="",text="그림 없음")
            self._photos.pop(key,None)
        else:
            thumb=image.copy();thumb.thumbnail((100,100),Image.Resampling.LANCZOS)
            self._photos[key]=ImageTk.PhotoImage(thumb)
            label.configure(image=self._photos[key],text="")

    def choose_folder(self):
        if self.busy:return
        folder=filedialog.askdirectory(parent=self.root,title="기본 그림이 들어 있는 폴더 선택",initialdir=self.folder.get() or None)
        if folder:self.folder.set(folder);self.rescan()

    def rescan(self):
        if self.busy or not self.folder.get():return
        folder=self.folder.get()
        def work(progress):
            progress("기본 그림을 자료함에 복사 중…")
            return self.vault.import_entries(scan_library(folder,self.overrides,self.custom_classes,self.custom_bosses))
        self._run(work,self._scanned,"그림 폴더 확인 중…")

    def _scanned(self,entries):
        self.entries=entries if all(entry.asset_id for entry in entries) else self.vault.import_entries(entries)
        self._refresh_library()
        missing=sum(e.status not in {"연결 완료","사용 제외"} for e in entries)
        self.status.set(f"자료함에 기본 그림을 보관했습니다. 직접 확인이 필요한 파일: {missing}개")
        if missing:self.library_dialog()

    def _refresh_library(self):
        validate_entries(self.entries)
        self.vault.update_entries(self.entries)
        valid=[e for e in self.entries if e.status=="연결 완료"]
        issues=[e for e in self.entries if e.status not in {"연결 완료","사용 제외"}]
        self.library_status.set(f"자료함 기본 그림 {len(self.entries)}개 · 연결 {len(valid)}개 · 확인 필요 {len(issues)}개 · 보관 결과 {len(self.vault.results())}개")
        if valid and not self._entry():self.character.set(valid[0].class_name);self.mode.set(valid[0].mode)
        self._select_character()
        self.schedule_save()

    def library_dialog(self):
        if self.busy:return
        if getattr(self,"library_window",None) and self.library_window.winfo_exists():
            self.library_window.lift();return
        window=tk.Toplevel(self.root);self.library_window=window
        window.title("기본 그림 파일 연결 확인")
        window.transient(self.root);window.grab_set()
        window.geometry("1000x570");window.minsize(800,500)
        ttk.Label(window,text="파일명 또는 하위 폴더로 분류합니다. 인식하지 못한 파일은 직접 지정하세요.",padding=12).pack(fill="x")
        holder=ttk.Frame(window,padding=10);holder.pack(fill="both",expand=True)
        columns=("file","class","mode","status")
        tree=ttk.Treeview(holder,columns=columns,show="headings",selectmode="browse")
        for name,title,width in [("file","파일",350),("class","클래스·보스",110),("mode","전투계열·종류",90),("status","상태",250)]:
            tree.heading(name,text=title);tree.column(name,width=width,minwidth=70)
        scroll=ttk.Scrollbar(holder,orient="vertical",command=tree.yview);tree.configure(yscrollcommand=scroll.set)
        tree.pack(side="left",fill="both",expand=True);scroll.pack(side="right",fill="y")
        edit=ttk.Frame(window,padding=12,style="Panel.TFrame");edit.pack(fill="x")
        photo=ttk.Label(edit,text="선택한 파일 미리보기");photo.grid(row=0,column=0,rowspan=3,padx=(0,12))
        c=tk.StringVar();m=tk.StringVar();skip=tk.BooleanVar();kind=tk.StringVar(value="클래스")
        ttk.Label(edit,text="클래스 / 보스 이름 · 직접 입력 가능").grid(row=0,column=1,sticky="w")
        ttk.Label(edit,text="전투계열 · 직접 입력 가능").grid(row=0,column=2,sticky="w",padx=10)
        names=ttk.Combobox(edit,textvariable=c,values=list(CLASS_ALIASES)+list(BOSS_ALIASES)+self.custom_classes+self.custom_bosses,width=20)
        names.grid(row=1,column=1,sticky="ew")
        modes=ttk.Combobox(edit,textvariable=m,values=list(MODE_ALIASES),width=15,state="readonly")
        modes.grid(row=1,column=2,padx=10,sticky="ew")
        ttk.Label(edit,text="초상화 종류").grid(row=3,column=1,sticky="w")
        kinds=ttk.Combobox(edit,textvariable=kind,values=["클래스","보스·몬스터"],state="readonly",width=15)
        kinds.grid(row=3,column=2,padx=10,sticky="ew")
        def mode_choices(event=None):
            options=modes_for(c.get(),kind.get());modes.configure(values=options)
            if m.get() not in options:m.set(options[0])
        def name_changed(event=None):
            kind.set(subject_kind(c.get(),self.custom_bosses));mode_choices()
        names.bind("<<ComboboxSelected>>",name_changed);names.bind("<FocusOut>",name_changed)
        kinds.bind("<<ComboboxSelected>>",mode_choices)
        ttk.Checkbutton(edit,text="사용 제외",variable=skip).grid(row=1,column=3)
        detail=ttk.Label(edit,text="",style="Muted.TLabel",wraplength=760);detail.grid(row=2,column=1,columnspan=4,sticky="w",pady=6)
        def fill():
            selected=tree.selection()
            for child in tree.get_children():tree.delete(child)
            for index,entry in enumerate(self.entries):
                tree.insert("","end",iid=str(index),values=(entry.relative,entry.class_name or "—",entry.mode or "—",entry.status))
            if selected and tree.exists(selected[0]):tree.selection_set(selected)
        def selected(event=None):
            selection=tree.selection()
            if not selection:return
            entry=self.entries[int(selection[0])];c.set(entry.class_name);m.set(entry.mode);skip.set(entry.skipped)
            kind.set(subject_kind(entry.class_name,self.custom_bosses));mode_choices()
            detail.configure(text=entry.error or entry.path)
            try:self._thumbnail(photo,load_image(entry.path),"library")
            except Exception:self._thumbnail(photo,None,"library")
        def assign():
            selection=tree.selection()
            if not selection:return
            entry=self.entries[int(selection[0])]
            entry.class_name=c.get().strip()[:80];entry.mode=m.get().strip()[:40];entry.skipped=skip.get()
            entry.kind=kind.get()
            self.overrides[entry.path]={"class_name":entry.class_name,"mode":entry.mode,"skipped":entry.skipped,"kind":entry.kind}
            self._remember_subject(entry.class_name,entry.kind)
            self._refresh_library();fill();selected();self.schedule_save()
        ttk.Button(edit,text="선택한 파일에 적용",command=assign).grid(row=1,column=4,padx=10)
        tree.bind("<<TreeviewSelect>>",selected)
        fill()
        ttk.Button(window,text="닫기",command=window.destroy).pack(pady=8)

    def _remember_subject(self,name,kind):
        if kind=="보스·몬스터" and name not in BOSS_ALIASES and name not in self.custom_bosses:self.custom_bosses.append(name)
        elif kind=="클래스" and name not in CLASS_ALIASES and name not in self.custom_classes:self.custom_classes.append(name)
        self.vault.set_preference("custom_bosses",self.custom_bosses)

    def add_portrait(self):
        if self.busy:return
        filename=filedialog.askopenfilename(parent=self.root,title="기본 클래스 또는 보스·몬스터 그림 추가",filetypes=IMAGE_TYPES)
        if not filename:return
        try:image=load_image(filename)
        except Exception as exc:messagebox.showerror("그림 추가",str(exc),parent=self.root);return
        guessed,mode=infer_identity(Path(filename).name,self.custom_classes,self.custom_bosses)
        window=tk.Toplevel(self.root);window.title("초상화 기본 그림 추가");window.geometry("470x530");window.transient(self.root);window.grab_set()
        panel=ttk.Frame(window,padding=16,style="Panel.TFrame");panel.pack(fill="both",expand=True)
        photo=ttk.Label(panel,anchor="center");photo.pack(fill="x");self._thumbnail(photo,image,"add-portrait")
        ttk.Label(panel,text=Path(filename).name,wraplength=420).pack(pady=6)
        kind=tk.StringVar(value=subject_kind(guessed,self.custom_bosses) if guessed else self.portrait_kind.get())
        name=tk.StringVar(value=guessed or "");specialization=tk.StringVar(value=mode)
        kinds=self._combo(panel,"초상화 종류",kind,["클래스","보스·몬스터"])
        ttk.Label(panel,text="클래스 / 보스·몬스터 이름 · 직접 입력 가능").pack(anchor="w",pady=(8,3))
        names=ttk.Combobox(panel,textvariable=name);names.pack(fill="x")
        modes=self._combo(panel,"전투계열 / 그림 유형",specialization,[])
        note=ttk.Label(panel,text="파일 이름을 인식하지 못했습니다. 이름과 종류를 지정해 주세요." if not guessed else "인식한 이름과 전투계열을 확인해 주세요.",style="Muted.TLabel",wraplength=420)
        note.pack(fill="x",pady=10)
        def sync(event=None):
            names.configure(values=self._subject_names(kind.get()))
            options=modes_for(name.get(),kind.get());modes.configure(values=options)
            if specialization.get() not in options:specialization.set(options[0])
        def known(event=None):
            if name.get() in CLASS_ALIASES or name.get() in BOSS_ALIASES:kind.set(subject_kind(name.get(),self.custom_bosses))
            sync()
        kinds.bind("<<ComboboxSelected>>",sync);names.bind("<<ComboboxSelected>>",known);names.bind("<FocusOut>",known);sync()
        def add():
            value=name.get().strip()[:80]
            if not value:note.configure(text="클래스 또는 보스·몬스터 이름을 입력해 주세요.");return
            self._save_session();self._remember_subject(value,kind.get())
            entry=LibraryEntry(filename,Path(filename).name,value,specialization.get(),kind=kind.get())
            try:
                self.entries=self.vault.import_entries([entry]);self.character.set(value);self.mode.set(specialization.get())
                self._refresh_library();self._save_settings();window.destroy()
                self.status.set(f"{value} / {specialization.get()} 기본 그림을 자료함에 추가했습니다.")
                if any(e.status.startswith("중복") for e in self.entries):self.library_dialog()
            except Exception as exc:messagebox.showerror("그림 추가 실패",str(exc),parent=window)
        ttk.Button(panel,text="기본 그림으로 등록",command=add).pack(fill="x",pady=8)

    def choose_reference(self):
        if self.busy:return
        path=filedialog.askopenfilename(parent=self.root,title="외부 참조 그림 선택",filetypes=IMAGE_TYPES)
        if path:
            try:
                image=load_image(path)
                self._restore_reference(self.vault.put_image(image,"reference"),Path(path).name)
                self.status.set("참조 그림을 불러왔습니다. 기본 그림은 유지됩니다.")
                self.schedule_save()
            except Exception as exc:messagebox.showerror("그림 읽기 실패",str(exc),parent=self.root)

    def clear_reference(self):
        if self.busy:return
        self.reference_image=None;self.reference_path="";self.reference_asset="";self.reference_label="";self.reference_name.configure(text="")
        self._thumbnail(self.reference_thumb,None,"reference")
        self.schedule_save()

    def _restore_reference(self,digest,label=""):
        if not digest:
            self.reference_image=None;self.reference_path="";self.reference_asset="";self.reference_label=""
            self.reference_name.configure(text="");self._thumbnail(self.reference_thumb,None,"reference");return
        try:
            self.reference_image=self.vault.image(digest);self.reference_path=str(self.vault.materialize(digest))
            self.reference_asset=digest;self.reference_label=label or "보관된 참조 그림"
            self.reference_name.configure(text=self.reference_label)
            self._thumbnail(self.reference_thumb,self.reference_image,"reference")
        except (ValueError,OSError):self.status.set("보관된 참조 그림을 읽을 수 없습니다.")

    def _select_layer(self,identifier):
        self.selected_layer.set(identifier)
        self._load_layer_controls();self.schedule_render()

    def _load_layer_controls(self):
        self.loading_controls=True
        layer=next(e for e in self.layers if e["id"]==self.selected_layer.get())
        if layer.get("font") and layer["font"] not in self.font_map.values():
            label=layer.get("font_name") or Path(layer["font"]).name
            if label in self.font_map:label+=" (자료함)"
            self.font_map[label]=layer["font"];self.font_combo.configure(values=list(self.font_map))
        self.layer_selection.set(next(label for label,key in self.layer_labels.items() if key==layer["id"]))
        self.layer_text.set(layer["text"])
        self.layer_font.set(next((label for label,path in self.font_map.items() if path==layer["font"]),Path(layer["font"]).name if layer["font"] else "폰트 파일을 선택하세요"))
        for variable,key in [(self.layer_size,"size"),(self.layer_x,"x"),(self.layer_y,"y"),(self.layer_stroke,"stroke")]:variable.set(layer[key])
        self.color_button.configure(text="글자 색: "+layer["color"])
        self.loading_controls=False

    def _change_layer(self,field,value):
        if not self.ready or getattr(self,"loading_controls",False):return
        layer=next(e for e in self.layers if e["id"]==self.selected_layer.get())
        layer[field]=value
        if field=="font":layer["font_name"]=Path(value).name
        self.schedule_render()

    def choose_font(self):
        path=filedialog.askopenfilename(parent=self.root,title="폰트 파일 선택",filetypes=[("폰트","*.ttf *.otf *.ttc")])
        if path:self._change_layer("font",path);self._load_layer_controls()

    def choose_color(self):
        layer=next(e for e in self.layers if e["id"]==self.selected_layer.get())
        color=colorchooser.askcolor(color=layer["color"],parent=self.root,title="글자 색 선택")[1]
        if color:self._change_layer("color",color);self._load_layer_controls()

    def _active_image(self):
        if self.view.get()=="AI 결과" and self.result_image is not None and self.result_key==self.current_key():return self.result_image
        return self.base_image

    def _render_full(self):
        return render_portrait(self._active_image(),self.layers,self.zoom.get(),self.pan_x.get(),self.pan_y.get(),self.shade.get())

    def schedule_render(self):
        if not self.ready:return
        if self.render_pending:self.root.after_cancel(self.render_pending)
        self.render_pending=self.root.after(45,self._render)
        self.schedule_save()

    def _render(self):
        self.render_pending=None
        try:image,boxes=self._render_full()
        except Exception as exc:self.status.set("미리보기 오류: "+str(exc));return
        cw,ch=max(1,self.canvas.winfo_width()),max(1,self.canvas.winfo_height())
        scale=min((cw-8)/SIZE[0],(ch-8)/SIZE[1])
        if self.preview_actual.get():scale=min(1.0,scale)
        if scale<=0:return
        width,height=max(1,round(SIZE[0]*scale)),max(1,round(SIZE[1]*scale))
        self._photos["preview"]=ImageTk.PhotoImage(image.resize((width,height),Image.Resampling.LANCZOS))
        self.canvas.delete("all")
        ox,oy=(cw-width)/2,(ch-height)/2
        self.canvas.create_image(ox,oy,image=self._photos["preview"],anchor="nw")
        if self._active_image() is None:self.canvas.create_text(cw/2,oy+height*.42,text="기본 그림 폴더를 선택해 주세요",fill="#d7dce4",font=("TkDefaultFont",11))
        self.preview_transform=(ox,oy,scale);self.preview_boxes=boxes
        box=boxes.get(self.selected_layer.get())
        if box:self.canvas.create_rectangle(ox+box[0]*scale-3,oy+box[1]*scale-3,ox+box[2]*scale+3,oy+box[3]*scale+3,outline="#e4c58a",dash=(3,2))
        self.preview_title.configure(text="미리보기 · "+("AI 결과" if self.view.get()=="AI 결과" and self.result_key==self.current_key() else "기본 그림")+f" · 220 × 283 · {round(scale*100)}%")

    def _drag_start(self,event):
        ox,oy,scale=self.preview_transform
        for layer in reversed(self.layers):
            box=self.preview_boxes.get(layer["id"])
            if box and ox+box[0]*scale-6<=event.x<=ox+box[2]*scale+6 and oy+box[1]*scale-6<=event.y<=oy+box[3]*scale+6:
                self._select_layer(layer["id"]);self.drag=(event.x,event.y,layer["x"],layer["y"]);self.canvas.focus_set();break

    def _drag_move(self,event):
        if not self.drag:return
        _,_,scale=self.preview_transform
        layer=next(e for e in self.layers if e["id"]==self.selected_layer.get())
        sx,sy,lx,ly=self.drag
        layer["x"]=max(0,min(100,lx+(event.x-sx)/scale/SIZE[0]*100))
        layer["y"]=max(0,min(100,ly+(event.y-sy)/scale/SIZE[1]*100))
        self._load_layer_controls();self.schedule_render()

    def _move_key(self,event):
        if event.keysym not in {"Left","Right","Up","Down"}:return
        layer=next(e for e in self.layers if e["id"]==self.selected_layer.get())
        step=.25 if event.state&1 else 1
        dx={"Left":-step,"Right":step}.get(event.keysym,0);dy={"Up":-step,"Down":step}.get(event.keysym,0)
        layer["x"]=max(0,min(100,layer["x"]+dx));layer["y"]=max(0,min(100,layer["y"]+dy))
        self._load_layer_controls();self.schedule_render()

    def _invalidate_connection(self):
        self.verified=None;self._update_provider_ui();self.schedule_save()

    def _update_provider_ui(self):
        selected=provider_label(self.provider.get())
        self.provider.set(selected)
        web=selected=="ChatGPT 웹"
        self.settings_button.configure(text="웹 작업 안내" if web else "AI 연결 설정")
        self.connect_button.configure(text="ChatGPT 열기 ↗" if web else "연결 확인")
        self.generate_button.configure(text="ChatGPT 웹 작업 열기" if web else "AI로 초상화 생성")
        preview_title="미리보기 · 220 × 283"
        if web:
            preview_title="웹 작업 준비 후 결과 파일 끌어 놓기"
            try:
                task=self.web_tasks.task(self.vault.preference("web_active",""))
                preview_title=f"웹 결과 → {task['project']['character']} / {task['project']['mode']}"
            except ValueError:pass
        self.preview_title.configure(text=preview_title,wraplength=310)
        if web:self.ai_status.set("ChatGPT 웹 · Plus 등 구독으로 직접 생성 · 웹 모델 자동 확인 불가")
        elif self.verified!=selected:
            self.ai_status.set(selected+(" · 별도 API 요금 · 미연결" if selected=="OpenAI API" else " · 로컬/서버 워크플로 · 미연결"))

    def open_chatgpt(self):
        import webbrowser
        try:
            if not webbrowser.open(CHATGPT_URL):raise OSError("기본 브라우저를 열지 못했습니다.")
            self.status.set("ChatGPT 웹을 열었습니다. 로그인하고 준비된 요청문과 PNG 그림을 첨부해 주세요.")
        except Exception as exc:messagebox.showerror("ChatGPT 열기",str(exc)+"\n브라우저에서 https://chatgpt.com/ 을 열어 주세요.",parent=self.root)

    def open_web_workspace(self):
        if self.busy:return
        existing=getattr(self,"web_workspace",None)
        if existing and existing.window.winfo_exists():existing.window.lift();return
        from .web_ui import WebWorkspace
        self.web_workspace=WebWorkspace(self)
        if not self.web_tasks.tasks() and self.base_image is not None:self.web_workspace.prepare()

    def _drop_web_result(self,paths):
        if self.provider.get()!="ChatGPT 웹":
            self.status.set("웹 결과를 가져오려면 생성 방식에서 ChatGPT 웹을 선택하세요.")
            return False
        identifier=self.vault.preference("web_active","")
        if not identifier:
            self.open_web_workspace()
            self.status.set("웹 작업을 준비한 뒤 다운로드한 결과 파일을 끌어 놓으세요.")
            return False
        workspace=getattr(self,"web_workspace",None)
        model=workspace.model.get() if workspace and workspace.window.winfo_exists() and workspace.task_id==identifier else ""
        accepted=self.import_web_result(identifier,paths,model)
        if accepted and workspace and workspace.window.winfo_exists():workspace.refresh(identifier)
        return accepted

    def import_web_result(self,identifier,paths,reported_model="",parent=None):
        if self.busy:
            self.status.set("현재 작업이 끝난 뒤 결과 그림을 가져와 주세요.");return False
        if len(paths)!=1:
            messagebox.showinfo("결과 그림 선택","결과 그림 파일을 한 번에 한 장씩 가져와 주세요.",parent=parent or self.root);return False
        try:
            # The task snapshot determines the class and editor settings, even if
            # the main window has since switched to a different character.
            self._save_session()
            result_id=self.web_tasks.import_result(identifier,paths[0],reported_model)
            self.open_stored_result(result_id)
            self._save_settings()
            self.library_status.set(f"자료함 기본 그림 {len(self.entries)}개 · 보관 결과 {len(self.vault.results())}개")
            self.status.set(f"ChatGPT 웹 결과를 {self.character.get()} / {self.mode.get()}에 보관했습니다. 글자와 구도를 조절하세요.")
            return True
        except Exception as exc:
            messagebox.showerror("웹 결과 가져오기 실패",str(exc),parent=parent or self.root);return False

    def connection_settings(self):
        if self.busy:return
        if self.provider.get()=="ChatGPT 웹":self.open_web_workspace();return
        window=tk.Toplevel(self.root);window.title("AI 연결 설정");window.geometry("780x650")
        window.transient(self.root);window.grab_set()
        tabs=ttk.Notebook(window);tabs.pack(fill="both",expand=True,padx=12,pady=12)
        openai=ttk.Frame(tabs,padding=16,style="Panel.TFrame");comfy=ttk.Frame(tabs,padding=16,style="Panel.TFrame")
        tabs.add(openai,text="OpenAI API");tabs.add(comfy,text="ComfyUI")
        key=tk.StringVar(value=self.api_key);model=tk.StringVar(value=self.ai["model"]);quality=tk.StringVar(value=self.ai["quality"])
        for label,variable,hidden in [("API 키 · 이번 실행 동안만 보관",key,True),("이미지 모델명",model,False)]:
            ttk.Label(openai,text=label).pack(anchor="w",pady=(10,4))
            ttk.Entry(openai,textvariable=variable,show="*" if hidden else "").pack(fill="x")
        self._combo(openai,"품질",quality,["low","medium","high","auto"])
        ttk.Label(openai,text="API 키는 설정 파일이나 프로젝트에 저장하지 않습니다.\nOPENAI_API_KEY 환경변수를 사용할 수도 있습니다.\n이미지 생성은 OpenAI API의 별도 사용 요금이 발생합니다.",style="Muted.TLabel",wraplength=650).pack(anchor="w",pady=18)
        url=tk.StringVar(value=self.ai["comfy_url"]);workflow_path=tk.StringVar(value=self.ai["workflow"])
        ttk.Label(comfy,text="ComfyUI 서버 주소").pack(anchor="w")
        ttk.Entry(comfy,textvariable=url).pack(fill="x",pady=4)
        row=ttk.Frame(comfy,style="Panel.TFrame");row.pack(fill="x",pady=8)
        ttk.Entry(row,textvariable=workflow_path,state="readonly").pack(side="left",fill="x",expand=True)
        bind_vars={name:tk.StringVar() for name in ["base","reference","prompt","output"]}
        bind_options={}
        boxes={}
        for name,label in [("base","기본 그림 입력"),("reference","참조 그림 입력 · 참조 사용 시 필수"),("prompt","프롬프트 입력"),("output","결과 이미지 출력 노드")]:
            boxes[name]=self._combo(comfy,label,bind_vars[name],[])
        model_label=ttk.Label(comfy,text="워크플로 미선택",style="Muted.TLabel",wraplength=680);model_label.pack(anchor="w",pady=7)
        def load_options():
            try:
                if not workflow_path.get():return
                graph=read_workflow(json.loads(Path(workflow_path.get()).read_text(encoding="utf-8-sig")))
                for name,kind in [("base","image"),("reference","image"),("prompt","prompt")]:
                    choices=input_options(graph,kind);mapping={"지정 안 함":"",**dict(choices)};bind_options[name]=mapping
                    boxes[name].configure(values=list(mapping))
                    target=self.ai["bindings"].get(name,"")
                    bind_vars[name].set(next((label for label,value in mapping.items() if value==target),"지정 안 함"))
                mapping={f"{node_id} · {node.get('_meta',{}).get('title',node['class_type'])}":node_id for node_id,node in graph.items()}
                bind_options["output"]=mapping;boxes["output"].configure(values=list(mapping))
                default=self.ai["bindings"].get("output",next((k for k,v in graph.items() if v["class_type"]=="SaveImage"),""))
                bind_vars["output"].set(next((label for label,value in mapping.items() if value==default),""))
                model_label.configure(text="워크플로 모델: "+(", ".join(model_names(graph)) or "모델명이 직접 지정되지 않음"))
            except Exception as exc:messagebox.showerror("워크플로 확인",str(exc),parent=window)
        def browse_workflow():
            selected=filedialog.askopenfilename(parent=window,title="ComfyUI API 형식 워크플로",filetypes=[("JSON","*.json")])
            if selected:workflow_path.set(selected);load_options()
        ttk.Button(row,text="워크플로 불러오기…",command=browse_workflow).pack(side="left",padx=6)
        load_options()
        ttk.Label(comfy,text="ComfyUI에서 API 형식으로 저장한 JSON을 사용하세요.\n기본 그림·참조 그림·프롬프트가 결과 노드에 연결돼 있는지 생성 전에 검사합니다.",style="Muted.TLabel",wraplength=670).pack(anchor="w",pady=8)
        def save():
            self.api_key=key.get().strip()
            self.ai.update(model=model.get().strip(),quality=quality.get(),comfy_url=url.get().strip(),workflow=workflow_path.get(),
                           bindings={name:bind_options.get(name,{}).get(variable.get(),"") for name,variable in bind_vars.items()})
            self._invalidate_connection();self.schedule_save();window.destroy()
        ttk.Button(window,text="설정 적용",command=save).pack(pady=(0,12))
        if self.provider.get()=="ComfyUI":tabs.select(comfy)

    def _provider(self):
        if self.provider.get()=="OpenAI API":return OpenAIProvider(self.api_key,self.ai["model"])
        if self.provider.get()=="ComfyUI":return ComfyProvider(self.ai["comfy_url"])
        raise ValueError("ChatGPT 웹은 웹 작업 창에서 직접 생성한 그림을 가져옵니다.")

    def check_connection(self):
        if self.busy:return
        if self.provider.get()=="ChatGPT 웹":self.open_chatgpt();return
        provider_name=self.provider.get()
        try:provider=self._provider()
        except Exception as exc:messagebox.showerror("AI 연결",str(exc),parent=self.root);return
        def complete(info):
            self.verified=provider_name
            self.ai_status.set(f"{provider_name} · {info['model']} · 연결 확인")
            self.status.set(info["note"])
        def work(progress):
            info=provider.check()
            if isinstance(provider,ComfyProvider) and self.ai.get("workflow"):
                try:
                    graph=read_workflow(json.loads(Path(self.ai["workflow"]).read_text(encoding="utf-8-sig")))
                    info["model"]=", ".join(model_names(graph)) or "워크플로 모델명 미지정"
                except (OSError,ValueError,ProviderError):info["model"]="워크플로 확인 필요"
            return info
        self._run(work,complete,"AI 연결 확인 중…")

    def generate(self):
        if self.busy:return
        if self.provider.get()=="ChatGPT 웹":self.open_web_workspace();return
        if self.base_image is None:messagebox.showinfo("기본 그림 필요","선택한 클래스·전투계열의 기본 그림을 연결해 주세요.",parent=self.root);return
        if self.verified!=self.provider.get():messagebox.showinfo("AI 연결 필요","AI 연결 설정을 적용하고 '연결 확인'을 눌러 주세요.",parent=self.root);return
        self._save_session()
        provider=self._provider();base=self.base_image.copy();reference=self.reference_image.copy() if self.reference_image else None
        key=self.current_key();base_path=self.base_path;reference_path=self.reference_path
        prompt=compose_prompt(*key,self.gender.get(),self.preserve.get(),self.reference_role.get(),self.extra.get("1.0","end-1c"),reference is not None,self.portrait_kind.get())
        workflow=None
        if self.provider.get()=="ComfyUI":
            try:
                workflow=read_workflow(json.loads(Path(self.ai["workflow"]).read_text(encoding="utf-8-sig")))
                prepare_workflow(workflow,self.ai["bindings"],prompt,"base.png","reference.png" if reference else None)
            except Exception as exc:messagebox.showerror("ComfyUI 설정 확인",str(exc),parent=self.root);return
        bindings=copy.deepcopy(self.ai["bindings"]);quality=self.ai["quality"]
        def work(progress):
            return provider.generate(base,reference,prompt,quality,progress) if isinstance(provider,OpenAIProvider) else provider.generate(base,reference,prompt,workflow,bindings,progress)
        def complete(result):
            self.result_image=result.image;self.result_key=key
            self.result_metadata={**result.metadata,"character":key[0],"mode":key[1],"base_path":base_path,"reference_path":reference_path,"prompt":prompt,"time":datetime.now().isoformat(timespec="seconds")}
            model=result.metadata.get("requested_model") or ", ".join(result.metadata.get("models",[])) or "워크플로 모델 미표시"
            self.provenance.set(f"생성 AI: {result.metadata['provider']} · {model}")
            if self.current_key()==key:self.view.set("AI 결과");self.zoom.set(100);self.pan_x.set(0);self.pan_y.set(0)
            portrait,_=self._render_full()
            self.result_id=self.vault.add_result(result.image,portrait,self.project_data())
            self.library_status.set(f"자료함 기본 그림 {len(self.entries)}개 · 보관 결과 {len(self.vault.results())}개")
            self.status.set("AI 초상화를 생성하고 자료함에 자동 보관했습니다. 글자와 구도를 조절하세요.")
            self.schedule_render()
        self._run(work,complete,"AI 생성 시작…")

    def _run(self,work,complete,message):
        if self.busy:return
        self.busy=True;self.status.set(message);self.progress.start(12)
        for widget in [self.generate_button,self.connect_button,self.folder_button,self.settings_button,self.reference_button]:widget.configure(state="disabled")
        for widget in [self.class_combo,self.mode_combo,self.provider_combo,self.kind_combo]:widget.configure(state="disabled")
        def worker():
            try:self.messages.put(("done",complete,work(lambda text:self.messages.put(("progress",text)))))
            except Exception as exc:
                text=str(exc)
                if self.api_key:text=text.replace(self.api_key,"[키 숨김]")
                self.messages.put(("error",text))
        threading.Thread(target=worker,daemon=True).start()

    def _poll(self):
        try:
            while True:
                item=self.messages.get_nowait()
                if item[0]=="progress":self.status.set(item[1]);continue
                self.busy=False;self.progress.stop()
                for widget in [self.generate_button,self.connect_button,self.folder_button,self.settings_button,self.reference_button]:widget.configure(state="normal")
                for widget in [self.class_combo,self.mode_combo,self.provider_combo,self.kind_combo]:widget.configure(state="readonly")
                self._update_provider_ui()
                if item[0]=="done":
                    try:item[1](item[2])
                    except Exception as exc:
                        self.status.set("결과 처리 오류: "+str(exc));messagebox.showerror("결과 처리 오류",str(exc),parent=self.root)
                else:
                    self.suspend_save=False
                    self.status.set(item[1]);messagebox.showerror("작업 실패",item[1],parent=self.root)
        except queue.Empty:pass
        self.root.after(70,self._poll)

    def choose_output(self):
        folder=filedialog.askdirectory(parent=self.root,title="초상화를 저장할 폴더",initialdir=self.output.get() or None)
        if folder:self.output.set(folder);self.schedule_save()

    def project_data(self,key=None):
        key=key or self.current_key()
        return {"schema":1,"character":key[0],"mode":key[1],"kind":subject_kind(key[0],self.custom_bosses),"layers":copy.deepcopy(self.layers),
                "zoom":self.zoom.get(),"pan_x":self.pan_x.get(),"pan_y":self.pan_y.get(),"shade":self.shade.get(),
                "reference_asset":self.reference_asset,"reference_label":self.reference_label,
                "controls":{"gender":self.gender.get(),"preserve":self.preserve.get(),"reference_role":self.reference_role.get(),"prompt":self.extra.get("1.0","end-1c")},
                "generation":self.result_metadata if self.view.get()=="AI 결과" and self.result_key==key else {"provider":"기본 그림","base_path":self.base_path}}

    def _save_session(self,key=None):
        if not self.ready or self.suspend_save:return
        key=key or self.editor_key or self.current_key()
        image=self.result_image if self.view.get()=="AI 결과" and self.result_key==key else self.base_image
        if image is None:return
        project=self.project_data(key)
        if self.view.get()=="AI 결과" and self.result_id and self.result_key==key:
            preview,_=render_portrait(image,self.layers,self.zoom.get(),self.pan_x.get(),self.pan_y.get(),self.shade.get())
            self.vault.update_result(self.result_id,preview,project)
        self.vault.save_draft(key,project,self.view.get(),self.result_id if self.result_key==key else None)

    def _apply_project_controls(self,project):
        controls=project.get("controls",{})
        for name in ["gender","preserve","reference_role"]:
            if isinstance(controls.get(name),str):getattr(self,name).set(controls[name])
        if isinstance(controls.get("prompt"),str):self.extra.delete("1.0","end");self.extra.insert("1.0",controls["prompt"])

    def _read_result(self,identifier,apply_editor=True):
        record=self.vault.result(identifier)
        self.result_id=record["id"];self.result_image=record["image"]
        self.result_key=(record["class_name"],record["mode"])
        self.result_metadata=record["project"].get("generation",{})
        model=self.result_metadata.get("requested_model") or ", ".join(self.result_metadata.get("models",[]))
        if self.result_metadata.get("provider")=="ChatGPT 웹":
            reported=self.result_metadata.get("reported_model","")
            model="사용자 입력: "+reported if reported else "웹 모델 자동 확인 불가"
        self.provenance.set("보관 결과: "+str(self.result_metadata.get("provider","생성 정보 없음"))+(" · "+model if model else ""))
        if apply_editor:
            self._apply_template(record["project"]);self._apply_project_controls(record["project"])
            self._restore_reference(record["project"].get("reference_asset",""),record["project"].get("reference_label",""))
            self.view.set("AI 결과")
        return record

    def open_stored_result(self,identifier):
        if self.busy:return
        self._save_session()
        record=self.vault.result(identifier)
        self.editor_key=None
        self.character.set(record["class_name"]);self.mode.set(record["mode"])
        self._select_character(restore=False)
        self._read_result(identifier)
        self._load_layer_controls();self.schedule_render()
        self.status.set("자료함에서 결과와 편집 설정을 불러왔습니다.")

    def _archive_current(self):
        image=self._active_image()
        if image is None:raise ValueError("먼저 기본 그림을 선택하거나 초상화를 생성해 주세요.")
        preview,_=self._render_full()
        project=self.project_data()
        identifier=self.result_id if self.view.get()=="AI 결과" and self.result_key==self.current_key() else None
        identifier=self.vault.add_result(image,preview,project,identifier)
        if self.view.get()=="AI 결과":self.result_id=identifier
        self.library_status.set(f"자료함 기본 그림 {len(self.entries)}개 · 보관 결과 {len(self.vault.results())}개")
        return identifier

    def keep_current(self):
        if self.busy:return
        try:
            identifier=self._archive_current()
            self.open_stored_result(identifier)
            self._save_settings()
            self.status.set("현재 그림과 글자·구도 설정을 자료함에 보관했습니다.")
        except Exception as exc:messagebox.showerror("자료함 보관 실패",str(exc),parent=self.root)

    def results_dialog(self):
        if self.busy:return
        self._save_session()
        if not self.vault.results():messagebox.showinfo("보관된 결과","아직 보관한 결과가 없습니다. AI 생성 결과는 자동 보관되며, 기본 그림 편집본은 '자료함에 보관'을 누르세요.",parent=self.root);return
        window=tk.Toplevel(self.root);window.title("보관된 초상화 결과");window.geometry("920x570")
        window.transient(self.root);window.grab_set()
        holder=ttk.Frame(window,padding=12);holder.pack(fill="both",expand=True)
        tree=ttk.Treeview(holder,columns=("time","class","mode"),show="headings",selectmode="browse")
        for name,label,width in [("time","보관 날짜",210),("class","클래스·보스",150),("mode","전투계열·종류",100)]:tree.heading(name,text=label);tree.column(name,width=width)
        tree.pack(side="left",fill="both",expand=True)
        scroll=ttk.Scrollbar(holder,orient="vertical",command=tree.yview);scroll.pack(side="left",fill="y");tree.configure(yscrollcommand=scroll.set)
        right=ttk.Frame(holder,padding=(14,0));right.pack(side="right",fill="y")
        image_label=ttk.Label(right,text="결과 선택");image_label.pack()
        detail=ttk.Label(right,text="",wraplength=240,style="Muted.TLabel");detail.pack(pady=10)
        records=self.vault.results()
        for record in records:tree.insert("","end",iid=record["id"],values=(record["created"],record["class_name"],record["mode"]))
        def selected(event=None):
            selection=tree.selection()
            if not selection:return
            record=self.vault.result(selection[0])
            preview=self.vault.image(record["preview_hash"]);preview.thumbnail((210,275),Image.Resampling.LANCZOS)
            self._photos["result-gallery"]=ImageTk.PhotoImage(preview)
            image_label.configure(image=self._photos["result-gallery"],text="")
            detail.configure(text="생성 서비스: "+str(record["project"].get("generation",{}).get("provider","기본 그림")))
        def open_selected():
            selection=tree.selection()
            if selection:window.destroy();self.open_stored_result(selection[0])
        tree.bind("<<TreeviewSelect>>",selected);tree.bind("<Double-1>",lambda e:open_selected())
        ttk.Button(right,text="이 결과 열고 편집",command=open_selected).pack(fill="x",pady=10)
        tree.selection_set(records[0]["id"]);selected()

    def export_vault(self):
        if self.busy:return
        self._save_settings()
        filename=filedialog.asksaveasfilename(parent=self.root,title="기본 그림·결과·설정 전체 자료함 백업",defaultextension=".bdostudio",initialfile="초상화자료함_"+datetime.now().strftime("%Y%m%d")+".bdostudio",filetypes=[("초상화 자료함","*.bdostudio")])
        if not filename:return
        self._run(lambda progress:self.vault.export_backup(filename),lambda path:self.status.set("자료함 백업 완료: "+str(path)),"그림·결과·폰트·설정을 한 파일로 백업 중…")

    def import_vault(self):
        if self.busy:return
        filename=filedialog.askopenfilename(parent=self.root,title="다른 컴퓨터에서 가져온 자료함 선택",filetypes=[("초상화 자료함","*.bdostudio")])
        if not filename:return
        if not messagebox.askyesno("자료함 가져오기","현재 자료함은 자동 백업한 뒤 선택한 자료함으로 전환합니다.\n기본 그림·결과·편집 설정을 가져올까요?",parent=self.root):return
        self._save_settings();self.suspend_save=True
        def complete(recovery):
            self.suspend_save=False
            self._reload_vault()
            self.status.set("자료함을 가져왔습니다. 이전 자료함 자동 백업: "+str(recovery))
        self._run(lambda progress:self.vault.restore_backup(filename),complete,"자료함 검사 및 복원 중…")

    def _reload_vault(self):
        existing=getattr(self,"web_workspace",None)
        if existing and existing.window.winfo_exists():existing.window.destroy()
        saved=self.vault.load_preferences();self.saved=saved
        for name in ["provider","character","mode","folder","output","gender","preserve","reference_role"]:
            if isinstance(saved.get(name),str):getattr(self,name).set(saved[name])
        if self.output.get() and not Path(self.output.get()).is_dir():self.output.set("")
        self.provider.set(provider_label(self.provider.get()))
        self.ai.update(saved.get("ai",{}));self.overrides=saved.get("library_overrides",{});self.custom_classes=saved.get("custom_classes",[])
        self.custom_bosses=self.vault.preference("custom_bosses",saved.get("custom_bosses",[]))
        if saved.get("layers"):self._apply_template({"layers":saved["layers"],"zoom":100,"pan_x":0,"pan_y":0,"shade":65})
        self.editor_key=None;self.result_key=None;self.result_id=None;self.result_image=None;self.result_metadata={}
        self.base_path="";self.base_image=None
        self._restore_reference("","")
        self.entries=self.vault.entries()
        self._refresh_library()
        if saved.get("reference_asset") and not self.reference_asset:self._restore_reference(saved["reference_asset"],saved.get("reference_label",""))
        self._invalidate_connection()

    def open_vault_folder(self):
        open_folder(self.data_dir)

    def export(self):
        image=self._active_image()
        if image is None:messagebox.showinfo("그림 필요","저장할 그림을 먼저 불러오거나 생성해 주세요.",parent=self.root);return
        if not self.output.get():self.choose_output()
        if not self.output.get():return
        try:
            portrait,_=self._render_full()
            self._archive_current()
            target=export_bundle(self.output.get(),"_".join(self.current_key()),image,portrait,self.project_data())
            self.status.set("저장 완료: "+str(target))
            messagebox.showinfo("저장 완료",f"{target}\n\nportrait.bmp / portrait.png: 220 × 283픽셀\nsource.png: 원본 크기 보관\nproject.json: 편집 설정",parent=self.root)
        except Exception as exc:messagebox.showerror("저장 실패",str(exc),parent=self.root)

    def open_project(self):
        if self.busy:return
        filename=filedialog.askopenfilename(parent=self.root,title="저장한 project.json 열기",filetypes=[("프로젝트 JSON","*.json")])
        if not filename:return
        try:
            self._save_session()
            path=Path(filename);data=json.loads(path.read_text(encoding="utf-8"))
            if data.get("schema")!=1:raise ValueError("지원하지 않는 프로젝트 형식입니다.")
            image=load_image(path.parent/data.get("source","source.png"))
            if data.get("kind")=="보스·몬스터":self._remember_subject(str(data["character"]),"보스·몬스터")
            self.character.set(str(data["character"]));self.mode.set(str(data["mode"]))
            self.editor_key=None;self._select_character(restore=False)
            self._apply_template(data)
            self.result_image=image;self.result_key=self.current_key();self.result_metadata=data.get("generation",{})
            self.view.set("AI 결과");self.provenance.set("불러온 프로젝트 · "+str(self.result_metadata.get("provider","생성 AI 정보 없음")))
            self._apply_project_controls(data)
            portrait,_=self._render_full()
            self.result_id=self.vault.add_result(image,portrait,self.project_data())
            self._load_layer_controls();self.schedule_render();self.status.set("프로젝트를 불러왔습니다: "+str(path))
        except Exception as exc:messagebox.showerror("프로젝트 열기 실패",str(exc),parent=self.root)

    def _apply_template(self,data):
        layers=data.get("layers")
        if not isinstance(layers,list) or len(layers)!=3 or {x.get("id") for x in layers if isinstance(x,dict)}!={"class","mode","name"}:raise ValueError("올바른 글자 레이어 3개가 필요합니다.")
        for layer in layers:
            if not isinstance(layer.get("text"),str) or len(layer["text"])>300:raise ValueError("글자 내용을 확인해 주세요.")
            for field in ["x","y","size","stroke"]:
                if not isinstance(layer.get(field),(float,int)) or not -1000<float(layer[field])<1000:raise ValueError("글자 위치·크기 값이 올바르지 않습니다.")
            if not isinstance(layer.get("font"),str):raise ValueError("폰트 경로가 올바르지 않습니다.")
        self.layers=copy.deepcopy(layers)
        self.layers[0:]=sorted(self.layers,key=lambda x:["mode","class","name"].index(x["id"]))
        for variable,name,low,high in [(self.zoom,"zoom",100,250),(self.pan_x,"pan_x",-100,100),(self.pan_y,"pan_y",-100,100),(self.shade,"shade",0,100)]:
            variable.set(max(low,min(high,float(data.get(name,variable.get())))))
        missing=[x for x in self.layers if x["font"] and not Path(x["font"]).is_file()]
        for layer in missing:layer["font"]=self.fonts[0] if self.fonts else ""
        if missing:self.status.set("일부 폰트를 찾지 못해 이 컴퓨터의 기본 폰트로 바꿨습니다.")

    def save_template(self):
        filename=filedialog.asksaveasfilename(parent=self.root,title="글자·구도 템플릿 저장",defaultextension=".json",filetypes=[("JSON","*.json")])
        if filename:
            try:
                data=self.project_data();data.pop("generation",None);atomic_json(Path(filename),data)
                self.status.set("템플릿 저장: "+filename)
            except Exception as exc:messagebox.showerror("템플릿 저장 실패",str(exc),parent=self.root)

    def load_template(self):
        filename=filedialog.askopenfilename(parent=self.root,title="글자·구도 템플릿 불러오기",filetypes=[("JSON","*.json")])
        if filename:
            try:
                self._apply_template(json.loads(Path(filename).read_text(encoding="utf-8")))
                self._load_layer_controls();self.schedule_render()
            except Exception as exc:messagebox.showerror("템플릿 불러오기 실패",str(exc),parent=self.root)

    def apply_game(self):
        if self._active_image() is None:return
        target=filedialog.askopenfilename(parent=self.root,title="FaceTexture 폴더에서 교체할 기존 BMP 선택",filetypes=[("BMP","*.bmp")])
        if not target:return
        portrait,_=self._render_full()
        if not messagebox.askyesno("게임 초상화 적용",f"{target}\n\n기존 파일을 백업한 뒤 현재 미리보기로 교체합니다.\n게임을 종료한 상태에서 적용하는 것을 권합니다.\n적용할까요?",parent=self.root):return
        try:
            apply_with_backup(target,portrait,self.data_dir/"backups")
            self.status.set("게임 초상화 적용 완료 · 원본 백업 저장됨")
        except Exception as exc:messagebox.showerror("적용 실패",str(exc),parent=self.root)

    def restore_game(self):
        backups=sorted((self.data_dir/"backups").glob("*.json"),reverse=True)
        if not backups:messagebox.showinfo("복원","저장된 게임 초상화 백업이 없습니다.",parent=self.root);return
        try:
            manifest=backups[0];data=json.loads(manifest.read_text(encoding="utf-8"));target=Path(data["target"])
            if not messagebox.askyesno("최근 적용 복원",f"{target}\n\n가장 최근 적용 전의 그림으로 복원할까요?",parent=self.root):return
            original=manifest.with_suffix(".bmp").read_bytes()
            import hashlib
            if hashlib.sha256(original).hexdigest()!=data["sha256"]:raise ValueError("백업 파일이 변경되어 복원할 수 없습니다.")
            temporary=target.with_name(target.name+".restore.tmp");temporary.write_bytes(original);temporary.replace(target)
            self.status.set("원본 초상화를 복원했습니다: "+str(target))
        except Exception as exc:messagebox.showerror("복원 실패",str(exc),parent=self.root)

    def schedule_save(self):
        if not self.ready or self.suspend_save:return
        if self.save_pending:self.root.after_cancel(self.save_pending)
        self.save_pending=self.root.after(600,self._save_settings)

    def _save_settings(self):
        self.save_pending=None
        if self.suspend_save:return
        data={name:getattr(self,name).get() for name in ["provider","character","mode","folder","output","gender","preserve","reference_role","preview_actual"]}
        data.update(ai=self.ai,library_overrides=self.overrides,custom_classes=self.custom_classes,custom_bosses=self.custom_bosses,layers=self.layers,prompt=self.extra.get("1.0","end-1c"),reference_asset=self.reference_asset,reference_label=self.reference_label)
        try:
            self._save_session()
            self.vault.save_preferences(data)
            atomic_json(self.config_file,self.vault.pack_preferences(data))
        except Exception as exc:self.status.set("자료함 저장 실패: "+str(exc))

    def help(self):
        messagebox.showinfo("사용 안내","1. 기본 그림을 한 번 추가하면 내부 자료함에 복사합니다. 원본 폴더가 없어도 사용할 수 있습니다.\n2. '파일 연결 확인'에서 오류·중복을 지정하거나 제외합니다.\n3. 생성 방식을 선택하세요: OpenAI API / ChatGPT 웹 / ComfyUI.\n\nChatGPT 웹: '웹 작업 열기' → 현재 선택으로 작업 준비 → 요청문 복사 → 첨부 그림 폴더 열기 → ChatGPT에 PNG와 요청문 첨부 → 웹에서 생성·다운로드 → 결과 파일 끌어 놓기 또는 파일 선택. 가져온 결과는 준비 당시의 클래스에 보관됩니다.\nOpenAI API·ComfyUI: 연결 설정 → 연결 확인 → 생성. OpenAI API는 Plus 구독과 별도 과금됩니다.\n\n4. 결과에서 글자·구도를 조절하고 저장합니다. 생성·가져온 결과는 자동 보관되며 '보관된 결과'에서 다시 엽니다.\n5. 다른 컴퓨터로 이동: StudioData 포함 폴더 전체 복사 또는 자료함 메뉴의 백업 내보내기/가져오기. 다른 OS는 해당 OS용 프로그램이 필요합니다.\n\nAPI 키는 이동하지 않습니다. ComfyUI 모델은 별도 설치합니다.",parent=self.root)

    def close(self):
        if self.busy and not messagebox.askyesno("진행 중인 작업","앱을 닫아도 이미 보낸 AI 요청은 서버에서 계속 처리될 수 있습니다. 종료할까요?",parent=self.root):return
        self._save_settings();self.root.destroy()


def main():
    parser=argparse.ArgumentParser(description="검은사막 초상화 스튜디오")
    parser.add_argument("--data-dir",type=Path,help="설정·백업 보관 폴더")
    parser.add_argument("--portable",action="store_true",help="프로그램 옆 StudioData 폴더에 자료함 보관")
    parser.add_argument("--smoke-test",type=Path,help=argparse.SUPPRESS)
    parser.add_argument("--apply-update",type=Path,help=argparse.SUPPRESS)
    args=parser.parse_args()
    if args.apply_update:
        from .updater import apply_plan
        apply_plan(args.apply_update);return
    root=create_root()
    if args.smoke_test:root.withdraw()
    app=StudioApp(root,select_data_directory(args.data_dir,args.portable))
    if args.smoke_test:
        import hashlib
        root.update_idletasks()
        image,boxes=app._render_full();app._save_settings()
        app.open_web_workspace();app.web_workspace.window.withdraw()
        root.update_idletasks()
        atomic_json(args.smoke_test,{"version":__version__,"size":list(image.size),"layers":list(boxes),"tk":root.tk.call("info","patchlevel"),"library_count":len(app.entries),"result_count":len(app.vault.results()),"active_result_id":app.result_id,"preview_sha256":hashlib.sha256(image.tobytes()).hexdigest(),"providers":list(app.provider_combo.cget("values")),"file_drop":app.file_drop_enabled,"web_file_drop":app.web_workspace.drop_enabled,"web_task_id":app.web_workspace.task_id})
        root.destroy();return
    root.mainloop()


if __name__=="__main__":main()
