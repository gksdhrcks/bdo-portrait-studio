"""Local handoff to ChatGPT web. This module never sends an AI request."""
from __future__ import annotations

import copy
import re
import uuid
from datetime import datetime
from pathlib import Path

from .core import atomic_json, load_image, png_bytes, render_portrait, subject_kind

CHATGPT_URL = "https://chatgpt.com/"
PROVIDERS = ("OpenAI API", "ChatGPT 웹", "ComfyUI")


def provider_label(value):
    if value == "OpenAI":
        return "OpenAI API"
    return value if value in PROVIDERS else "OpenAI API"


def web_prompt(project, has_reference):
    controls = project.get("controls", {})
    boss=project.get("kind",subject_kind(project["character"]))=="보스·몬스터"
    parts = [
        "첨부한 그림을 이용해 검은사막 "+("보스·몬스터" if boss else "캐릭터")+" 초상화 한 장을 만들어 주세요.",
        f"{'보스·몬스터 이름' if boss else '클래스'}: {project['character']} / {'그림 유형' if boss else '전투계열'}: {project['mode']}",
        "01_base.png는 기본 그림입니다. 이 그림을 초상화의 바탕으로 사용해 주세요.",
        f"기본 그림에서 유지할 특징: {controls.get('preserve', '클래스·무기·의상')}",
        f"젠더 표현: {controls.get('gender', '기본 그림 유지')}",
    ]
    if has_reference:
        parts.extend([
            "02_reference.png는 외부 참조 그림입니다.",
            f"참조할 요소: {controls.get('reference_role', '화풍과 색감')}",
            "참조와 기본 그림이 충돌하면 기본 그림의 클래스 정체성과 유지할 특징을 우선해 주세요.",
        ])
    if boss:parts.append("기본 그림의 종족·체형·고유 특징을 유지해 주세요. 요청이 없으면 사람 형태로 바꾸지 마세요.")
    parts.extend([
        "세로형 초상화로, 가로:세로 약 52:67 비율로 구성해 주세요. "+("보스의 얼굴과 고유 특징이 잘 보이게 해 주세요." if boss else "얼굴과 주요 무기가 잘 보이게 해 주세요."),
        "아래쪽에는 나중에 글자를 배치할 여백을 두세요. 그림 안에는 글자·이름·로고·워터마크를 그리지 마세요.",
        "최종 220×283 크기 조절과 글자 합성은 별도 프로그램에서 합니다. 가능한 높은 해상도의 그림으로 만들어 주세요.",
    ])
    if controls.get("prompt", "").strip():
        parts.append("추가 요청: " + controls["prompt"].strip())
    return "\n".join(parts)


class WebTasks:
    def __init__(self, vault):
        self.vault = vault

    def tasks(self):
        values = self.vault.preference("web_tasks", [])
        if not isinstance(values, list):
            return []
        return [item for item in values if isinstance(item, dict)
                and re.fullmatch(r"[a-f0-9]{32}", str(item.get("id", "")))
                and isinstance(item.get("project"), dict)
                and isinstance(item.get("prompt"), str)]

    def task(self, identifier):
        item = next((item for item in self.tasks() if item["id"] == identifier), None)
        if item is None:
            raise ValueError("웹 작업을 찾을 수 없습니다. 현재 선택으로 새 작업을 준비해 주세요.")
        return copy.deepcopy(item)

    def create(self, base, reference, project):
        if base is None:
            raise ValueError("선택한 클래스·전투계열의 기본 그림을 먼저 연결해 주세요.")
        project = copy.deepcopy(project)
        reference_asset = self.vault.put_image(reference, "reference") if reference is not None else ""
        project["reference_asset"] = reference_asset
        # New artwork starts with its full frame; keep the user's text and shade settings.
        project.update(zoom=100, pan_x=0, pan_y=0)
        project.pop("generation", None)
        task = dict(id=uuid.uuid4().hex,
                    created=datetime.now().astimezone().isoformat(timespec="seconds"),
                    base_asset=self.vault.put_image(base, "base"), reference_asset=reference_asset,
                    prompt=web_prompt(project, reference is not None),
                    project=self.vault.pack_project(project), result_ids=[])
        self.vault.set_preference("web_tasks", [task, *self.tasks()])
        self.materialize(task["id"])
        return task

    def materialize(self, identifier):
        task = self.task(identifier)
        folder = self.vault.root / "web-tasks" / task["id"]
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "01_base.png").write_bytes(png_bytes(self.vault.image(task["base_asset"])))
        attachments = ["01_base.png"]
        if task.get("reference_asset"):
            (folder / "02_reference.png").write_bytes(png_bytes(self.vault.image(task["reference_asset"])))
            attachments.append("02_reference.png")
        (folder / "요청문.txt").write_text(task["prompt"], encoding="utf-8")
        (folder / "사용순서.txt").write_text(
            "1. ChatGPT 웹에서 로그인합니다.\n"
            "2. 이 폴더의 PNG 그림을 채팅창에 첨부하고 요청문.txt 내용을 붙여 넣습니다.\n"
            "3. 생성된 그림을 다운로드합니다.\n"
            "4. 스튜디오의 해당 웹 작업을 선택하고 결과 그림을 끌어 놓거나 파일 선택으로 가져옵니다.\n"
            "웹 작업을 준비하거나 폴더를 여는 것만으로 AI 요청이 전송되지는 않습니다.\n",
            encoding="utf-8")
        atomic_json(folder / "task.json", dict(id=task["id"], created=task["created"],
                    character=task["project"]["character"], mode=task["project"]["mode"],
                    attachments=attachments))
        return folder

    def import_result(self, identifier, filename, reported_model=""):
        task = self.task(identifier)
        image = load_image(filename)
        project = self.vault.unpack_project(task["project"])
        project["generation"] = dict(provider="ChatGPT 웹", task_id=identifier,
            reported_model=reported_model.strip()[:160], model_verified=False,
            prompt=task["prompt"], imported_filename=Path(filename).name,
            time=datetime.now().astimezone().isoformat(timespec="seconds"))
        preview, _ = render_portrait(image, project["layers"], project["zoom"],
                                    project["pan_x"], project["pan_y"], project["shade"])
        result_id = self.vault.add_result(image, preview, project)
        values = self.tasks()
        for item in values:
            if item["id"] == identifier:
                item.setdefault("result_ids", []).append(result_id)
        self.vault.set_preference("web_tasks", values)
        return result_id
