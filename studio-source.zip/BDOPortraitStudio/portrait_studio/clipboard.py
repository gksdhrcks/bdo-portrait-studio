"""Copy real image bytes, with no browser keystrokes or automatic submission."""
from __future__ import annotations

import io
import shutil
import subprocess
import sys
import time
from pathlib import Path

from PIL import Image


def _windows_copy(owner, png, dib, text):
    import ctypes
    from ctypes import wintypes
    user = ctypes.WinDLL("user32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    user.OpenClipboard.argtypes = [wintypes.HWND]
    user.OpenClipboard.restype = wintypes.BOOL
    user.CloseClipboard.restype = wintypes.BOOL
    user.EmptyClipboard.restype = wintypes.BOOL
    user.RegisterClipboardFormatW.argtypes = [wintypes.LPCWSTR]
    user.RegisterClipboardFormatW.restype = wintypes.UINT
    user.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
    user.SetClipboardData.restype = wintypes.HANDLE
    kernel.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
    kernel.GlobalAlloc.restype = wintypes.HGLOBAL
    kernel.GlobalLock.argtypes = [wintypes.HGLOBAL]
    kernel.GlobalLock.restype = ctypes.c_void_p
    kernel.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
    kernel.GlobalFree.argtypes = [wintypes.HGLOBAL]
    kernel.GlobalFree.restype = wintypes.HGLOBAL
    png_format = user.RegisterClipboardFormatW("PNG")
    if not png_format:
        raise ctypes.WinError(ctypes.get_last_error())
    formats = [(png_format, png), (8, dib)]  # PNG and CF_DIB, both actual image data.
    if text:
        formats.append((13, text.replace("\0", "").encode("utf-16-le") + b"\0\0"))
    handles = []
    opened = False
    try:
        for format_id, payload in formats:
            handle = kernel.GlobalAlloc(0x0002, len(payload))  # GMEM_MOVEABLE
            if not handle:
                raise MemoryError("그림을 복사할 메모리가 부족합니다.")
            handles.append([format_id, handle])
            address = kernel.GlobalLock(handle)
            if not address:
                raise ctypes.WinError(ctypes.get_last_error())
            try:
                ctypes.memmove(address, payload, len(payload))
            finally:
                kernel.GlobalUnlock(handle)
        for attempt in range(12):
            if user.OpenClipboard(owner):
                opened = True
                break
            time.sleep(.04)
        if not opened:
            raise OSError("다른 프로그램이 클립보드를 사용 중입니다. 잠시 후 다시 복사하세요.")
        if not user.EmptyClipboard():
            raise ctypes.WinError(ctypes.get_last_error())
        for item in handles:
            if not user.SetClipboardData(item[0], item[1]):
                error = ctypes.get_last_error()
                user.EmptyClipboard()
                raise OSError(error, f"클립보드 형식 {item[0]}을 기록하지 못했습니다: {ctypes.FormatError(error)}")
            item[1] = None  # Ownership now belongs to Windows.
    finally:
        if opened:
            user.CloseClipboard()
        for _, handle in handles:
            if handle:
                kernel.GlobalFree(handle)


def copy_image(root, filename, text=""):
    path = Path(filename).resolve()
    png = path.read_bytes()
    if not png.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("복사할 PNG 그림을 찾을 수 없습니다.")
    if sys.platform == "win32":
        with Image.open(io.BytesIO(png)) as image:
            bitmap = io.BytesIO()
            image.convert("RGB").save(bitmap, "BMP")
        root.update_idletasks()
        _windows_copy(root.winfo_id(), png, bitmap.getvalue()[14:], text)
        return "image+text"
    if sys.platform == "darwin":
        script = 'on run argv\nset the clipboard to (read (POSIX file (item 1 of argv)) as «class PNGf»)\nend run'
        result = subprocess.run(["osascript", "-e", script, str(path)], capture_output=True, timeout=10)
        if result.returncode:
            raise OSError("그림 복사를 시작하지 못했습니다. 한 장 파일 위치를 열어 직접 첨부하세요.")
        return "image"
    if shutil.which("wl-copy"):
        command = ["wl-copy", "--type", "image/png"]
    elif shutil.which("xclip"):
        command = ["xclip", "-selection", "clipboard", "-t", "image/png", "-i"]
    else:
        raise OSError("그림 복사에는 wl-copy 또는 xclip이 필요합니다. 한 장 파일을 끌어 놓거나 직접 첨부할 수도 있습니다.")
    with path.open("rb") as incoming:
        subprocess.run(command, stdin=incoming, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       check=True, timeout=8)
    return "image"
