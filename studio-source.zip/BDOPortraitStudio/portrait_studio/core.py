from __future__ import annotations

import hashlib
import io
import json
import os
import re
import sys
import unicodedata
import warnings
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

SIZE = (624, 804)
EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
CLASS_ALIASES = {
    "워리어": ["warrior"], "레인저": ["ranger"], "소서러": ["sorceress"],
    "자이언트": ["berserker", "giant"], "금수랑": ["tamer"], "무사": ["musa"],
    "매화": ["maehwa"], "발키리": ["valkyrie"], "쿠노이치": ["kunoichi"],
    "닌자": ["ninja"], "위자드": ["wizard"], "위치": ["witch"],
    "다크나이트": ["darkknight", "dark_knight"], "격투가": ["striker"],
    "미스틱": ["mystic"], "란": ["lahn"], "아처": ["archer"], "샤이": ["shai"],
    "가디언": ["guardian"], "하사신": ["hashashin"], "노바": ["nova"],
    "세이지": ["sage"], "커세어": ["corsair"], "드라카니아": ["drakania"],
    "우사": ["woosa"], "매구": ["maegu"], "스칼라": ["scholar"],
    "도사": ["dosa"], "데드아이": ["deadeye"], "오공": ["wukong"],
    "세라핌": ["seraph"], "에이전트": ["agent"],
}
MODE_ALIASES = {"각성": ["awakening", "awakened"], "전승": ["succession"],
                "기본": ["base"], "재능": ["talent"], "개방": ["ascension"]}
BOSS_ALIASES = {
    "가모스": ["garmoth"], "벨": ["vell"], "크자카": ["kzarka"],
    "누베르": ["nouver"], "카란다": ["karanda"], "쿠툼": ["kutum"],
    "귄트": ["quint"], "무라카": ["muraka"], "미루목 파괴자 오핀": ["offin", "오핀"],
    "산군": ["sangun"], "금돼지왕": ["goldenpigking", "금돼지 왕"],
    "우투리": ["uturi"], "불가살": ["bulgasal"], "흑봉황": ["blackphoenix"],
}
SPECIAL_MODES = {name: ("개방", "기본") for name in ["아처", "스칼라", "데드아이", "오공", "세라핌"]}
SPECIAL_MODES["샤이"] = ("재능", "기본")
SPECIAL_MODES["에이전트"] = ("전승", "기본")


def subject_kind(name, custom_bosses=()):
    return "보스·몬스터" if name in BOSS_ALIASES or name in custom_bosses else "클래스"


def modes_for(name, kind=None):
    if kind == "보스·몬스터" or name in BOSS_ALIASES:
        return ("기본",)
    return SPECIAL_MODES.get(name, ("각성", "전승", "기본") if name in CLASS_ALIASES else tuple(MODE_ALIASES))


def default_mode(name, kind=None):
    return modes_for(name, kind)[0]


def compact(text: str) -> str:
    return re.sub(r"[\s_.()\[\]{}-]+", "", unicodedata.normalize("NFKC", text).casefold())


def infer_identity(relative_path: str, custom_classes=(), custom_bosses=()) -> tuple[str, str]:
    text = str(Path(relative_path).with_suffix(""))
    segments = re.split(r"[/\\]", text)
    tokens = [compact(t) for t in re.split(r"[\s/\\_.()\[\]{}-]+", text) if t]
    joined = [compact(segment) for segment in segments]
    classes, modes = set(), set()
    aliases = {**CLASS_ALIASES, **BOSS_ALIASES,
               **{name: [] for name in [*custom_classes, *custom_bosses] if name not in CLASS_ALIASES and name not in BOSS_ALIASES}}
    for mode, alts in MODE_ALIASES.items():
        if any(compact(a) in tokens for a in [mode, *alts]):
            modes.add(mode)
    for name, alts in aliases.items():
        for alias in [name, *alts]:
            alias = compact(alias)
            if alias in tokens or any(re.sub(r"\d+$", "", s) == alias for s in joined):
                classes.add(name)
            for mode, mode_alts in MODE_ALIASES.items():
                for mode_alias in [mode, *mode_alts]:
                    combinations = {alias + compact(mode_alias), compact(mode_alias) + alias}
                    if any(re.sub(r"\d+$", "", s) in combinations for s in joined):
                        classes.add(name)
                        modes.add(mode)
    name=next(iter(classes)) if len(classes)==1 else ""
    mode=next(iter(modes)) if len(modes)==1 else ""
    if name and not modes and (name in SPECIAL_MODES or subject_kind(name,custom_bosses)=="보스·몬스터"):
        mode=default_mode(name,subject_kind(name,custom_bosses))
    return name,mode


def load_image(path_or_bytes) -> Image.Image:
    source = io.BytesIO(path_or_bytes) if isinstance(path_or_bytes, bytes) else path_or_bytes
    with warnings.catch_warnings():
        warnings.simplefilter("error", Image.DecompressionBombWarning)
        with Image.open(source) as image:
            image.load()
            image = ImageOps.exif_transpose(image)
            if image.mode in ("RGBA", "LA") or "transparency" in image.info:
                rgba = image.convert("RGBA")
                background = Image.new("RGBA", rgba.size, (24, 26, 31, 255))
                return Image.alpha_composite(background, rgba).convert("RGB")
            return image.convert("RGB")


def png_bytes(path_or_image) -> bytes:
    image = path_or_image if isinstance(path_or_image, Image.Image) else load_image(path_or_image)
    output = io.BytesIO()
    image.save(output, "PNG")
    return output.getvalue()


@dataclass
class LibraryEntry:
    path: str
    relative: str
    class_name: str = ""
    mode: str = ""
    skipped: bool = False
    error: str = ""
    status: str = ""
    asset_id: str = ""
    kind: str = "클래스"


def validate_entries(entries: list[LibraryEntry]) -> list[LibraryEntry]:
    counts = Counter((e.class_name, e.mode) for e in entries
                     if not e.skipped and not e.error and e.class_name and e.mode)
    for entry in entries:
        if entry.skipped:
            entry.status = "사용 제외"
        elif entry.error:
            entry.status = "이미지 읽기 실패"
        elif not entry.class_name:
            entry.status = "클래스 인식 불가 · 직접 지정"
        elif not entry.mode:
            entry.status = "전투계열 인식 불가 · 직접 지정"
        elif entry.mode not in modes_for(entry.class_name,entry.kind):
            entry.status = "전투계열 확인 필요 · "+" / ".join(modes_for(entry.class_name,entry.kind))
        elif counts[entry.class_name, entry.mode] > 1:
            entry.status = "중복 · 사용할 그림 하나를 남기세요"
        else:
            entry.status = "연결 완료"
    return entries


def scan_library(folder: str, overrides: dict | None = None, custom_classes=(), custom_bosses=()) -> list[LibraryEntry]:
    root = Path(folder).expanduser().resolve()
    if not root.is_dir():
        raise ValueError("기본 그림 폴더를 찾을 수 없습니다.")
    entries = []
    for file in sorted(root.rglob("*")):
        if not file.is_file() or file.suffix.lower() not in EXTENSIONS:
            continue
        if file.is_symlink():
            continue
        relative = file.relative_to(root).as_posix()
        name, mode = infer_identity(relative, custom_classes, custom_bosses)
        entry = LibraryEntry(str(file), relative, name, mode, kind=subject_kind(name,custom_bosses))
        saved = (overrides or {}).get(str(file), {})
        if isinstance(saved, dict):
            entry.class_name = str(saved.get("class_name", name))[:80]
            entry.mode = str(saved.get("mode", mode))[:40]
            entry.skipped = bool(saved.get("skipped", False))
            entry.kind = saved.get("kind",subject_kind(entry.class_name,custom_bosses))
        try:
            load_image(file)
        except Exception as exc:
            entry.error = str(exc)
        entries.append(entry)
    return validate_entries(entries)


def default_layers(font_path="") -> list[dict]:
    return [dict(id="mode", text="각성", x=50.0, y=73.0, size=26, color="#f0d6a2", font=font_path, stroke=1),
            dict(id="class", text="다크나이트", x=50.0, y=81.0, size=54, color="#f0d6a2", font=font_path, stroke=1),
            dict(id="name", text="나의 캐릭터", x=50.0, y=89.0, size=25, color="#f0d6a2", font=font_path, stroke=1)]


def find_fonts() -> list[str]:
    roots = [Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"] if sys.platform == "win32" else (
        [Path("/System/Library/Fonts"), Path("/Library/Fonts"), Path.home()/"Library/Fonts"] if sys.platform == "darwin"
        else [Path("/usr/share/fonts"), Path("/usr/local/share/fonts"), Path.home()/".local/share/fonts", Path.home()/".fonts"])
    found = []
    for root in roots:
        if root.exists():
            try:
                found.extend(str(p) for p in root.rglob("*") if p.suffix.lower() in {".ttf", ".otf", ".ttc"})
            except OSError:
                pass
    def rank(path):
        value = Path(path).name.casefold()
        preferred = ["malgun.ttf", "applesdgothicneo.ttc", "notosanscjk", "nanumgothic", "notosanskr"]
        return (next((i for i, name in enumerate(preferred) if name in value), 20), value)
    return sorted(set(found), key=rank)


def render_portrait(image: Image.Image | None, layers: list[dict], zoom=100.0, pan_x=0.0,
                    pan_y=0.0, shade=65.0, supersample=2) -> tuple[Image.Image, dict]:
    width, height = SIZE[0]*supersample, SIZE[1]*supersample
    if image is None:
        canvas = Image.new("RGB", (width, height), "#242a32")
    else:
        scale = max(width/image.width, height/image.height)*max(100, min(300, float(zoom)))/100
        crop_width, crop_height = min(image.width,width/scale), min(image.height,height/scale)
        left = max(0,(image.width-crop_width)/2*(1+max(-100,min(100,float(pan_x)))/100))
        top = max(0,(image.height-crop_height)/2*(1+max(-100,min(100,float(pan_y)))/100))
        canvas = image.resize((width,height),Image.Resampling.LANCZOS,
                              box=(left,top,min(image.width,left+crop_width),min(image.height,top+crop_height)))
    if shade:
        mask = Image.new("L", (1, height))
        mask.putdata([int(max(0, (y/height-.55)/.45)*2.55*min(100,max(0,float(shade)))) for y in range(height)])
        canvas = Image.composite(Image.new("RGB", canvas.size, "#080b10"), canvas, mask.resize(canvas.size))
    draw = ImageDraw.Draw(canvas)
    boxes = {}
    for layer in layers:
        if not layer.get("text"):
            continue
        size = round(max(10, min(160, float(layer.get("size", 40))))*supersample)
        font = ImageFont.truetype(layer["font"], size) if layer.get("font") and Path(layer["font"]).is_file() else ImageFont.load_default(size=size)
        x, y = float(layer.get("x", 50))*width/100, float(layer.get("y", 80))*height/100
        stroke = round(max(0, min(8,float(layer.get("stroke", 1))))*supersample)
        text = str(layer["text"])
        draw.text((x+supersample,y+supersample), text, font=font, anchor="mm", fill="#090b10", stroke_width=stroke, stroke_fill="#090b10")
        draw.text((x,y), text, font=font, anchor="mm", fill=layer.get("color", "#ffffff"), stroke_width=stroke, stroke_fill="#141820")
        box = draw.textbbox((x,y), text, font=font, anchor="mm", stroke_width=stroke)
        boxes[layer["id"]] = tuple(value/supersample for value in box)
    return canvas.resize(SIZE, Image.Resampling.LANCZOS), boxes


def safe_name(text: str) -> str:
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", text).strip(" .")[:100] or "portrait"
    if value.split(".")[0].upper() in {"CON", "PRN", "AUX", "NUL", *[f"COM{i}" for i in range(1,10)], *[f"LPT{i}" for i in range(1,10)]}:
        value = "_"+value
    return value


def atomic_json(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name+".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def export_bundle(folder: str, title: str, source: Image.Image, portrait: Image.Image, project: dict) -> Path:
    root = Path(folder).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    stem = safe_name(title)+"_"+datetime.now().strftime("%Y%m%d_%H%M%S")
    for index in range(10000):
        target = root/(stem+(f"_{index}" if index else ""))
        try:
            target.mkdir()
            break
        except FileExistsError:
            continue
    else:
        raise OSError("저장 폴더 이름을 만들 수 없습니다.")
    source.convert("RGB").save(target/"source.png")
    portrait.convert("RGB").save(target/"portrait.bmp", "BMP")
    portrait.save(target/"portrait.png")
    public_project = {key:value for key,value in project.items() if key not in {"api_key", "key"}}
    public_project.update(schema=1, source="source.png")
    atomic_json(target/"project.json", public_project)
    return target


def data_directory() -> Path:
    if sys.platform == "win32":
        return Path(os.environ.get("LOCALAPPDATA", str(Path.home()/"AppData/Local")))/"BDOPortraitStudio"
    if sys.platform == "darwin":
        return Path.home()/"Library/Application Support/BDOPortraitStudio"
    return Path(os.environ.get("XDG_DATA_HOME", str(Path.home()/".local/share")))/"bdo-portrait-studio"


def apply_with_backup(target: str, portrait: Image.Image, backup_root: Path) -> Path:
    path = Path(target).resolve()
    if not path.is_file() or path.suffix.lower() != ".bmp":
        raise ValueError("교체할 기존 BMP 파일을 선택해 주세요.")
    backup_root.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup = backup_root/(stamp+".bmp")
    original = path.read_bytes()
    backup.write_bytes(original)
    atomic_json(backup.with_suffix(".json"), {"target":str(path), "sha256":hashlib.sha256(original).hexdigest()})
    temporary = path.with_name(path.name+".portrait-studio.tmp")
    portrait.convert("RGB").save(temporary, "BMP")
    temporary.replace(path)
    return backup
