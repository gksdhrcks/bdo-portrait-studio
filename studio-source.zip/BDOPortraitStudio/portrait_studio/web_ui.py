from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from PIL import Image, ImageTk

from .desktop import open_folder, register_file_drop


class WebWorkspace:
    """A visible, user-operated handoff; no browser/session automation."""
    def __init__(self, app):
        self.app = app
        self.service = app.web_tasks
        self.window = tk.Toplevel(app.root)
        self.window.title("ChatGPT 웹 작업 · 준비 → 웹에서 생성 → 결과 가져오기")
        self.window.geometry("850x740")
        self.window.minsize(700, 660)
        self.window.transient(app.root)
        self.photos = {}
        self.task_ids = []
        self.task_id = ""
        self.note = tk.StringVar(value="현재 클래스와 참조 그림으로 새 작업을 준비해 주세요.")
        self.folder = tk.StringVar()
        self.model = tk.StringVar()
        self.title = tk.StringVar(value="준비된 웹 작업 없음")
        top = ttk.Frame(self.window, padding=12, style="Panel.TFrame")
        top.pack(fill="x")
        ttk.Label(top, text="ChatGPT 웹에서 직접 생성", style="Section.TLabel").pack(anchor="w")
        ttk.Label(top, text="Plus 계정으로 웹에서 로그인해 생성합니다. 이 창에서는 API 키를 사용하지 않습니다.",
                  style="Muted.TLabel", wraplength=780).pack(anchor="w", pady=(4, 8))
        row = ttk.Frame(top, style="Panel.TFrame"); row.pack(fill="x")
        self.selector = ttk.Combobox(row, state="readonly")
        self.selector.pack(side="left", fill="x", expand=True)
        self.selector.bind("<<ComboboxSelected>>", self.select)
        self.prepare_button = ttk.Button(row, text="① 현재 선택으로 새 작업 준비", command=self.prepare)
        self.prepare_button.pack(side="left", padx=(8, 0))
        ttk.Label(top, textvariable=self.title, wraplength=780).pack(anchor="w", pady=(8, 0))

        footer = ttk.Frame(self.window, padding=12, style="Panel.TFrame")
        footer.pack(side="bottom", fill="x")
        ttk.Label(footer, text="③ 다운로드한 결과 가져오기", style="Section.TLabel").pack(anchor="w")
        row = ttk.Frame(footer, style="Panel.TFrame"); row.pack(fill="x", pady=5)
        ttk.Label(row, text="웹 모델명 (선택 입력)").pack(side="left")
        ttk.Entry(row, textvariable=self.model).pack(side="left", fill="x", expand=True, padx=8)
        ttk.Label(footer, text="웹에서 사용한 실제 모델은 자동 확인되지 않습니다. 입력한 이름은 '사용자 입력'으로 기록합니다.",
                  style="Muted.TLabel", wraplength=780).pack(anchor="w")
        self.drop_zone = ttk.Label(footer, text="다운로드한 그림 파일 한 장을 여기에 끌어 놓으세요.",
                                   anchor="center", padding=12, relief="groove")
        self.drop_zone.pack(fill="x", pady=7)
        self.drop_enabled = register_file_drop(self.drop_zone, self.drop)
        if not self.drop_enabled:
            self.drop_zone.configure(text="이 실행 환경은 파일 끌어 놓기를 지원하지 않습니다. 아래 파일 선택을 사용하세요.")
        self.import_button = ttk.Button(footer, text="결과 그림 파일 선택…", command=self.choose_result)
        self.import_button.pack(fill="x")
        ttk.Label(footer, textvariable=self.note, style="Muted.TLabel", wraplength=780).pack(anchor="w", pady=(8, 0))

        body = ttk.Frame(self.window, padding=(12, 8))
        body.pack(fill="both", expand=True)
        thumbs = ttk.Frame(body, style="Panel.TFrame"); thumbs.pack(fill="x")
        self.base_thumb = ttk.Label(thumbs, text="기본 그림", anchor="center")
        self.base_thumb.pack(side="left", padx=12, pady=5)
        self.reference_thumb = ttk.Label(thumbs, text="참조 그림 없음", anchor="center")
        self.reference_thumb.pack(side="left", padx=12, pady=5)
        ttk.Label(thumbs, text="첨부 순서\n01_base.png → 기본 그림\n02_reference.png → 외부 참조 (선택)",
                  style="Muted.TLabel").pack(side="left", padx=10)
        ttk.Label(body, text="② 아래 요청문을 복사하고, 준비된 PNG 그림과 함께 ChatGPT에 넣으세요.",
                  wraplength=780).pack(anchor="w", pady=(8, 4))
        holder = ttk.Frame(body); holder.pack(fill="both", expand=True)
        self.prompt = tk.Text(holder, height=7, wrap="word", font=("TkDefaultFont", 10))
        scroll = ttk.Scrollbar(holder, orient="vertical", command=self.prompt.yview)
        self.prompt.configure(yscrollcommand=scroll.set)
        self.prompt.pack(side="left", fill="both", expand=True); scroll.pack(side="right", fill="y")
        actions = ttk.Frame(body); actions.pack(fill="x", pady=(7, 0))
        self.copy_button = ttk.Button(actions, text="요청문 복사", command=self.copy_prompt)
        self.copy_button.pack(side="left", fill="x", expand=True)
        self.folder_button = ttk.Button(actions, text="첨부 그림 폴더 열기", command=self.open_attachments)
        self.folder_button.pack(side="left", fill="x", expand=True, padx=7)
        ttk.Button(actions, text="ChatGPT 열기 ↗", command=app.open_chatgpt).pack(side="left", fill="x", expand=True)
        ttk.Entry(body, textvariable=self.folder, state="readonly").pack(fill="x", pady=(6, 0))
        self.refresh(app.vault.preference("web_active", ""))

    def refresh(self, identifier=""):
        tasks = self.service.tasks()
        self.task_ids = [task["id"] for task in tasks]
        self.selector.configure(values=[
            f"{task['created'][:19].replace('T', ' ')} · {task['project']['character']} / {task['project']['mode']}"
            f" · 결과 {len(task.get('result_ids', []))}개 · {task['id'][:6]}" for task in tasks])
        if self.task_ids:
            self.selector.current(self.task_ids.index(identifier) if identifier in self.task_ids else 0)
            self.select()
        else:
            self.task_id = ""
            for button in [self.copy_button, self.folder_button, self.import_button]:
                button.configure(state="disabled")

    def prepare(self):
        if self.app.busy:
            return
        try:
            task = self.service.create(self.app.base_image, self.app.reference_image, self.app.project_data())
            self.refresh(task["id"])
            self.note.set("준비 완료. 요청문을 복사하고, 첨부 그림 폴더의 PNG 파일을 ChatGPT에 넣으세요.")
            self.app._save_settings()
        except Exception as exc:
            messagebox.showerror("웹 작업 준비", str(exc), parent=self.window)

    def _thumbnail(self, label, digest, key, missing):
        if digest:
            picture = self.app.vault.image(digest)
            picture.thumbnail((95, 95), Image.Resampling.LANCZOS)
            self.photos[key] = ImageTk.PhotoImage(picture)
            label.configure(image=self.photos[key], text="")
        else:
            label.configure(image="", text=missing)

    def select(self, event=None):
        index = self.selector.current()
        if not 0 <= index < len(self.task_ids):
            return
        try:
            task = self.service.task(self.task_ids[index])
            folder = self.service.materialize(task["id"])
            self.task_id = task["id"]
            self.app.vault.set_preference("web_active", self.task_id)
            self.app._update_provider_ui()
            self.title.set(f"결과 연결 대상: {task['project']['character']} / {task['project']['mode']}"
                           " · 준비 당시의 글자·참조 설정으로 보관")
            self.model.set("")
            self.folder.set(str(folder))
            self.prompt.configure(state="normal"); self.prompt.delete("1.0", "end")
            self.prompt.insert("1.0", task["prompt"]); self.prompt.configure(state="disabled")
            self._thumbnail(self.base_thumb, task["base_asset"], "base", "기본 그림 없음")
            self._thumbnail(self.reference_thumb, task.get("reference_asset"), "reference", "참조 그림 없음")
            for button in [self.copy_button, self.folder_button, self.import_button]:
                button.configure(state="normal")
            self.note.set("첨부할 그림과 요청문을 확인하세요. ChatGPT의 로그인·첨부·생성·다운로드는 웹에서 직접 진행합니다.")
        except Exception as exc:
            self.task_id = ""
            for button in [self.copy_button, self.folder_button, self.import_button]:
                button.configure(state="disabled")
            self.note.set("웹 작업을 읽지 못했습니다: " + str(exc))

    def copy_prompt(self):
        if not self.task_id:
            return
        text = self.service.task(self.task_id)["prompt"]
        self.app.root.clipboard_clear(); self.app.root.clipboard_append(text)
        self.window.update_idletasks()
        self.note.set("요청문을 복사했습니다. ChatGPT 채팅창에 붙여 넣고 PNG 그림도 첨부하세요.")

    def open_attachments(self):
        if not self.task_id:
            return
        try:
            open_folder(self.service.materialize(self.task_id))
            self.note.set("열린 폴더의 01_base.png와 02_reference.png(있을 때)를 ChatGPT에 첨부하세요.")
        except Exception as exc:
            messagebox.showerror("첨부 폴더 열기", str(exc), parent=self.window)

    def choose_result(self):
        if not self.task_id:
            return
        from .app import IMAGE_TYPES
        filename = filedialog.askopenfilename(parent=self.window, title="ChatGPT에서 다운로드한 결과 그림 선택", filetypes=IMAGE_TYPES)
        if filename:
            self.drop([filename])

    def drop(self, paths):
        if not self.task_id:
            self.note.set("먼저 현재 선택으로 새 웹 작업을 준비해 주세요.")
            return False
        identifier = self.task_id
        if self.app.import_web_result(identifier, paths, self.model.get(), self.window):
            self.refresh(identifier)
            self.note.set("결과를 자료함에 보관했습니다. 메인 화면에서 글자·구도를 조절하고 저장하세요.")
            self.window.after_idle(self.app.root.lift)
            return True
        return False
