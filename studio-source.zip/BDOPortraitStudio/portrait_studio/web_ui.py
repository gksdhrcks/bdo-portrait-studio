from __future__ import annotations

import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from PIL import Image, ImageTk

from .clipboard import copy_image
from .core import load_image
from .desktop import open_folder, register_file_drag, register_file_drop

BUNDLE_REQUEST = "첨부한 작업판 상단의 요청문을 읽고, 아래 A(기본 그림)와 B(참조 그림, 있을 때)를 참고해 새로운 검은사막 초상화 한 장을 생성해 주세요. 작업판의 글자·테두리·패널 구성은 결과에 넣지 마세요."


class WebWorkspace:
    """A visible, user-operated handoff; no browser/session automation."""
    def __init__(self, app):
        self.app = app
        self.service = app.web_tasks
        self.window = tk.Toplevel(app.root)
        self.window.title("ChatGPT에 보낼 그림 준비")
        self.window.geometry("850x790")
        self.window.minsize(700, 700)
        self.window.transient(app.root)
        self.photos = {}
        self.task_ids = []
        self.task_id = ""
        self.bundle_path = None
        self.bundle_note = tk.StringVar()
        self.paste_key = "⌘V" if sys.platform == "darwin" else "Ctrl+V"
        self.note = tk.StringVar(value="현재 클래스와 참조 그림으로 새 작업을 준비해 주세요.")
        self.folder = tk.StringVar()
        self.model = tk.StringVar()
        self.title = tk.StringVar(value="준비된 웹 작업 없음")
        top = ttk.Frame(self.window, padding=12, style="Panel.TFrame")
        top.pack(fill="x")
        ttk.Label(top, text="그림과 요청을 준비하고 → ChatGPT에 붙여넣기", style="Section.TLabel").pack(anchor="w")
        ttk.Label(top, text="복사는 첨부 준비입니다. 붙여넣기와 전송은 ChatGPT에서 직접 진행하세요.",
                  style="Muted.TLabel", wraplength=780).pack(anchor="w", pady=(4, 8))
        row = ttk.Frame(top, style="Panel.TFrame"); row.pack(fill="x")
        self.selector = ttk.Combobox(row, state="readonly")
        self.selector.pack(side="left", fill="x", expand=True)
        self.selector.bind("<<ComboboxSelected>>", self.select)
        self.prepare_button = ttk.Button(row, text="현재 선택으로 새 작업", command=self.prepare)
        self.prepare_button.pack(side="left", padx=(8, 0))
        ttk.Label(top, textvariable=self.title, wraplength=780).pack(anchor="w", pady=(8, 0))

        footer = ttk.Frame(self.window, padding=12, style="Panel.TFrame")
        footer.pack(side="bottom", fill="x")
        ttk.Label(footer, text="완성된 그림 가져오기", style="Section.TLabel").pack(anchor="w")
        row = ttk.Frame(footer, style="Panel.TFrame"); row.pack(fill="x", pady=5)
        ttk.Label(row, text="웹 모델명 (선택 입력)").pack(side="left")
        ttk.Entry(row, textvariable=self.model).pack(side="left", fill="x", expand=True, padx=8)
        ttk.Label(footer, text="웹 모델명은 자동 확인되지 않으며 입력한 이름으로 기록합니다.",
                  style="Muted.TLabel", wraplength=780).pack(anchor="w")
        self.drop_zone = ttk.Label(footer, text="다운로드한 그림 파일 한 장을 여기에 끌어 놓으세요.",
                                   anchor="center", padding=12, relief="groove")
        self.drop_zone.pack(fill="x", pady=7)
        self.drop_enabled = register_file_drop(self.drop_zone, self.drop)
        if not self.drop_enabled:
            self.drop_zone.configure(text="이 실행 환경은 파일 끌어 놓기를 지원하지 않습니다. 아래 파일 선택을 사용하세요.")
        self.import_button = ttk.Button(footer, text="결과 그림 파일 선택…", command=self.choose_result)
        self.import_button.pack(fill="x")
        ttk.Label(footer, textvariable=self.note, style="Muted.TLabel", wraplength=780).pack(anchor="w", pady=(8, 0))

        body = ttk.Frame(self.window, padding=(12, 8))
        body.pack(fill="both", expand=True)
        self.tabs = ttk.Notebook(body); self.tabs.pack(fill="both", expand=True)
        quick = ttk.Frame(self.tabs, padding=12)
        original = ttk.Frame(self.tabs, padding=12)
        self.tabs.add(quick, text="간편 첨부 · 한 장으로")
        self.tabs.add(original, text="원본 그림 그대로 첨부")
        ttk.Label(quick, text="요청문 + 기본 그림 + 참조 그림을 한 장에 담았습니다.",
                  style="Section.TLabel", wraplength=650).pack(anchor="w", pady=(0,8))
        quick_row = ttk.Frame(quick); quick_row.pack(fill="both", expand=True)
        self.bundle_thumb = ttk.Label(quick_row, text="한 장 첨부 미리보기", anchor="center", relief="groove", padding=6)
        self.bundle_thumb.pack(side="left", padx=(0,12))
        quick_actions = ttk.Frame(quick_row); quick_actions.pack(side="left", fill="both", expand=True)
        self.bundle_copy_button = ttk.Button(quick_actions, text="① 한 장 복사하고 ChatGPT 열기", command=lambda:self.copy_bundle(True))
        self.bundle_copy_button.pack(fill="x", pady=(4,10))
        ttk.Label(quick_actions, text=f"② ChatGPT 입력칸을 눌러 {self.paste_key}\n③ 첨부 그림을 확인하고 전송",
                  wraplength=400).pack(anchor="w", pady=6)
        ttk.Label(quick_actions, text="이미지 안에 요청문도 들어 있습니다. 한 장만 첨부하세요. 원본 해상도가 중요하면 옆의 원본 첨부 탭을 사용하세요.",
                  style="Muted.TLabel", wraplength=400).pack(anchor="w", pady=6)
        ttk.Label(quick, textvariable=self.bundle_note, style="Muted.TLabel", wraplength=680).pack(anchor="w", pady=6)
        quick_tools = ttk.Frame(quick); quick_tools.pack(fill="x")
        self.bundle_again_button = ttk.Button(quick_tools, text="한 장 다시 복사", command=self.copy_bundle)
        self.bundle_again_button.pack(side="left")
        self.bundle_folder_button = ttk.Button(quick_tools, text="한 장 파일 위치", command=self.open_bundle)
        self.bundle_folder_button.pack(side="left", padx=6)
        ttk.Button(quick_tools, text="생성 요청 한 줄 복사", command=self.copy_bundle_request).pack(side="left")
        ttk.Button(quick, text="한글 폰트 선택…", command=self.choose_bundle_font).pack(anchor="e", pady=(5,0))
        self.bundle_drag_enabled = register_file_drag(self.bundle_thumb, lambda:[self.bundle_path] if self.bundle_path else [])

        thumbs = ttk.Frame(original, style="Panel.TFrame"); thumbs.pack(fill="x")
        self.base_thumb = ttk.Label(thumbs, text="기본 그림", anchor="center")
        self.base_thumb.pack(side="left", padx=12, pady=5)
        self.reference_thumb = ttk.Label(thumbs, text="참조 그림 없음", anchor="center")
        self.reference_thumb.pack(side="left", padx=12, pady=5)
        ttk.Label(thumbs, text="A: 기본 그림\nB: 외부 참조 (선택)", padding=10,
                  style="Muted.TLabel").pack(side="left", padx=10)
        self.original_drag = ttk.Label(original, text="원본 그림 전체를 ChatGPT로 끌어 놓기", anchor="center", relief="groove", padding=8)
        self.original_drag.pack(fill="x", pady=5)
        self.original_drag_enabled = register_file_drag(self.original_drag, self.drag_originals)
        for thumbnail in [self.base_thumb,self.reference_thumb]:register_file_drag(thumbnail,self.drag_originals)
        ttk.Label(original, text="그림은 한 번에 첨부하고 아래 요청문을 복사해 붙여넣으세요.",
                  wraplength=780).pack(anchor="w", pady=(8, 4))
        holder = ttk.Frame(original); holder.pack(fill="both", expand=True)
        self.prompt = tk.Text(holder, height=7, wrap="word", font=("TkDefaultFont", 10))
        scroll = ttk.Scrollbar(holder, orient="vertical", command=self.prompt.yview)
        self.prompt.configure(yscrollcommand=scroll.set)
        self.prompt.pack(side="left", fill="both", expand=True); scroll.pack(side="right", fill="y")
        actions = ttk.Frame(original); actions.pack(fill="x", pady=(7, 0))
        self.copy_button = ttk.Button(actions, text="요청문만 복사", command=self.copy_prompt)
        self.copy_button.pack(side="left", fill="x", expand=True)
        self.folder_button = ttk.Button(actions, text="첨부 그림 폴더 열기", command=self.open_attachments)
        self.folder_button.pack(side="left", fill="x", expand=True, padx=7)
        ttk.Button(actions, text="ChatGPT 열기 ↗", command=app.open_chatgpt).pack(side="left", fill="x", expand=True)
        ttk.Entry(original, textvariable=self.folder, state="readonly").pack(fill="x", pady=(6, 0))
        self.refresh(app.vault.preference("web_active", ""))

    def refresh(self, identifier=""):
        tasks = self.service.tasks()
        self.task_ids = [task["id"] for task in tasks]
        self.selector.configure(values=[
            f"{task['created'][:19].replace('T', ' ')} · {task['project']['character']} / {task['project']['mode']}"
            f" · 결과 {len(task.get('result_ids', []))}개 · {task['id'][:6]}" for task in tasks])
        if self.task_ids:
            self.selector.current(self.task_ids.index(identifier) if identifier in self.task_ids else 0)
            self.select()
        else:
            self.task_id = ""
            for button in [self.copy_button, self.folder_button, self.import_button,self.bundle_copy_button,self.bundle_again_button,self.bundle_folder_button]:
                button.configure(state="disabled")

    def prepare(self, reuse=False):
        if self.app.busy:
            return
        try:
            task = self.service.create(self.app.base_image, self.app.reference_image, self.app.project_data(),reuse=reuse)
            self.refresh(task["id"])
            self.note.set("준비 완료. '한 장 복사하고 ChatGPT 열기'를 눌러 시작하세요.")
            self.app._save_settings()
        except Exception as exc:
            messagebox.showerror("웹 작업 준비", str(exc), parent=self.window)

    def _thumbnail(self, label, digest, key, missing):
        if digest:
            picture = self.app.vault.image(digest)
            picture.thumbnail((95, 95), Image.Resampling.LANCZOS)
            self.photos[key] = ImageTk.PhotoImage(picture)
            label.configure(image=self.photos[key], text="")
        else:
            label.configure(image="", text=missing)

    def select(self, event=None):
        index = self.selector.current()
        if not 0 <= index < len(self.task_ids):
            return
        try:
            task = self.service.task(self.task_ids[index])
            folder = self.service.materialize(task["id"])
            self.task_id = task["id"]
            self.app.vault.set_preference("web_active", self.task_id)
            self.app._update_provider_ui()
            self.title.set(f"결과 연결 대상: {task['project']['character']} / {task['project']['mode']}"
                           " · 준비 당시의 글자·참조 설정으로 보관")
            self.model.set("")
            self.folder.set(str(folder))
            self.prompt.configure(state="normal"); self.prompt.delete("1.0", "end")
            self.prompt.insert("1.0", task["prompt"]); self.prompt.configure(state="disabled")
            self._thumbnail(self.base_thumb, task["base_asset"], "base", "기본 그림 없음")
            self._thumbnail(self.reference_thumb, task.get("reference_asset"), "reference", "참조 그림 없음")
            for button in [self.copy_button, self.folder_button, self.import_button]:
                button.configure(state="normal")
            self.show_bundle()
            self.note.set("선택한 작업의 그림과 요청을 확인한 뒤 간편 첨부 또는 원본 첨부를 선택하세요.")
        except Exception as exc:
            self.task_id = ""
            for button in [self.copy_button, self.folder_button, self.import_button]:
                button.configure(state="disabled")
            self.note.set("웹 작업을 읽지 못했습니다: " + str(exc))

    def show_bundle(self):
        self.bundle_path = None
        try:
            self.bundle_path = self.service.bundle(self.task_id)
            image = load_image(self.bundle_path); image.thumbnail((160,190),Image.Resampling.LANCZOS)
            self.photos["bundle"] = ImageTk.PhotoImage(image,master=self.window)
            self.bundle_thumb.configure(image=self.photos["bundle"],text="")
            self.bundle_note.set("미리보기를 ChatGPT로 끌어 놓아도 됩니다." if self.bundle_drag_enabled else "그림 복사를 지원하지 않으면 '한 장 파일 위치'에서 PNG 한 장을 첨부하세요.")
            for button in [self.bundle_copy_button,self.bundle_again_button,self.bundle_folder_button]:button.configure(state="normal")
        except Exception as exc:
            self.bundle_thumb.configure(image="",text="한 장 첨부 준비 필요")
            self.bundle_note.set(str(exc))
            for button in [self.bundle_copy_button,self.bundle_again_button,self.bundle_folder_button]:button.configure(state="disabled")

    def copy_bundle(self, open_browser=False):
        if not self.task_id:return
        try:
            path = self.service.bundle(self.task_id)
            copy_image(self.app.root,path,BUNDLE_REQUEST)
            self.note.set(f"그림을 복사했습니다. ChatGPT 입력칸에서 {self.paste_key}로 붙인 뒤 첨부를 확인하고 전송하세요. 요청문은 그림 안에도 있습니다.")
            if open_browser:self.app.open_chatgpt()
        except Exception as exc:
            self.note.set(f"그림을 복사하지 못했습니다: {exc} · '한 장 파일 위치'에서 PNG 한 장을 직접 첨부하세요.")

    def copy_bundle_request(self):
        self.app.root.clipboard_clear();self.app.root.clipboard_append(BUNDLE_REQUEST)
        self.window.update_idletasks()
        self.note.set("생성 요청 한 줄을 복사했습니다. 한 장 그림을 첨부한 ChatGPT 입력칸에 붙여넣으세요.")

    def open_bundle(self):
        if not self.task_id:return
        try:
            path=self.service.bundle(self.task_id);open_folder(path.parent)
            self.note.set("ChatGPT_한장첨부.png 한 장만 ChatGPT에 첨부하세요. 요청문과 두 그림이 들어 있습니다.")
        except Exception as exc:self.note.set(str(exc))

    def choose_bundle_font(self):
        path=filedialog.askopenfilename(parent=self.window,title="한 장 첨부에 쓸 한글 폰트",filetypes=[("폰트","*.ttf *.otf *.ttc")])
        if not path:return
        from pathlib import Path
        from .handoff import korean_font
        try:
            if korean_font([path])!=path:raise ValueError("선택한 폰트가 한글을 지원하지 않습니다.")
            self.app.vault.set_preference("web_bundle_font",self.app.vault.put_blob(Path(path).read_bytes(),"font",Path(path).suffix.lower()))
            if self.task_id:self.show_bundle()
        except Exception as exc:self.note.set(str(exc))

    def drag_originals(self):
        if not self.task_id:return []
        self.copy_prompt()
        self.note.set(f"원본 그림을 모두 끌어 놓은 뒤 {self.paste_key}로 준비된 요청문을 붙여넣으세요.")
        return self.service.attachments(self.task_id)

    def copy_prompt(self):
        if not self.task_id:
            return
        text = self.service.task(self.task_id)["prompt"]
        self.app.root.clipboard_clear(); self.app.root.clipboard_append(text)
        self.window.update_idletasks()
        self.note.set("요청문을 복사했습니다. ChatGPT 채팅창에 붙여 넣고 PNG 그림도 첨부하세요.")

    def open_attachments(self):
        if not self.task_id:
            return
        try:
            open_folder(self.service.materialize(self.task_id))
            self.note.set("열린 폴더의 01_base.png와 02_reference.png(있을 때)를 ChatGPT에 첨부하세요.")
        except Exception as exc:
            messagebox.showerror("첨부 폴더 열기", str(exc), parent=self.window)

    def choose_result(self):
        if not self.task_id:
            return
        from .app import IMAGE_TYPES
        filename = filedialog.askopenfilename(parent=self.window, title="ChatGPT에서 다운로드한 결과 그림 선택", filetypes=IMAGE_TYPES)
        if filename:
            self.drop([filename])

    def drop(self, paths):
        if not self.task_id:
            self.note.set("먼저 현재 선택으로 새 웹 작업을 준비해 주세요.")
            return False
        identifier = self.task_id
        if self.app.import_web_result(identifier, paths, self.model.get(), self.window):
            self.refresh(identifier)
            self.note.set("결과를 자료함에 보관했습니다. 메인 화면에서 글자·구도를 조절하고 저장하세요.")
            self.window.after_idle(self.app.root.lift)
            return True
        return False
