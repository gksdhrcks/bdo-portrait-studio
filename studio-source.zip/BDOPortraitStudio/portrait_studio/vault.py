"""A self-contained, cross-platform picture library. No external image paths required."""
from __future__ import annotations

import copy
import hashlib
import json
import re
import sqlite3
import sys
import uuid
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

from .core import LibraryEntry, data_directory, load_image, png_bytes, validate_entries, subject_kind

APPLICATION_ID = 0x42445053
MAX_BLOB = 128 * 1024 * 1024
SCHEMA = {
    "blobs": "CREATE TABLE blobs (hash TEXT PRIMARY KEY, kind TEXT NOT NULL, extension TEXT NOT NULL, payload BLOB NOT NULL)",
    "library": "CREATE TABLE library (id TEXT PRIMARY KEY, label TEXT NOT NULL, image_hash TEXT NOT NULL, class_name TEXT NOT NULL, mode TEXT NOT NULL, skipped INTEGER NOT NULL)",
    "results": "CREATE TABLE results (id TEXT PRIMARY KEY, class_name TEXT NOT NULL, mode TEXT NOT NULL, created TEXT NOT NULL, image_hash TEXT NOT NULL, preview_hash TEXT NOT NULL, project TEXT NOT NULL)",
    "prefs": "CREATE TABLE prefs (key TEXT PRIMARY KEY, payload TEXT NOT NULL)",
}


def program_directory() -> Path:
    if getattr(sys, "frozen", False):
        executable=Path(sys.executable).resolve()
        app=next((parent for parent in executable.parents if parent.suffix==".app"),None)
        return app.parent if app else executable.parent
    return Path(__file__).resolve().parent.parent


def select_data_directory(explicit=None, portable=False) -> Path:
    if explicit:return Path(explicit).expanduser().resolve()
    program=program_directory()
    if portable or (program/"portable.txt").is_file():
        candidate=program/"StudioData"
        try:
            candidate.mkdir(parents=True,exist_ok=True)
            probe=candidate/(".write-check-"+uuid.uuid4().hex)
            probe.write_bytes(b"");probe.unlink()
            old=data_directory()/"settings.json"
            if not (candidate/"settings.json").exists() and not (candidate/"PortraitLibrary.bdostudio").exists() and old.is_file():
                (candidate/"settings.json").write_bytes(old.read_bytes())
            return candidate
        except OSError:
            if portable:raise ValueError("프로그램 폴더에 쓸 수 없습니다. --data-dir로 자료함 위치를 지정해 주세요.")
    return data_directory()


def without_secrets(value):
    if isinstance(value,dict):
        return {key:without_secrets(item) for key,item in value.items()
                if not re.search(r"api[_-]?key|access[_-]?token|refresh[_-]?token|password|authorization|secret|^token$",str(key),re.I)}
    if isinstance(value,list):return [without_secrets(item) for item in value]
    return value


class Vault:
    def __init__(self,root: Path):
        self.root=Path(root).resolve()
        self.root.mkdir(parents=True,exist_ok=True)
        self.path=self.root/"PortraitLibrary.bdostudio"
        existed=self.path.is_file() and self.path.stat().st_size>0
        self.cache=self.root/"cache"
        self.cache.mkdir(exist_ok=True)
        self.file_cache={}
        with self.connect() as connection:
            if existed:
                if connection.execute("PRAGMA application_id").fetchone()[0]!=APPLICATION_ID or connection.execute("PRAGMA user_version").fetchone()[0]!=1:
                    raise ValueError("자료함 파일 형식 또는 버전을 확인해 주세요. 기존 파일은 변경하지 않았습니다.")
            else:
                connection.execute(f"PRAGMA application_id={APPLICATION_ID}")
                connection.execute("PRAGMA user_version=1")
            existing={row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            for name,statement in SCHEMA.items():
                if name not in existing:connection.execute(statement)

    @contextmanager
    def connect(self):
        connection=sqlite3.connect(self.path,timeout=30)
        connection.row_factory=sqlite3.Row
        try:
            with connection:yield connection
        finally:connection.close()

    def put_blob(self,payload: bytes,kind="image",extension=".png") -> str:
        if len(payload)>MAX_BLOB:raise ValueError("한 파일이 128MB를 넘습니다. 크기를 줄인 뒤 등록해 주세요.")
        if extension.lower() not in {".png",".jpg",".jpeg",".webp",".bmp",".ttf",".otf",".ttc",".json"}:raise ValueError("자료함에서 지원하지 않는 파일 형식입니다.")
        digest=hashlib.sha256(payload).hexdigest()
        with self.connect() as connection:
            connection.execute("INSERT OR IGNORE INTO blobs VALUES (?,?,?,?)",(digest,kind,extension.lower(),payload))
        return digest

    def blob(self,digest):
        if not isinstance(digest,str) or not re.fullmatch(r"[a-f0-9]{64}",digest):raise ValueError("자료함 그림 번호가 올바르지 않습니다.")
        with self.connect() as connection:
            row=connection.execute("SELECT payload,extension FROM blobs WHERE hash=?",(digest,)).fetchone()
        if row is None:raise ValueError("자료함에서 그림 또는 폰트를 찾을 수 없습니다.")
        return bytes(row["payload"]),row["extension"]

    def materialize(self,digest):
        payload,extension=self.blob(digest)
        path=self.cache/(digest+extension)
        if not path.is_file() or path.stat().st_size!=len(payload):
            temporary=self.cache/(uuid.uuid4().hex+".tmp")
            temporary.write_bytes(payload);temporary.replace(path)
        return path

    def image(self,digest):return load_image(self.materialize(digest))

    def put_image(self,image,kind="image"):return self.put_blob(png_bytes(image),kind,".png")

    def import_entries(self,entries):
        custom_bosses=self.preference("custom_bosses",[])
        for entry in entries:
            if entry.kind=="보스·몬스터" and entry.class_name and entry.class_name not in custom_bosses:custom_bosses.append(entry.class_name)
        self.set_preference("custom_bosses",custom_bosses)
        with self.connect() as connection:
            previous={row["id"]:dict(row) for row in connection.execute("SELECT * FROM library")}
        rows=[]
        for entry in entries:
            digest=self.put_blob(Path(entry.path).read_bytes(),"base",Path(entry.path).suffix)
            identifier=entry.asset_id or hashlib.sha256(str(Path(entry.path).resolve()).encode("utf-8")).hexdigest()[:32]
            old=previous.get(identifier)
            if old:
                name,mode,skipped=old["class_name"],old["mode"],old["skipped"]
            else:name,mode,skipped=entry.class_name,entry.mode,int(entry.skipped)
            rows.append((identifier,entry.relative,digest,name,mode,skipped))
        with self.connect() as connection:
            connection.executemany("INSERT OR REPLACE INTO library VALUES (?,?,?,?,?,?)",rows)
        return self.entries()

    def entries(self):
        with self.connect() as connection:rows=connection.execute("SELECT * FROM library ORDER BY label,id").fetchall()
        entries=[]
        custom_bosses=self.preference("custom_bosses",[])
        for row in rows:
            error="";path=""
            try:path=str(self.materialize(row["image_hash"]));load_image(path)
            except Exception as exc:error=str(exc)
            entries.append(LibraryEntry(path,row["label"],row["class_name"],row["mode"],bool(row["skipped"]),error,asset_id=row["id"],kind=subject_kind(row["class_name"],custom_bosses)))
        return validate_entries(entries)

    def update_entries(self,entries):
        rows=[(entry.class_name,entry.mode,int(entry.skipped),entry.asset_id) for entry in entries if entry.asset_id]
        with self.connect() as connection:
            connection.executemany("UPDATE library SET class_name=?,mode=?,skipped=? WHERE id=?",rows)

    def pack_project(self,project):
        data=copy.deepcopy(project)
        for layer in data.get("layers",[]):
            font=layer.get("font","")
            if font and not font.startswith("vault:") and Path(font).is_file():
                path=Path(font);stamp=(str(path),path.stat().st_size,path.stat().st_mtime_ns)
                digest=self.file_cache.get(stamp)
                if not digest:
                    digest=self.put_blob(path.read_bytes(),"font",path.suffix);self.file_cache[stamp]=digest
                layer.setdefault("font_name",path.name)
                layer["font"]="vault:"+digest
        return without_secrets(data)

    def unpack_project(self,project):
        data=copy.deepcopy(project)
        for layer in data.get("layers",[]):
            font=layer.get("font","")
            if isinstance(font,str) and font.startswith("vault:"):
                try:layer["font"]=str(self.materialize(font[6:]))
                except (OSError,ValueError):layer["font"]=""
        return data

    def pack_preferences(self,preferences):
        data=self.pack_project(preferences)
        workflow=data.get("ai",{}).get("workflow","")
        if workflow and not workflow.startswith("vault:") and Path(workflow).is_file():
            graph=without_secrets(json.loads(Path(workflow).read_text(encoding="utf-8-sig")))
            data["ai"]["workflow"]="vault:"+self.put_blob(json.dumps(graph,ensure_ascii=False).encode("utf-8"),"workflow",".json")
        return data

    def unpack_preferences(self,preferences):
        data=self.unpack_project(preferences)
        workflow=data.get("ai",{}).get("workflow","")
        if isinstance(workflow,str) and workflow.startswith("vault:"):
            try:data["ai"]["workflow"]=str(self.materialize(workflow[6:]))
            except (OSError,ValueError):data["ai"]["workflow"]=""
        return data

    def preference(self,key,default=None):
        with self.connect() as connection:row=connection.execute("SELECT payload FROM prefs WHERE key=?",(key,)).fetchone()
        return json.loads(row["payload"]) if row else default

    def set_preference(self,key,value):
        with self.connect() as connection:
            connection.execute("INSERT OR REPLACE INTO prefs VALUES (?,?)",(key,json.dumps(without_secrets(value),ensure_ascii=False)))

    def save_preferences(self,data):self.set_preference("settings",self.pack_preferences(data))
    def load_preferences(self):return self.unpack_preferences(self.preference("settings",{}))

    def save_draft(self,key,project,view="기본 그림",result_id=None):
        drafts=self.preference("drafts",{})
        drafts[json.dumps(list(key),ensure_ascii=False)]={"project":self.pack_project(project),"view":view,"result_id":result_id}
        self.set_preference("drafts",drafts)

    def draft(self,key):
        value=self.preference("drafts",{}).get(json.dumps(list(key),ensure_ascii=False))
        if value:value={**value,"project":self.unpack_project(value["project"])}
        return value

    def add_result(self,image,preview,project,identifier=None):
        identifier=identifier or uuid.uuid4().hex
        image_hash=self.put_image(image,"result")
        preview_hash=self.put_image(preview,"preview")
        packed=self.pack_project(project)
        packed["source_asset"]=image_hash
        with self.connect() as connection:
            old=connection.execute("SELECT created FROM results WHERE id=?",(identifier,)).fetchone()
            created=old[0] if old else datetime.now().astimezone().isoformat(timespec="seconds")
            connection.execute("INSERT OR REPLACE INTO results VALUES (?,?,?,?,?,?,?)",(identifier,str(project["character"]),str(project["mode"]),created,image_hash,preview_hash,json.dumps(packed,ensure_ascii=False)))
        return identifier

    def update_result(self,identifier,preview,project):
        preview_hash=self.put_image(preview,"preview")
        with self.connect() as connection:old=connection.execute("SELECT image_hash,preview_hash FROM results WHERE id=?",(identifier,)).fetchone()
        if old is None:return
        packed=self.pack_project(project);packed["source_asset"]=old[0]
        with self.connect() as connection:
            connection.execute("UPDATE results SET preview_hash=?,project=? WHERE id=?",(preview_hash,json.dumps(packed,ensure_ascii=False),identifier))
            previous=old["preview_hash"]
            if previous!=preview_hash:
                connection.execute("DELETE FROM blobs WHERE hash=? AND kind='preview' AND NOT EXISTS (SELECT 1 FROM results WHERE image_hash=? OR preview_hash=? OR project LIKE ?) AND NOT EXISTS (SELECT 1 FROM library WHERE image_hash=?) AND NOT EXISTS (SELECT 1 FROM prefs WHERE payload LIKE ?)",(previous,previous,previous,'%'+previous+'%',previous,'%'+previous+'%'))

    def results(self,key=None):
        with self.connect() as connection:
            if key:rows=connection.execute("SELECT id,class_name,mode,created,preview_hash FROM results WHERE class_name=? AND mode=? ORDER BY created DESC,rowid DESC",tuple(key)).fetchall()
            else:rows=connection.execute("SELECT id,class_name,mode,created,preview_hash FROM results ORDER BY created DESC,rowid DESC").fetchall()
        return [dict(row) for row in rows]

    def result(self,identifier):
        with self.connect() as connection:row=connection.execute("SELECT * FROM results WHERE id=?",(identifier,)).fetchone()
        if row is None:raise ValueError("보관된 결과를 찾을 수 없습니다.")
        data=dict(row);data["project"]=self.unpack_project(json.loads(data["project"]))
        data["image"]=self.image(data["image_hash"])
        return data

    def export_backup(self,filename):
        target=Path(filename).expanduser().resolve()
        if target==self.path:raise ValueError("현재 사용 중인 자료함과 다른 파일명을 선택해 주세요.")
        target.parent.mkdir(parents=True,exist_ok=True)
        temporary=target.with_name(target.name+"."+uuid.uuid4().hex+".tmp")
        destination=sqlite3.connect(temporary)
        try:
            with self.connect() as source:source.backup(destination)
        finally:destination.close()
        temporary.replace(target)
        return target

    @staticmethod
    def validate_backup(connection):
        if connection.execute("PRAGMA application_id").fetchone()[0]!=APPLICATION_ID or connection.execute("PRAGMA user_version").fetchone()[0]!=1:
            raise ValueError("지원하는 초상화 자료함 파일이 아닙니다.")
        if connection.execute("PRAGMA quick_check").fetchone()[0]!="ok":raise ValueError("자료함 파일이 손상됐습니다.")
        found={row[0]:row[1] for row in connection.execute("SELECT name,sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
        normalize=lambda text:re.sub(r"\s+","",text).casefold()
        if set(found)!=set(SCHEMA) or any(normalize(found[name])!=normalize(SCHEMA[name]) for name in SCHEMA):
            raise ValueError("자료함 구조가 올바르지 않습니다.")
        if connection.execute("SELECT count(*) FROM sqlite_master WHERE type IN ('trigger','view')").fetchone()[0]:
            raise ValueError("지원하지 않는 자료함 구조입니다.")
        for digest,payload,extension in connection.execute("SELECT hash,payload,extension FROM blobs"):
            if len(payload)>MAX_BLOB or hashlib.sha256(payload).hexdigest()!=digest or extension not in {".png",".jpg",".jpeg",".webp",".bmp",".ttf",".otf",".ttc",".json"}:
                raise ValueError("자료함 내부 파일의 검증에 실패했습니다.")
        for (payload,) in connection.execute("SELECT payload FROM prefs"):
            if len(payload)>5_000_000:raise ValueError("자료함 설정이 너무 큽니다.")
            json.loads(payload)

    def restore_backup(self,filename):
        source_path=Path(filename).expanduser().resolve()
        if source_path==self.path:raise ValueError("현재 사용 중인 자료함입니다.")
        source=sqlite3.connect(source_path.as_uri()+"?mode=ro",uri=True)
        try:
            if hasattr(source,"setlimit"):source.setlimit(sqlite3.SQLITE_LIMIT_LENGTH,MAX_BLOB+1024*1024)
            self.validate_backup(source)
            recovery=self.root/"recovery"/("before-import-"+datetime.now().strftime("%Y%m%d-%H%M%S-%f")+".bdostudio")
            self.export_backup(recovery)
            with self.connect() as destination:source.backup(destination)
        finally:source.close()
        settings=self.preference("settings",{})
        self.set_preference("settings",without_secrets(settings))
        self.file_cache.clear()
        return recovery
