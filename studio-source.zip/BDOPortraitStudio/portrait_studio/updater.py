"""Verified release downloads and a separate, restart-safe installer."""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import time
import urllib.parse
import urllib.request
import uuid
import zipfile
from pathlib import Path, PurePosixPath

from .core import atomic_json

APP_ID = "bdo-portrait-studio"
DEFAULT_REPOSITORY = "gksdhrcks/bdo-portrait-studio"
MAX_DOWNLOAD = 256 * 1024 * 1024
MAX_EXTRACT = 512 * 1024 * 1024


def version_tuple(value):
    if not isinstance(value,str) or not re.fullmatch(r"\d{1,4}\.\d{1,4}\.\d{1,4}",value):
        raise ValueError("올바른 업데이트 버전이 아닙니다.")
    return tuple(map(int,value.split(".")))


def github_feed(repository):
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+",repository):
        raise ValueError("GitHub 저장소를 사용자이름/저장소이름 형식으로 입력하세요.")
    return f"https://github.com/{repository}/releases/latest/download/update.json"


def package_target():
    if not getattr(sys,"frozen",False):return "source"
    machine=platform.machine().lower()
    architecture="arm64" if machine in {"arm64","aarch64"} else "x64"
    return {"win32":"windows","darwin":"macos"}.get(sys.platform,"linux")+"-"+architecture


def _open(location):
    if location.startswith("https://"):
        request=urllib.request.Request(location,headers={"User-Agent":"BDOPortraitStudio-Updater","Cache-Control":"no-cache"})
        response=urllib.request.urlopen(request,timeout=30)
        if not response.geturl().startswith("https://"):
            response.close();raise ValueError("업데이트 연결이 HTTPS를 벗어났습니다.")
        return response
    if "://" in location:raise ValueError("업데이트 주소는 HTTPS 또는 로컬 파일 경로여야 합니다.")
    return open(Path(location).expanduser(),"rb")


def _asset_location(feed,filename):
    if not isinstance(filename,str) or not re.fullmatch(r"[A-Za-z0-9_.-]+\.zip",filename):
        raise ValueError("업데이트 파일 이름이 올바르지 않습니다.")
    if feed.startswith("https://"):
        return urllib.parse.urljoin(feed,filename)
    return str(Path(feed).resolve().parent/filename)


def check_release(feed,current_version,target=None):
    with _open(feed) as response:raw=response.read(1024*1024+1)
    if len(raw)>1024*1024:raise ValueError("업데이트 정보 파일이 너무 큽니다.")
    manifest=json.loads(raw.decode("utf-8"))
    if manifest.get("schema")!=1 or manifest.get("app")!=APP_ID:raise ValueError("초상화 스튜디오의 업데이트 정보가 아닙니다.")
    latest=version_tuple(manifest.get("version"));current=version_tuple(current_version)
    target=target or package_target()
    package=manifest.get("packages",{}).get(target)
    if latest>current and not package:raise ValueError("이 운영체제용 업데이트 파일이 아직 배포되지 않았습니다.")
    if package:
        if not re.fullmatch(r"[a-f0-9]{64}",str(package.get("sha256",""))):raise ValueError("업데이트 검증 번호가 없습니다.")
        if not isinstance(package.get("size"),int) or not 0<package["size"]<=MAX_DOWNLOAD:raise ValueError("업데이트 크기가 올바르지 않습니다.")
        location=_asset_location(feed,package.get("file"))
    else:location=""
    return dict(version=manifest["version"],available=latest>current,target=target,
                notes=str(manifest.get("notes",""))[:12000],package=package,location=location,feed=feed)


def app_file(relative,target):
    parts=PurePosixPath(relative).parts
    if not parts or any(p in {".","..","StudioData",".venv","__pycache__"} or ":" in p for p in parts):return False
    common={"README.md","LICENSE","VERIFICATION.md","portable.txt","release-info.json","RELEASE_NOTES.md"}
    if len(parts)==1 and parts[0] in common:return True
    if parts[0]=="ThirdPartyLicenses" and len(parts)>1:return True
    if target=="source":
        if len(parts)==1 and parts[0] in {"run.py","build.py","requirements.txt","start.bat","start.sh","start.command",".gitignore","publish_release.py"}:return True
        if parts[0] in {"portrait_studio","tests"} and len(parts)==2 and parts[1].endswith(".py"):return True
        return parts[:2]==(".github","workflows") and len(parts)==3 and parts[2].endswith((".yml",".yaml"))
    if target.startswith("windows-"):return parts==("BDOPortraitStudio.exe",)
    if target.startswith("macos-"):return parts[:2]==("BDOPortraitStudio.app","Contents") and len(parts)>2
    return parts==("BDOPortraitStudio",)


def unpack_package(archive_path,payload,target):
    payload=Path(payload).resolve();payload.mkdir(parents=True,exist_ok=True)
    files=[];total=0;roots=set();seen=set()
    with zipfile.ZipFile(archive_path) as archive:
        if len(archive.infolist())>3000:raise ValueError("업데이트 파일 항목이 너무 많습니다.")
        for info in archive.infolist():
            if info.is_dir():continue
            if "\\" in info.filename:raise ValueError("업데이트 파일 경로가 올바르지 않습니다.")
            path=PurePosixPath(info.filename)
            if path.is_absolute() or len(path.parts)<2 or ".." in path.parts:raise ValueError("업데이트 파일 경로가 올바르지 않습니다.")
            roots.add(path.parts[0]);relative=PurePosixPath(*path.parts[1:]).as_posix()
            if not app_file(relative,target) or stat.S_ISLNK(info.external_attr>>16):raise ValueError("프로그램 파일 이외의 항목이 업데이트에 포함되어 있습니다: "+relative)
            if relative.casefold() in seen:raise ValueError("중복 업데이트 파일이 있습니다.")
            seen.add(relative.casefold());total+=info.file_size
            if total>MAX_EXTRACT:raise ValueError("압축을 푼 업데이트가 너무 큽니다.")
            destination=(payload/relative).resolve()
            if not destination.is_relative_to(payload):raise ValueError("업데이트 파일 범위를 벗어났습니다.")
            destination.parent.mkdir(parents=True,exist_ok=True)
            content=archive.read(info)
            destination.write_bytes(content)
            destination.chmod((info.external_attr>>16)&0o777 or 0o644)
            files.append(dict(path=relative,sha256=hashlib.sha256(content).hexdigest()))
    if len(roots)!=1:raise ValueError("업데이트 배포 폴더가 하나여야 합니다.")
    entry="run.py" if target=="source" else ("BDOPortraitStudio.exe" if target.startswith("windows-") else "BDOPortraitStudio.app/Contents/MacOS/BDOPortraitStudio" if target.startswith("macos-") else "BDOPortraitStudio")
    if entry not in {item["path"] for item in files}:raise ValueError("업데이트에 실행 파일이 없습니다.")
    return files,entry


def stage_release(release,data_dir,install_dir,progress=lambda value:None):
    if not release["available"]:raise ValueError("이미 최신 버전입니다.")
    stage=Path(data_dir).resolve()/"updates"/uuid.uuid4().hex
    stage.mkdir(parents=True)
    archive=stage/"download.zip";digest=hashlib.sha256();count=0
    with _open(release["location"]) as incoming,open(archive,"wb") as output:
        while True:
            block=incoming.read(128*1024)
            if not block:break
            count+=len(block)
            if count>release["package"]["size"] or count>MAX_DOWNLOAD:raise ValueError("업데이트 크기가 배포 정보와 다릅니다.")
            digest.update(block);output.write(block)
            progress(f"업데이트 다운로드 중… {count*100/release['package']['size']:.0f}%")
    if count!=release["package"]["size"] or digest.hexdigest()!=release["package"]["sha256"]:raise ValueError("업데이트 파일 검증에 실패했습니다. 설치하지 않았습니다.")
    files,entry=unpack_package(archive,stage/"payload",release["target"])
    plan=dict(app=APP_ID,version=release["version"],target=release["target"],
              install_dir=str(Path(install_dir).resolve()),data_dir=str(Path(data_dir).resolve()),
              payload=str(stage/"payload"),files=files,entry=entry,parent_pid=os.getpid())
    path=stage/"plan.json";atomic_json(path,plan)
    return path


def validate_plan(plan_path):
    plan_path=Path(plan_path).resolve();plan=json.loads(plan_path.read_text(encoding="utf-8"))
    if plan.get("app")!=APP_ID:raise ValueError("업데이트 설치 정보가 올바르지 않습니다.")
    version_tuple(plan.get("version"))
    install=Path(plan["install_dir"]).resolve();payload=Path(plan["payload"]).resolve()
    if install==Path(install.anchor) or payload!=plan_path.parent/"payload":raise ValueError("업데이트 경로를 확인해 주세요.")
    files=plan["files"]
    if not isinstance(files,list) or not files or len(files)>3000:raise ValueError("업데이트 설치 항목이 올바르지 않습니다.")
    seen=set()
    for item in files:
        relative=item["path"]
        if relative in seen or not app_file(relative,plan["target"]):raise ValueError("프로그램 이외의 경로를 변경할 수 없습니다.")
        seen.add(relative)
        source=(payload/relative).resolve();destination=(install/relative).resolve()
        if not source.is_relative_to(payload) or not destination.is_relative_to(install):raise ValueError("업데이트 경로가 프로그램 폴더를 벗어났습니다.")
        if source.is_symlink() or not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest()!=item["sha256"]:raise ValueError("설치 준비 파일이 변경되었습니다.")
    if plan["entry"] not in seen:raise ValueError("설치할 실행 파일이 없습니다.")
    return plan


def launch_installer(plan_path):
    plan=validate_plan(plan_path)
    stage=Path(plan_path).resolve().parent
    if plan["target"]=="source":
        runner=stage/"runner";shutil.copytree(plan["payload"],runner)
        command=[sys.executable,str(runner/"run.py"),"--apply-update",str(plan_path)]
    elif plan["target"].startswith("macos-"):
        runner=stage/"runner.app";shutil.copytree(Path(plan["payload"])/"BDOPortraitStudio.app",runner)
        executable=runner/"Contents/MacOS/BDOPortraitStudio";executable.chmod(0o755)
        command=[str(executable),"--apply-update",str(plan_path)]
    else:
        runner=stage/("update-runner.exe" if sys.platform=="win32" else "update-runner")
        shutil.copy2(Path(plan["payload"])/plan["entry"],runner);runner.chmod(0o755)
        command=[str(runner),"--apply-update",str(plan_path)]
    environment=os.environ.copy()
    if getattr(sys,"frozen",False):environment["PYINSTALLER_RESET_ENVIRONMENT"]="1"
    options={"creationflags":subprocess.CREATE_NO_WINDOW} if sys.platform=="win32" else {"start_new_session":True}
    with open(stage/"installer.log","ab") as log:
        return subprocess.Popen(command,cwd=stage,env=environment,stdout=log,stderr=log,**options)


def pid_running(pid):
    if not isinstance(pid,int) or pid<=0:return False
    if sys.platform=="win32":
        import ctypes
        api=ctypes.WinDLL("kernel32",use_last_error=True)
        api.OpenProcess.restype=ctypes.c_void_p
        handle=api.OpenProcess(0x100000,False,pid)
        if not handle:return False
        try:
            api.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_uint32]
            return api.WaitForSingleObject(handle,0)==258
        finally:
            api.CloseHandle.argtypes=[ctypes.c_void_p];api.CloseHandle(handle)
    try:os.kill(pid,0);return True
    except ProcessLookupError:return False
    except PermissionError:return True


def _replace(source,destination):
    destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True)
    temporary=destination.with_name(destination.name+".update-"+uuid.uuid4().hex)
    shutil.copy2(source,temporary)
    try:
        for attempt in range(80):
            try:os.replace(temporary,destination);return
            except PermissionError:
                if attempt==79:raise
                time.sleep(.25)
    finally:
        if temporary.exists():temporary.unlink()


def apply_plan(plan_path,wait=True,restart=True):
    plan=validate_plan(plan_path);stage=Path(plan_path).resolve().parent
    data=Path(plan["data_dir"]);install=Path(plan["install_dir"]);payload=Path(plan["payload"])
    if wait:
        for attempt in range(240):
            if not pid_running(plan["parent_pid"]):break
            time.sleep(.25)
        else:raise RuntimeError("프로그램이 종료되지 않아 업데이트하지 않았습니다.")
    # Recheck files after waiting; no user library is ever an install target.
    validate_plan(plan_path)
    changed=[]
    try:
        for item in plan["files"]:
            relative=item["path"];target=install/relative;backup=stage/"previous"/relative
            existed=target.is_file()
            if existed:backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,backup)
            changed.append((target,backup,existed))
            _replace(payload/relative,target)
        result=dict(status="updated",version=plan["version"],message="업데이트를 적용했습니다.")
    except Exception as exc:
        errors=[]
        for target,backup,existed in reversed(changed):
            try:
                if existed:_replace(backup,target)
                elif target.is_file():target.unlink()
            except Exception as rollback_error:errors.append(str(rollback_error))
        result=dict(status="failed",version=plan["version"],message=str(exc),rollback_errors=errors)
    atomic_json(data/"update-status.json",result)
    if restart:
        entry=install/plan["entry"]
        command=([sys.executable,str(entry)] if plan["target"]=="source" else [str(entry)])+["--data-dir",str(data)]
        environment=os.environ.copy()
        if getattr(sys,"frozen",False):environment["PYINSTALLER_RESET_ENVIRONMENT"]="1"
        subprocess.Popen(command,cwd=install,env=environment)
    return result
