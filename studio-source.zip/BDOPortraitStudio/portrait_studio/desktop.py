"""Small cross-platform desktop helpers, including optional native file drops."""
from __future__ import annotations

import os
import subprocess
import sys
import tkinter as tk
from pathlib import Path


def create_root():
    try:
        from tkinterdnd2 import TkinterDnD
    except ImportError as exc:
        root = tk.Tk()
        root.dnd_unavailable = True
        root.dnd_error = str(exc)
        return root

    class DropRoot(TkinterDnD.Tk):
        def __init__(self):
            try:
                super().__init__()
            except (RuntimeError, tk.TclError):
                # Tk is created before the native library loads. Remove that
                # partial window before falling back to a regular Tk root.
                try:
                    self.destroy()
                except (AttributeError, tk.TclError):
                    pass
                raise

    try:
        return DropRoot()
    except (RuntimeError, tk.TclError) as exc:
        root = tk.Tk()
        root.dnd_unavailable = True
        root.dnd_error = str(exc)
        return root


def register_file_drop(widget, callback):
    try:
        from tkinterdnd2 import COPY, DND_FILES
        widget.drop_target_register(DND_FILES)

        def dropped(event):
            paths = list(widget.tk.splitlist(event.data))
            return COPY if callback(paths) else "refuse_drop"

        widget.dnd_bind("<<Drop>>", dropped)
        return True
    except (ImportError, AttributeError, RuntimeError, tk.TclError):
        return False


def register_file_drag(widget, paths):
    try:
        from tkinterdnd2 import COPY, DND_FILES
        widget.drag_source_register(1, DND_FILES)

        def start(event):
            files = tuple(str(Path(path).resolve()) for path in paths())
            if not files or any(not Path(path).is_file() for path in files):
                return "refuse_drop"
            return COPY, DND_FILES, files

        widget.dnd_bind("<<DragInitCmd>>", start)
        return True
    except (ImportError, AttributeError, RuntimeError, tk.TclError):
        return False


def open_folder(folder):
    path = str(Path(folder).resolve())
    if sys.platform == "win32":
        os.startfile(path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])
