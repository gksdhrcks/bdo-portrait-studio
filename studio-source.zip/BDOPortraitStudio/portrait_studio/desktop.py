"""Small cross-platform desktop helpers, including optional native file drops."""
from __future__ import annotations

import os
import subprocess
import sys
import tkinter as tk
from pathlib import Path


def create_root():
    try:
        from tkinterdnd2 import TkinterDnD
    except ImportError:
        root = tk.Tk()
        root.dnd_unavailable = True
        return root

    class DropRoot(TkinterDnD.Tk):
        def __init__(self):
            try:
                super().__init__()
            except (RuntimeError, tk.TclError):
                # Tk is created before the native library loads. Remove that
                # partial window before falling back to a regular Tk root.
                try:
                    self.destroy()
                except (AttributeError, tk.TclError):
                    pass
                raise

    try:
        return DropRoot()
    except (RuntimeError, tk.TclError):
        root = tk.Tk()
        root.dnd_unavailable = True
        return root


def register_file_drop(widget, callback):
    try:
        from tkinterdnd2 import COPY, DND_FILES
        widget.drop_target_register(DND_FILES)

        def dropped(event):
            paths = list(widget.tk.splitlist(event.data))
            return COPY if callback(paths) else "refuse_drop"

        widget.dnd_bind("<<Drop>>", dropped)
        return True
    except (ImportError, AttributeError, RuntimeError, tk.TclError):
        return False


def open_folder(folder):
    path = str(Path(folder).resolve())
    if sys.platform == "win32":
        os.startfile(path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])
