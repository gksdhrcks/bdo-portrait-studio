"""One-image handoffs with readable instructions and distinct source/reference panels."""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from .core import find_fonts


def korean_font(candidates=()):
    for path in dict.fromkeys([*candidates, *find_fonts()]):
        if not path or not Path(path).is_file():
            continue
        try:
            font = ImageFont.truetype(str(path), 30)
            if bytes(font.getmask("한")) != bytes(font.getmask("\u0378")):
                return str(path)
        except (OSError, ValueError):
            continue
    raise ValueError("한 장 첨부에는 한글 폰트가 필요합니다. '한글 폰트 선택'에서 TTF·OTF·TTC를 선택하거나 원본 첨부 탭을 사용하세요.")


def wrap_text(text, font, width):
    lines = []
    for paragraph in text.replace("\r\n", "\n").split("\n"):
        current = ""
        for character in paragraph:
            if current and font.getlength(current + character) > width:
                lines.append(current)
                current = character
            else:
                current += character
        lines.append(current)
    return lines


def render_handoff(base, reference, prompt, font_path):
    if len(prompt) > 8000:
        raise ValueError("한 장에 담기에는 요청문이 너무 깁니다. 추가 요청을 줄이거나 원본 첨부 탭을 사용하세요.")
    width, margin, gap = 1800, 60, 36
    body_font = ImageFont.truetype(str(font_path), 32)
    title_font = ImageFont.truetype(str(font_path), 48)
    label_font = ImageFont.truetype(str(font_path), 36)
    text = prompt.replace("01_base.png", "아래 A · 기본 그림").replace("02_reference.png", "아래 B · 참조 그림")
    text += "\n이 작업판은 요청을 전달하는 자료입니다. 작업판의 글자·테두리·A/B 표시는 결과물에 넣지 마세요."
    lines = wrap_text(text, body_font, width - 2 * margin)
    text_y, line_height = 148, 49
    panels_y = text_y + line_height * len(lines) + 48
    panel_height = 1100
    height = panels_y + panel_height + 90
    if height > 4800:
        raise ValueError("요청문이 길어 한 장 첨부의 글자를 읽기 어렵습니다. 추가 요청을 줄이거나 원본 첨부 탭을 사용하세요.")
    canvas = Image.new("RGB", (width, height), "#f6f5f1")
    draw = ImageDraw.Draw(canvas)
    draw.text((margin, 46), "초상화 한 장을 새로 생성해 주세요", font=title_font, fill="#212a35")
    for index, line in enumerate(lines):
        draw.text((margin, text_y + index * line_height), line, font=body_font, fill="#202631")
    images = [("A · 기본 그림 — 바탕으로 사용", base)]
    if reference is not None:
        images.append(("B · 참조 그림 — 지정한 요소만 참고", reference))
    panel_width = (width - 2 * margin - gap * (len(images) - 1)) // len(images)
    boxes = []
    for index, (label, image) in enumerate(images):
        left = margin + index * (panel_width + gap)
        draw.text((left, panels_y), label, font=label_font, fill="#705223")
        top = panels_y + 64
        draw.rounded_rectangle((left, top, left + panel_width, top + panel_height - 70), radius=16, fill="#e6e6e1")
        thumb = image.convert("RGB")
        thumb.thumbnail((panel_width - 28, panel_height - 98), Image.Resampling.LANCZOS)
        x = left + (panel_width - thumb.width) // 2
        y = top + (panel_height - 70 - thumb.height) // 2
        canvas.paste(thumb, (x, y))
        boxes.append((x, y, x + thumb.width, y + thumb.height))
    draw.text((margin, height - 55), "요청문과 참고 그림 전달용 · 최종 초상화에는 위 설명과 패널을 그리지 마세요", font=body_font, fill="#616b78")
    return canvas, boxes
